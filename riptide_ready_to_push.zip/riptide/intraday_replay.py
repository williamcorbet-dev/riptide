"""
Intraday replay: re-run the ensemble signal at multiple points across a
single real trading day, so you can see how the system's read evolved
minute-to-minute (or however coarsely you like) and compare it against
what price actually did afterward.

This is an inspection tool, not a backtest -- it doesn't score itself or
feed anything back into the persistent scenario/weights state in `state/`
(it uses fresh, throwaway stores per run, same as the test suite does), so
running it as many times as you want has no side effects on live use.

At each checked time on the target day, only bars up to and including
that time are visible to the signal (`intraday_df`), and only prior
trading days are visible for the technical/daily-history voters
(`daily_df`) and the time-of-day fingerprint baseline
(`intraday_history`) -- so this is a genuine point-in-time reconstruction,
not a look-ahead-tainted one.

Usage:
    python intraday_replay.py --webull-csv data/SPY_Webull_1min_20260706_to_20260814.csv \
        --date 2026-08-14 --interval 30

Writes two CSVs (<date>_replay.csv -- one row per checked time, and
<date>_replay_votes.csv -- one row per checked time per voter, for
digging into *why* the signal was what it was) and, if matplotlib is
available, a PNG chart of that day's price with the signal overlaid.
"""

import argparse

import numpy as np
import pandas as pd

from webull_data import load_webull_intraday_csv, derive_daily_from_intraday
from composite_signal import SignalInputs, generate_signal
from scenario_engine import ScenarioStore, AdaptiveWeights, SIGNAL_THRESHOLD
from vanna_charm import VannaCharmHistoryStore
from skew_dynamics import SkewHistoryStore
from risk_management import RiskConfig, size_position
from options_pricing import bs_price, nearest_strike

MARKET_CLOSE_HOUR = 16


def _checkpoints(day_bars: pd.DataFrame, interval_minutes: int) -> list:
    """Every `interval_minutes`-th bar's timestamp for the day, always
    including the day's very first and last bar."""
    idx = day_bars.index
    if len(idx) == 0:
        return []
    step = max(1, interval_minutes)
    points = list(idx[::step])
    if idx[-1] not in points:
        points.append(idx[-1])
    return points


def _resolve_daily_df(history_bars: pd.DataFrame, target_date: pd.Timestamp,
                       daily_df: pd.DataFrame = None) -> pd.DataFrame:
    """Picks the daily_df a replay checkpoint should see: the caller's own
    real long history if supplied (filtered to strictly-before-target_date,
    same no-lookahead rule as everything else in this module), else the
    old fallback of resampling whatever intraday history happens to be in
    the same file.

    Added 2026-08-18 (daily_reviews.md, 2026-08-17 entry, proposal #1):
    live checkpoints (live_signal.py) build daily_df from ~750 days of
    real daily bars (yfinance or Webull D bars), but this replay tool was
    silently using a much shorter one -- only as many days as happened to
    be in the intraday export, derived by resampling 1-min bars up to
    daily. That's a real mismatch: a grading pass is supposed to
    reconstruct exactly what live saw, and `technical`/`hurst`/`hmm_regime`
    all behave differently with 30 days of resampled history than with
    750 real days (see the 2026-08-17 end-of-day review's methodology
    caveat -- it's the documented reason the daily-review numbers didn't
    quite match what live checkpoints showed that same day). Passing a
    real `daily_df` through now closes that gap; omitting it keeps the
    old resampled-fallback behavior so existing short-history callers
    (tests, quick looks with only an intraday export) keep working
    unchanged."""
    if daily_df is not None and not daily_df.empty:
        return daily_df[daily_df.index.normalize() < target_date]
    return derive_daily_from_intraday(history_bars)


def replay_day(minute_df: pd.DataFrame, target_date, interval_minutes: int = 30,
                account_size: float = 25000.0, assumed_iv: float = 0.16,
                signal_threshold: float = SIGNAL_THRESHOLD, chain=None,
                daily_df: pd.DataFrame = None, adaptive_weights_seed: dict = None,
                scenario_history_seed: dict = None) -> pd.DataFrame:
    """Re-runs generate_signal() at each checkpoint time within
    `target_date`, using only data visible up to that moment. Returns a
    row per checkpoint with the final signal plus forward-looking price
    context for hindsight comparison (NOT used by the signal itself).
    `signal_threshold` defaults to the live value (scenario_engine.
    SIGNAL_THRESHOLD) but can be loosened to see what would have fired at
    a lower bar -- see daily_review.py for grading those extra alerts.
    `chain`: an optional gamma_positioning.ChainSnapshot for this exact
    day (see historical_chain.py) -- if supplied, it's used at EVERY
    checkpoint of the replay (a single end-of-day snapshot standing in
    for the whole session, since that's all a daily vendor export gives
    you), which unlocks the gamma/vanna-charm/put-call-ratio/skew voters
    for this day instead of them sitting out.
    `daily_df`: optional real long daily-history DataFrame (same source
    live checkpoints use, e.g. Webull D bars) -- see `_resolve_daily_df`.
    Omit to fall back to resampling this file's own intraday history.
    `adaptive_weights_seed`/`scenario_history_seed`: this replay ALWAYS
    uses fresh, throwaway ScenarioStore/AdaptiveWeights (see below --
    never the real state/ used by live_signal.py/backtest.py), so by
    default every voter starts at trust==1.0 and no scenario has any
    history, regardless of what's actually been learned live. That's the
    right default for "what would each voter say in isolation," but it is
    NOT the same thing as "what would the live ensemble have called" --
    for that, pass a read-only copy of the real weights/scenario dicts
    here (e.g. `json.load(open("state/voter_weights.json"))`) to seed the
    throwaway store for this replay only; the real state/ files are never
    read or written by this function either way. Found and fixed
    2026-08-21 after a review accidentally compared "current live
    weights" against a replay that was silently using defaults -- see
    daily_reviews.md."""
    target_date = pd.Timestamp(target_date).normalize()
    all_days = minute_df.index.normalize()

    history_bars = minute_df[all_days < target_date]
    day_bars = minute_df[all_days == target_date]
    if day_bars.empty:
        raise ValueError(f"No bars found for {target_date.date()} in the supplied data")

    daily_df = _resolve_daily_df(history_bars, target_date, daily_df)
    if daily_df.empty:
        raise ValueError(f"No prior daily history before {target_date.date()} in this file -- "
                          f"pick a later date (the technical/Hurst/HMM voters need at least one "
                          f"prior completed day)")
    day_close = float(day_bars["Close"].iloc[-1])

    # Fresh, throwaway state per replay -- this must never touch the real
    # persistent state/ used by live_signal.py/backtest.py. If seeds are
    # given, they're applied in-memory only (never written to the
    # throwaway path on disk), so this never leaks into some other,
    # unrelated, unseeded replay call later in the same process.
    store, weights = ScenarioStore(path="/tmp/_replay_scenarios.json"), AdaptiveWeights(path="/tmp/_replay_weights.json")
    if adaptive_weights_seed is not None:
        weights.weights = dict(adaptive_weights_seed)
    if scenario_history_seed is not None:
        from scenario_engine import ScenarioRecord
        store.records = {fp: ScenarioRecord(fingerprint=fp, outcomes=list(outcomes))
                          for fp, outcomes in scenario_history_seed.items()}
    vc_store = VannaCharmHistoryStore(path="/tmp/_replay_vanna_charm.json")
    skew_store = SkewHistoryStore(path="/tmp/_replay_skew.json")
    risk_cfg = RiskConfig(account_size=account_size)

    rows = []
    for t in _checkpoints(day_bars, interval_minutes):
        intraday_today = day_bars[day_bars.index <= t]
        price_now = float(intraday_today["Close"].iloc[-1])
        hours_to_close = max(0.0, MARKET_CLOSE_HOUR - (t.hour + t.minute / 60))

        inputs = SignalInputs(
            daily_df=daily_df,  # may be short (or empty) early in the dataset -- voters degrade honestly
            intraday_df=intraday_today,
            intraday_history=history_bars if len(history_bars) > 0 else None,
            chain=chain,
            vanna_charm_store=vc_store,
            skew_store=skew_store,
            today=target_date.date(),
            hours_to_close=hours_to_close,
        )
        sig = generate_signal(inputs, scenario_store=store, adaptive_weights=weights,
                               signal_threshold=signal_threshold)

        contracts = 0
        if sig.signal in ("CALL", "PUT") and len(daily_df) > 0:
            strike = nearest_strike(price_now)
            premium = bs_price(price_now, strike, 1 / 365, 0.05, assumed_iv,
                                "call" if sig.signal == "CALL" else "put")
            contracts = size_position(sig, entry_premium=premium, cfg=risk_cfg).contracts

        future_30 = day_bars[day_bars.index > t]["Close"].iloc[0:30]
        price_plus_30m = float(future_30.iloc[min(29, len(future_30) - 1)]) if len(future_30) else np.nan
        pct_to_close = (day_close - price_now) / price_now if price_now else np.nan

        rows.append({
            "time": t, "price": price_now, "signal": sig.signal,
            "direction": round(sig.direction, 3), "confidence": round(sig.confidence, 3),
            "method": sig.method, "contracts_at_this_conf": contracts,
            "price_+30m": price_plus_30m, "day_close": day_close,
            "pct_move_to_close": round(pct_to_close, 5) if not np.isnan(pct_to_close) else np.nan,
        })

    return pd.DataFrame(rows).set_index("time")


def replay_day_votes(minute_df: pd.DataFrame, target_date, interval_minutes: int = 30,
                      signal_threshold: float = SIGNAL_THRESHOLD, chain=None,
                      daily_df: pd.DataFrame = None, adaptive_weights_seed: dict = None,
                      scenario_history_seed: dict = None) -> pd.DataFrame:
    """Same walk as replay_day(), but returns one row per (time, voter) --
    long format, for inspecting exactly which voters drove each reading.
    `chain`: see replay_day()'s docstring. `daily_df`/`adaptive_weights_seed`/
    `scenario_history_seed`: see replay_day()'s docstring."""
    target_date = pd.Timestamp(target_date).normalize()
    all_days = minute_df.index.normalize()
    history_bars = minute_df[all_days < target_date]
    day_bars = minute_df[all_days == target_date]
    if day_bars.empty:
        raise ValueError(f"No bars found for {target_date.date()} in the supplied data")

    daily_df = _resolve_daily_df(history_bars, target_date, daily_df)
    if daily_df.empty:
        raise ValueError(f"No prior daily history before {target_date.date()} in this file")
    store, weights = ScenarioStore(path="/tmp/_replay_scenarios.json"), AdaptiveWeights(path="/tmp/_replay_weights.json")
    if adaptive_weights_seed is not None:
        weights.weights = dict(adaptive_weights_seed)
    if scenario_history_seed is not None:
        from scenario_engine import ScenarioRecord
        store.records = {fp: ScenarioRecord(fingerprint=fp, outcomes=list(outcomes))
                          for fp, outcomes in scenario_history_seed.items()}
    vc_store = VannaCharmHistoryStore(path="/tmp/_replay_vanna_charm.json")
    skew_store = SkewHistoryStore(path="/tmp/_replay_skew.json")

    rows = []
    for t in _checkpoints(day_bars, interval_minutes):
        intraday_today = day_bars[day_bars.index <= t]
        hours_to_close = max(0.0, MARKET_CLOSE_HOUR - (t.hour + t.minute / 60))
        inputs = SignalInputs(daily_df=daily_df, intraday_df=intraday_today,
                               intraday_history=history_bars if len(history_bars) > 0 else None,
                               chain=chain, vanna_charm_store=vc_store, skew_store=skew_store,
                               today=target_date.date(), hours_to_close=hours_to_close)
        sig = generate_signal(inputs, scenario_store=store, adaptive_weights=weights,
                               signal_threshold=signal_threshold)
        for v in sig.votes:
            rows.append({"time": t, "voter": v.name, "direction": round(v.direction, 3),
                         "confidence": round(v.confidence, 3), "regime_tag": v.regime_tag})

    return pd.DataFrame(rows)


def plot_replay(replay_df: pd.DataFrame, day_bars: pd.DataFrame, out_path: str, target_date) -> bool:
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return False

    fig, ax = plt.subplots(figsize=(12, 5))
    ax.plot(day_bars.index, day_bars["Close"], color="black", linewidth=0.8, label="SPY (1min close)")

    colors = {"CALL": "green", "PUT": "red", "NONE": "gray"}
    markers = {"CALL": "^", "PUT": "v", "NONE": "o"}
    for sig_type in ("NONE", "PUT", "CALL"):  # draw NONE first so CALL/PUT sit on top
        sub = replay_df[replay_df["signal"] == sig_type]
        if sub.empty:
            continue
        sizes = 30 + 220 * sub["confidence"]
        ax.scatter(sub.index, sub["price"], c=colors[sig_type], marker=markers[sig_type],
                    s=sizes, edgecolors="black", linewidths=0.5, label=sig_type, zorder=3)

    ax.set_title(f"SPY {target_date} -- signal replay (marker size = confidence)")
    ax.set_ylabel("Price")
    ax.legend()
    ax.grid(alpha=0.3)
    fig.autofmt_xdate()
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return True


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--webull-csv", required=True)
    ap.add_argument("--date", required=True, help="YYYY-MM-DD, must be a day present in the CSV")
    ap.add_argument("--interval", type=int, default=30, help="minutes between checkpoints")
    ap.add_argument("--account-size", type=float, default=25000.0)
    ap.add_argument("--signal-threshold", type=float, default=SIGNAL_THRESHOLD,
                     help=f"direction magnitude needed to fire CALL/PUT (default {SIGNAL_THRESHOLD}, "
                          f"the live value) -- loosen this to see what would have fired at a lower bar")
    ap.add_argument("--out-prefix", default=None, help="defaults to the date, e.g. 2026-08-14")
    ap.add_argument("--chain-dir", default=None,
                     help="a folder containing this day's Greek_YYYYMMDD_OData*.csv files (see "
                          "historical_chain.py) -- if the target --date is found there, gamma/"
                          "vanna-charm/put-call-ratio/skew all run against the REAL chain for this "
                          "day instead of sitting out")
    ap.add_argument("--chain-symbol", default="SPY", help="ticker to pull out of --chain-dir's files")
    args = ap.parse_args()

    minute_df = load_webull_intraday_csv(args.webull_csv)
    prefix = args.out_prefix or args.date

    chain = None
    if args.chain_dir:
        from historical_chain import build_chain_lookup_from_dir
        lookup = build_chain_lookup_from_dir(args.chain_dir, symbol=args.chain_symbol)
        chain = lookup.get(pd.Timestamp(args.date).date())
        if chain is None:
            print(f"[warn] no chain found for {args.date} in {args.chain_dir} "
                  f"(found: {sorted(lookup.keys())}) -- continuing without one")
        else:
            print(f"[info] loaded real chain for {args.date} ({args.chain_symbol}, "
                  f"spot={chain.spot}, {len(chain.strike)} strikes)")

    replay = replay_day(minute_df, args.date, interval_minutes=args.interval, account_size=args.account_size,
                         signal_threshold=args.signal_threshold, chain=chain)
    votes = replay_day_votes(minute_df, args.date, interval_minutes=args.interval,
                              signal_threshold=args.signal_threshold, chain=chain)
    replay.to_csv(f"{prefix}_replay.csv")
    votes.to_csv(f"{prefix}_replay_votes.csv", index=False)

    print(replay.to_string())
    print(f"\nWrote {prefix}_replay.csv and {prefix}_replay_votes.csv")

    day_bars = minute_df[minute_df.index.normalize() == pd.Timestamp(args.date).normalize()]
    png_path = f"{prefix}_replay.png"
    if plot_replay(replay, day_bars, png_path, args.date):
        print(f"Wrote {png_path}")
    else:
        print("[info] matplotlib not available -- skipped the chart, CSVs are still complete")


if __name__ == "__main__":
    main()
