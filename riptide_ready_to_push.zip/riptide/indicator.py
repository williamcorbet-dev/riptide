"""
SPY 1DTE Options Directional Indicator
========================================
Computes a composite directional score from OHLCV price data and translates
it into CALL / PUT / NONE signals intended for 1-day-to-expiration (1DTE)
SPY options entries.

Methodology (see README.md for full rationale):
  - Trend:     fast/slow EMA spread, normalized by ATR
  - Momentum:  MACD histogram + RSI deviation from 50
  - Location:  price vs session VWAP, normalized by ATR
  - Volume:    relative volume as a confirmation multiplier
  - Regime gate: skips signals when ATR is in an extreme percentile
                 (too quiet -> theta eats premium; too wild -> chase risk)

This is a technical/quantitative research tool, not investment advice.
Options, especially 0-1DTE, carry substantial risk of rapid, total loss
of premium. See README.md for important disclosures before using this
with real capital.
"""

from dataclasses import dataclass

import numpy as np
import pandas as pd


# ---------------------------------------------------------------------------
# Indicator building blocks
# ---------------------------------------------------------------------------

def ema(series: pd.Series, span: int) -> pd.Series:
    return series.ewm(span=span, adjust=False).mean()


def rsi(series: pd.Series, period: int = 14) -> pd.Series:
    delta = series.diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    avg_gain = gain.ewm(alpha=1 / period, adjust=False).mean()
    avg_loss = loss.ewm(alpha=1 / period, adjust=False).mean()
    rs = avg_gain / avg_loss.replace(0, np.nan)
    result = 100 - (100 / (1 + rs))
    # When avg_loss is exactly 0 (no down moves anywhere in the smoothing
    # window -- rare, but happens on a strictly monotonic run), the division
    # above produces NaN and poisons the whole downstream composite score.
    # Standard convention: RSI = 100 when there were only gains, 50 (neutral)
    # when there was no movement at all.
    result = result.where(avg_loss != 0, np.where(avg_gain > 0, 100.0, 50.0))
    return result


def atr(df: pd.DataFrame, period: int = 14) -> pd.Series:
    high, low, close = df["High"], df["Low"], df["Close"]
    prev_close = close.shift(1)
    tr = pd.concat(
        [
            (high - low),
            (high - prev_close).abs(),
            (low - prev_close).abs(),
        ],
        axis=1,
    ).max(axis=1)
    return tr.ewm(alpha=1 / period, adjust=False).mean()


def macd(series: pd.Series, fast: int = 12, slow: int = 26, signal: int = 9):
    macd_line = ema(series, fast) - ema(series, slow)
    signal_line = ema(macd_line, signal)
    hist = macd_line - signal_line
    return macd_line, signal_line, hist


def money_flow_index(df: pd.DataFrame, period: int = 14) -> pd.Series:
    """Volume-weighted RSI: typical price * volume gives each bar's "money
    flow", split into positive/negative by whether typical price rose or
    fell versus the prior bar, then the same 0-100 RSI-shaped ratio is
    applied to the rolling sums. Unlike `rsi()` (pure price), this can
    disagree with price when a move isn't backed by real volume -- see
    `mfi_divergence.py` for why that gap matters (2026-08-19,
    daily_reviews.md: checked real correlation between RSI and MFI before
    building anything on top of it -- 0.83 same-day, but only 0.68 across
    30 real trading days with a meaningful gap >20pts on 12% of bars, so
    it's carrying genuinely different information some of the time, not
    just a relabeled RSI)."""
    typical = (df["High"] + df["Low"] + df["Close"]) / 3
    raw_money_flow = typical * df["Volume"]
    delta = typical.diff()
    positive_flow = raw_money_flow.where(delta > 0, 0.0).rolling(period).sum()
    negative_flow = raw_money_flow.where(delta < 0, 0.0).rolling(period).sum()
    money_ratio = positive_flow / negative_flow.replace(0, np.nan)
    mfi = 100 - (100 / (1 + money_ratio))
    # No negative flow at all in the window (a pure uptrend) is the
    # maximally-bullish case, not an undefined one -- only a window with
    # NO flow whatsoever (dead volume) should stay NaN.
    both_zero = (positive_flow == 0) & (negative_flow == 0)
    mfi = mfi.mask(negative_flow == 0, 100.0)
    mfi = mfi.mask(both_zero, np.nan)
    return mfi


def session_vwap(df: pd.DataFrame, window: int = 20) -> pd.Series:
    """Session VWAP when the index is intraday timestamps (grouped by
    calendar day). Falls back to a rolling VWAP over `window` bars for
    daily data, since a single daily bar has no intra-session VWAP."""
    typical = (df["High"] + df["Low"] + df["Close"]) / 3
    pv = typical * df["Volume"]

    is_intraday = isinstance(df.index, pd.DatetimeIndex) and (
        df.index.normalize() != df.index
    ).any()

    if is_intraday:
        day = df.index.normalize()
        cum_pv = pv.groupby(day).cumsum()
        cum_vol = df["Volume"].groupby(day).cumsum()
        return cum_pv / cum_vol.replace(0, np.nan)

    return pv.rolling(window).sum() / df["Volume"].rolling(window).sum()


@dataclass
class IndicatorConfig:
    ema_fast: int = 9
    ema_slow: int = 21
    ema_trend: int = 50
    rsi_period: int = 14
    atr_period: int = 14
    macd_fast: int = 12
    macd_slow: int = 26
    macd_signal: int = 9
    vol_avg_period: int = 20
    atr_lookback: int = 100  # window for volatility-regime percentile rank
    atr_low_pct: float = 0.15  # skip trades below this ATR percentile (too quiet)
    atr_high_pct: float = 0.95  # skip trades above this ATR percentile (too wild)
    signal_threshold: float = 0.35  # |score| needed to fire a CALL/PUT
    w_trend: float = 0.40
    w_momentum: float = 0.30
    w_vwap: float = 0.20
    w_volume: float = 0.10


def compute_indicator(df: pd.DataFrame, cfg: IndicatorConfig = IndicatorConfig()) -> pd.DataFrame:
    """
    df must have columns Open, High, Low, Close, Volume and a DatetimeIndex.
    Returns a copy of df with added columns, including `score` (-1..1) and
    `signal` (one of 'CALL', 'PUT', 'NONE').
    """
    required = {"Open", "High", "Low", "Close", "Volume"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"df is missing required columns: {missing}")

    out = df.copy()
    close = out["Close"]

    out["ema_fast"] = ema(close, cfg.ema_fast)
    out["ema_slow"] = ema(close, cfg.ema_slow)
    out["ema_trend"] = ema(close, cfg.ema_trend)
    out["rsi"] = rsi(close, cfg.rsi_period)
    out["atr"] = atr(out, cfg.atr_period)
    _, _, macd_hist = macd(close, cfg.macd_fast, cfg.macd_slow, cfg.macd_signal)
    out["macd_hist"] = macd_hist
    out["vwap"] = session_vwap(out, cfg.vol_avg_period)
    out["vol_avg"] = out["Volume"].rolling(cfg.vol_avg_period).mean()

    atr_safe = out["atr"].replace(0, np.nan)

    # Trend: EMA fast/slow spread normalized by ATR, squashed to [-1, 1]
    trend_component = np.tanh((out["ema_fast"] - out["ema_slow"]) / atr_safe)

    # Momentum: MACD histogram (ATR-normalized) blended with RSI deviation from 50
    macd_component = np.tanh(out["macd_hist"] / atr_safe)
    rsi_component = ((out["rsi"] - 50) / 50).clip(-1, 1)
    momentum_component = 0.6 * macd_component + 0.4 * rsi_component

    # Location: price vs VWAP, ATR-normalized
    vwap_component = np.tanh((close - out["vwap"]) / atr_safe)

    # Volume confirmation multiplier (does not set direction, only scales conviction)
    rel_vol = (out["Volume"] / out["vol_avg"]).clip(0, 3)
    volume_component = (rel_vol - 1) / 2  # roughly [-0.5, 1.0]

    direction = (
        cfg.w_trend * trend_component
        + cfg.w_momentum * momentum_component
        + cfg.w_vwap * vwap_component
    )
    score = (direction * (1 + cfg.w_volume * volume_component)).clip(-1, 1)
    out["score"] = score

    # Volatility regime gate: skip signals when ATR is at an extreme percentile
    atr_pct_rank = out["atr"].rolling(cfg.atr_lookback).rank(pct=True)
    out["atr_pct_rank"] = atr_pct_rank
    tradeable = atr_pct_rank.between(cfg.atr_low_pct, cfg.atr_high_pct)

    signal = pd.Series("NONE", index=out.index)
    signal[(score >= cfg.signal_threshold) & tradeable] = "CALL"
    signal[(score <= -cfg.signal_threshold) & tradeable] = "PUT"
    out["signal"] = signal

    return out
