"""
Full live ensemble signal -- pulls daily history, the current 0DTE/near-
dated options chain, VIX term structure, cross-asset leader history, and
(if you have it) intraday history for the candlestick and time-of-day
voters, then runs everything through composite_signal.generate_signal().
Once a signal comes back, it's sized and given an exit plan via
risk_management.py.

This is the ONLY script in this project that can use every voter,
including the live-only ones (gamma positioning, vanna/charm, put/call
ratio, skew dynamics) -- backtest.py can't, because free data sources
don't expose historical options chains. See README.md.

Usage:
    python live_signal.py --ticker SPY

    # with real intraday history from a Webull CSV export (see webull_data.py) --
    # unlocks the candlestick and time-of-day voters with real data instead
    # of sitting them out:
    python live_signal.py --ticker SPY --webull-intraday-csv SPY_1min.csv

After you know what actually happened (e.g. tomorrow's close), call
`record_outcome` (see bottom of this file / README) so the scenario engine
and adaptive voter weights learn from it -- this is how the system is
meant to improve over time rather than stay frozen at today's initial design.
"""

import argparse
from datetime import datetime, date

from backtest import load_data
from gamma_positioning import fetch_chain_yfinance
from vol_regime import fetch_vix_term_structure_yfinance
from cross_asset_leadlag import DEFAULT_LEADERS
from skew_dynamics import SkewHistoryStore
from vanna_charm import VannaCharmHistoryStore
from webull_data import load_webull_intraday_csv, split_latest_day
from composite_signal import SignalInputs, generate_signal
from scenario_engine import (ScenarioStore, AdaptiveWeights, record_outcome,  # noqa: F401 (re-exported for convenience)
                              SIGNAL_THRESHOLD)
from risk_management import RiskConfig, size_position, build_exit_plan
from options_pricing import bs_price, nearest_strike


def _fetch_leader_data(period: str) -> dict:
    """Best-effort fetch of each DEFAULT_LEADERS ticker's daily Close
    history. Leaders that fail to fetch are silently skipped -- the
    lead-lag voter already treats missing/short leaders as unusable rather
    than erroring, so a partial fetch degrades gracefully."""
    leaders = {}
    for ticker in DEFAULT_LEADERS:
        try:
            leaders[ticker] = load_data("yfinance", ticker=ticker, period=period, interval="1d")["Close"]
        except Exception as e:
            print(f"[warn] couldn't fetch leader {ticker} ({e}); skipping it")
    return leaders


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--ticker", default="SPY")
    ap.add_argument("--period", default="2y", help="daily history window for technical/HMM/Hurst/lead-lag")
    ap.add_argument("--expiration", default=None, help="options expiration (YYYY-MM-DD); defaults to nearest")
    ap.add_argument("--account-size", type=float, default=25000.0, help="for position sizing (risk_management.py)")
    ap.add_argument("--assumed-iv", type=float, default=0.16,
                     help="ATM IV fallback for pricing the entry premium used to size the position, "
                          "if the live chain doesn't have a usable ATM quote")
    ap.add_argument("--webull-intraday-csv", default=None,
                     help="path to a Webull intraday-history CSV export (see webull_data.py) -- if "
                          "given, the most recent day's bars feed the candlestick voter and the rest "
                          "build the time-of-day fingerprint baseline, instead of both sitting out")
    ap.add_argument("--webull-session", default="RTH",
                     help="trading_session filter applied to --webull-intraday-csv (default RTH-only)")
    ap.add_argument("--signal-threshold", type=float, default=SIGNAL_THRESHOLD,
                     help=f"direction magnitude needed to fire CALL/PUT instead of NONE (default "
                          f"{SIGNAL_THRESHOLD}). Lower this to alert more often during an early "
                          f"calibration period, then use daily_review.py at day's end to see which "
                          f"of the extra alerts were actually right before deciding how far to "
                          f"tighten it back up.")
    args = ap.parse_args()

    daily_df = load_data("yfinance", ticker=args.ticker, period=args.period, interval="1d")

    chain = None
    try:
        chain = fetch_chain_yfinance(args.ticker, args.expiration)
    except Exception as e:
        print(f"[warn] couldn't fetch live options chain ({e}); gamma/vanna-charm/PCR/skew voters will sit out")

    vix_df = None
    try:
        vix_df = fetch_vix_term_structure_yfinance(period=args.period)
    except Exception as e:
        print(f"[warn] couldn't fetch VIX term structure ({e}); that voter will sit out")

    leader_data = _fetch_leader_data(args.period)

    intraday_today, intraday_history = None, None
    if args.webull_intraday_csv:
        try:
            minute_df = load_webull_intraday_csv(args.webull_intraday_csv, session=args.webull_session)
            intraday_today, intraday_history = split_latest_day(minute_df)
            print(f"[info] loaded {len(minute_df)} intraday bars from {args.webull_intraday_csv} "
                  f"({len(intraday_today)} today, {len(intraday_history)} history)")
        except Exception as e:
            print(f"[warn] couldn't load --webull-intraday-csv ({e}); candlestick/time-of-day voters will sit out")

    now = datetime.now()
    market_close_hour = 16
    hours_to_close = max(0.0, market_close_hour - (now.hour + now.minute / 60))

    inputs = SignalInputs(
        daily_df=daily_df,
        intraday_df=intraday_today,
        intraday_history=intraday_history,
        chain=chain,
        vix_df=vix_df,
        leader_data=leader_data or None,
        skew_store=SkewHistoryStore(),
        vanna_charm_store=VannaCharmHistoryStore(),
        today=date.today(),
        hours_to_close=hours_to_close,
    )

    scenario_store = ScenarioStore()
    adaptive_weights = AdaptiveWeights()
    signal = generate_signal(inputs, scenario_store=scenario_store, adaptive_weights=adaptive_weights,
                              signal_threshold=args.signal_threshold)

    print(f"Ticker: {args.ticker}")
    print(f"As of:  {now.isoformat(timespec='seconds')}")
    if args.signal_threshold != SIGNAL_THRESHOLD:
        print(f"Signal threshold: {args.signal_threshold} (loosened from the {SIGNAL_THRESHOLD} default)")
    print()
    print(signal.breakdown())
    print()
    print(f"Scenario fingerprint (for later record_outcome calls): {signal.fingerprint}")

    if signal.signal in ("CALL", "PUT"):
        # Prefer the live chain's spot/time-to-expiry when we have one;
        # fall back to the last daily close (T=1 day) so sizing still runs
        # even when the chain fetch failed -- an approximate premium is
        # more useful here than no sizing at all, and it's clearly labeled
        # as an approximation either way.
        if chain is not None:
            spot, t_entry, pricing_note = chain.spot, chain.time_to_expiry_years, ""
        else:
            spot, t_entry = float(daily_df["Close"].iloc[-1]), 1 / 365
            pricing_note = " (no live chain -- approximated from last daily close)"

        risk_cfg = RiskConfig(account_size=args.account_size)
        strike = nearest_strike(spot)
        entry_premium = bs_price(spot, strike, t_entry, 0.05, args.assumed_iv,
                                  "call" if signal.signal == "CALL" else "put")
        size = size_position(signal, entry_premium=entry_premium, cfg=risk_cfg)
        exit_plan = build_exit_plan(entry_premium=entry_premium, cfg=risk_cfg)

        print()
        print(f"Suggested entry premium (approx, {args.assumed_iv:.0%} IV fallback){pricing_note}: ${entry_premium:.2f}")
        print(f"Position size: {size.contracts} contract(s)  "
              f"(${size.dollar_risk:,.0f} risked, {size.dollar_risk_pct_of_account:.2%} of account)")
        for note in size.sizing_notes:
            print(f"  note: {note}")
        print(f"Stop loss:       ${exit_plan.stop_loss_price:.2f}")
        print(f"Profit target:   ${exit_plan.profit_target_price:.2f}")
        print(f"Trailing stop:   activates at ${exit_plan.trailing_stop_trigger_price:.2f}, "
              f"gives back at most {exit_plan.trailing_stop_giveback_pct:.0%} of peak gain")
        print(f"Hard exit:       {exit_plan.hard_exit_note}")

    print()
    print("This is a technical/quantitative signal, not investment advice.")
    print("Confirm with your own risk management and current options pricing")
    print("before placing any trade. 1DTE options can lose their full premium.")


if __name__ == "__main__":
    main()
