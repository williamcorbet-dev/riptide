"""
Volatility regime: VIX term structure (forward-looking, options-implied)
and put/call volume ratio (sentiment). Upgrades the original project's
backward-looking ATR-percentile filter with a forward-looking one.

VIX term structure (^VIX vs ^VIX3M, both free via yfinance, full history
available -- fully backtestable):
  contango (VIX < VIX3M):      "calm" state, the normal/default condition
  backwardation (VIX > VIX3M): stress state, historically precedes larger
                                 and more amplified moves -- gamma regimes
                                 can invert quickly in this state

Put/call volume ratio, computed directly from the live options chain
(chain.call_volume / chain.put_volume) rather than scraping an external
CBOE feed of uncertain reliability -- self-consistent with the other
chain-based modules, but live-only for the same reason as GEX/vanna/charm.
"""

from dataclasses import dataclass

import numpy as np
import pandas as pd

from voters import Vote


@dataclass
class TermStructureReading:
    vix: float
    vix3m: float
    ratio: float          # VIX / VIX3M
    regime: str            # "contango" or "backwardation"
    percentile: float      # where today's ratio sits vs its own trailing history


def fetch_vix_term_structure_yfinance(period: str = "2y") -> pd.DataFrame:
    """Requires internet + `pip install yfinance`. Returns a DataFrame with
    VIX, VIX3M, and their ratio, fully backtestable over the requested
    history."""
    import yfinance as yf

    vix = yf.download("^VIX", period=period, interval="1d", progress=False)["Close"]
    vix3m = yf.download("^VIX3M", period=period, interval="1d", progress=False)["Close"]
    df = pd.concat([vix, vix3m], axis=1, keys=["VIX", "VIX3M"]).dropna()
    df["ratio"] = df["VIX"] / df["VIX3M"]
    return df


def term_structure_reading(df: pd.DataFrame, lookback: int = 252) -> TermStructureReading:
    latest = df.iloc[-1]
    hist = df["ratio"].iloc[-lookback:]
    pct = float((hist < latest["ratio"]).mean())
    regime = "backwardation" if latest["ratio"] > 1.0 else "contango"
    return TermStructureReading(
        vix=float(latest["VIX"]), vix3m=float(latest["VIX3M"]),
        ratio=float(latest["ratio"]), regime=regime, percentile=pct,
    )


def vix_term_structure_vote(df: pd.DataFrame, lookback: int = 252) -> Vote:
    """This voter doesn't call direction on its own (term structure says
    'how much should everyone else's opinion be trusted', not 'up or
    down') -- direction is 0, but confidence acts as a DAMPENER the
    scenario engine applies to the rest of the ensemble: elevated
    backwardation means trust the other voters less, not more, since
    regimes are more likely to be actively inverting.
    """
    reading = term_structure_reading(df, lookback)

    if reading.regime == "backwardation":
        stress = min(1.0, (reading.ratio - 1.0) / 0.15)  # ratio of 1.15+ = max stress reading
        return Vote(
            name="vix_term_structure", direction=0.0, confidence=0.0,
            regime_tag="stress",
            detail={"ratio": reading.ratio, "percentile": reading.percentile,
                    "dampener": float(0.3 + 0.7 * stress),
                    "note": "backwardation: dampens ensemble confidence, does not vote direction"},
        )

    return Vote(
        name="vix_term_structure", direction=0.0, confidence=0.0,
        regime_tag="calm",
        detail={"ratio": reading.ratio, "percentile": reading.percentile, "dampener": 1.0},
    )


def put_call_ratio_vote(chain, extreme_low: float = 0.7, extreme_high: float = 1.3) -> Vote:
    """Contrarian sentiment read from the live chain's put/call VOLUME
    ratio (see gamma_positioning.ChainSnapshot). Elevated put volume
    (ratio high) at an extreme is read as excess fear -> mild contrarian
    bullish lean, and vice versa. Deliberately weak/low-confidence: this
    is a secondary confirmation signal, not a primary driver, since raw
    put/call ratio has a mixed empirical track record on its own.
    """
    call_vol = float(np.nansum(chain.call_volume))
    put_vol = float(np.nansum(chain.put_volume))
    if call_vol <= 0:
        return Vote(name="put_call_ratio", direction=0.0, confidence=0.0,
                     detail={"reason": "no call volume in chain snapshot"}, live_only=True)

    ratio = put_vol / call_vol
    return _put_call_ratio_vote_from_ratio(ratio, extreme_low, extreme_high)


def put_call_ratio_vote_from_ratio(ratio: float, extreme_low: float = 0.7,
                                    extreme_high: float = 1.3) -> Vote:
    """Same voter as `put_call_ratio_vote`, but for when a data source
    hands us the put/call ratio directly instead of raw per-contract
    volume (e.g. Alpha Vantage's REALTIME_PUT_CALL_RATIO endpoint, which
    is available on a free API key -- unlike a full options chain with
    open interest/greeks, which that provider gates behind its priciest
    premium tiers). Added 2026-08-18 so the put/call voter can fire live
    even on days we don't have a full chain snapshot to build GEX/vanna/
    charm from.
    """
    return _put_call_ratio_vote_from_ratio(float(ratio), extreme_low, extreme_high)


def _put_call_ratio_vote_from_ratio(ratio: float, extreme_low: float, extreme_high: float) -> Vote:
    if ratio >= extreme_high:
        conf = min(1.0, (ratio - extreme_high) / extreme_high + 0.3)
        return Vote(name="put_call_ratio", direction=0.4, confidence=conf,
                     regime_tag="extreme_fear",
                     detail={"put_call_ratio": ratio}, live_only=True)
    if ratio <= extreme_low:
        conf = min(1.0, (extreme_low - ratio) / extreme_low + 0.3)
        return Vote(name="put_call_ratio", direction=-0.4, confidence=conf,
                     regime_tag="extreme_complacency",
                     detail={"put_call_ratio": ratio}, live_only=True)

    return Vote(name="put_call_ratio", direction=0.0, confidence=0.0,
                 detail={"put_call_ratio": ratio}, live_only=True)
