"""
From-scratch 2-state Gaussian Hidden Markov Model for regime detection --
a statistical (data-driven) regime read, independent of the mechanistic
gamma-positioning regime and the mathematical Hurst-exponent regime. All
three are combined in scenario_engine.py; agreement across independently-
derived methods is treated as materially higher-conviction than any one.

Implemented with plain numpy (no hmmlearn dependency) via the standard
Baum-Welch / EM algorithm on a 2-state Gaussian HMM over daily log returns.
Fully backtestable -- needs only historical price data.
"""

from dataclasses import dataclass

import numpy as np
import pandas as pd

from voters import Vote


@dataclass
class HMMParams:
    means: np.ndarray       # (2,) per-state mean return
    stds: np.ndarray        # (2,) per-state return std
    trans: np.ndarray       # (2,2) transition matrix
    start: np.ndarray       # (2,) initial state distribution


def _gaussian_pdf(x, mean, std):
    std = max(std, 1e-8)
    return np.exp(-0.5 * ((x - mean) / std) ** 2) / (std * np.sqrt(2 * np.pi))


def _forward_backward(obs: np.ndarray, params: HMMParams):
    n = len(obs)
    B = np.column_stack([_gaussian_pdf(obs, params.means[s], params.stds[s]) for s in range(2)])
    B = np.clip(B, 1e-300, None)

    alpha = np.zeros((n, 2))
    c = np.zeros(n)  # scaling factors for numerical stability
    alpha[0] = params.start * B[0]
    c[0] = alpha[0].sum()
    alpha[0] /= c[0]
    for t in range(1, n):
        alpha[t] = (alpha[t - 1] @ params.trans) * B[t]
        c[t] = alpha[t].sum()
        alpha[t] /= max(c[t], 1e-300)

    beta = np.zeros((n, 2))
    beta[-1] = 1.0
    for t in range(n - 2, -1, -1):
        beta[t] = (params.trans @ (B[t + 1] * beta[t + 1])) / max(c[t + 1], 1e-300)

    gamma = alpha * beta
    gamma /= gamma.sum(axis=1, keepdims=True)

    xi = np.zeros((n - 1, 2, 2))
    for t in range(n - 1):
        denom = (alpha[t] @ params.trans * B[t + 1]) @ beta[t + 1]
        for i in range(2):
            xi[t, i] = alpha[t, i] * params.trans[i] * B[t + 1] * beta[t + 1]
        xi[t] /= max(denom, 1e-300)

    log_likelihood = np.sum(np.log(np.clip(c, 1e-300, None)))
    return gamma, xi, log_likelihood


def fit_hmm(returns: np.ndarray, n_iter: int = 100, tol: float = 1e-6,
            seed: int = 0) -> HMMParams:
    """Fits a 2-state Gaussian HMM via Baum-Welch EM. State 0 is relabeled
    to be the lower-variance ("calm") state and state 1 the higher-
    variance ("stressed") state after fitting, so downstream code can rely
    on a consistent ordering."""
    rng = np.random.default_rng(seed)
    obs = np.asarray(returns, dtype=float)
    obs = obs[~np.isnan(obs)]

    mean_all, std_all = obs.mean(), obs.std()
    params = HMMParams(
        means=np.array([mean_all - 0.3 * std_all, mean_all + 0.3 * std_all]),
        stds=np.array([std_all * 0.7, std_all * 1.4]),
        trans=np.array([[0.95, 0.05], [0.10, 0.90]]),
        start=np.array([0.5, 0.5]),
    )

    prev_ll = -np.inf
    for _ in range(n_iter):
        gamma, xi, ll = _forward_backward(obs, params)

        start = gamma[0]
        trans = xi.sum(axis=0)
        trans /= trans.sum(axis=1, keepdims=True)

        weights = gamma  # (n, 2)
        means = (weights * obs[:, None]).sum(axis=0) / weights.sum(axis=0)
        variances = (weights * (obs[:, None] - means) ** 2).sum(axis=0) / weights.sum(axis=0)
        stds = np.sqrt(np.clip(variances, 1e-10, None))

        params = HMMParams(means=means, stds=stds, trans=trans, start=start)

        if abs(ll - prev_ll) < tol:
            break
        prev_ll = ll

    # Relabel so state 0 = lower variance ("calm"), state 1 = higher variance ("stressed")
    if params.stds[0] > params.stds[1]:
        order = [1, 0]
        params = HMMParams(
            means=params.means[order], stds=params.stds[order],
            trans=params.trans[np.ix_(order, order)], start=params.start[order],
        )

    return params


def decode_states(returns: np.ndarray, params: HMMParams) -> np.ndarray:
    """Returns the smoothed posterior probability of the 'stressed' state
    (state 1) for each observation."""
    gamma, _, _ = _forward_backward(np.asarray(returns, dtype=float), params)
    return gamma[:, 1]


def hmm_vote(close: pd.Series, train_window: int = 250, trend_lookback: int = 5) -> Vote:
    """Fits the HMM on trailing daily log returns, reads the current
    state's probability, and turns it into a vote:
      - "calm" state (state 0) dominant -> mild trend-following lean,
        confidence scaled by how calm/confident the state read is
      - "stressed" state (state 1) dominant -> direction follows the very
        recent move (stressed regimes tend to see continuation of
        whatever's already happening, per the gamma-negative logic this
        state usually coincides with), but flagged as higher-risk
    """
    log_ret = np.log(close / close.shift(1)).dropna()
    if len(log_ret) < max(60, train_window // 3):
        return Vote(name="hmm_regime", direction=0.0, confidence=0.0,
                     detail={"reason": "insufficient history to fit HMM"})

    window = log_ret.iloc[-train_window:] if len(log_ret) > train_window else log_ret
    params = fit_hmm(window.to_numpy())
    stressed_prob = decode_states(window.to_numpy(), params)[-1]

    recent_ret = np.log(close.iloc[-1] / close.iloc[-trend_lookback])
    direction = float(np.sign(recent_ret)) * (0.5 if stressed_prob < 0.5 else 1.0)
    confidence = float(abs(stressed_prob - 0.5) * 2)  # 0 at p=0.5 (max uncertainty), 1 at p=0 or 1

    regime_tag = "stressed" if stressed_prob >= 0.5 else "calm"

    return Vote(
        name="hmm_regime",
        direction=direction,
        confidence=confidence,
        regime_tag=regime_tag,
        detail={
            "stressed_state_prob": float(stressed_prob),
            "state_means": params.means.tolist(),
            "state_stds": params.stds.tolist(),
        },
    )
