"""
Python port of a Pine Script indicator Will shared (2026-08-20): an
adaptive SuperTrend that, instead of a fixed ATR multiplier, separately
learns -- per trend direction -- the Nth-percentile (default 85th)
pullback size actually observed in past up/down trends on THIS symbol,
and uses that learned distance as the trailing-stop line. It also flags
"bounce reactions": price dipping into the zone between that trailing
line and a thinner inner line, then closing back out toward price,
confirming the trend is continuing rather than breaking.

This is a faithful line-by-line port of the Pine script's actual
computation (band ratchet, trend state machine, rolling percentile
learning, EMA-smoothed factor, bounce-zone detection) -- not a
reimplementation from the general "SuperTrend" concept. The visual-only
parts of the original (the pullback-map histogram, the dashboard table,
bar coloring, alertcondition wiring) are Pine/TradingView-chart-specific
and have no meaning outside that UI, so they're intentionally left out
here; every line that feeds a `plot()`, `label`, `box`, or `table` used
for on-chart display only was skipped, everything that feeds a
decision was kept.

Faithfulness notes (see README this file's git history / daily_reviews.md
2026-08-20 for the sanity checks run against this port):
  - `ta.atr()` == this project's existing `indicator.atr()` (Wilder/RMA
    smoothing) -- reused directly, not reimplemented.
  - `ta.tr(true)` (gap-aware True Range) is recomputed locally as
    `_true_range()` since indicator.atr() doesn't expose it separately.
  - `arrayPercentile()`'s sort + linear-interpolation-between-ranks is
    exactly numpy's default (`interpolation="linear"`) percentile --
    used directly via `np.percentile`.
  - Sample ordering matches the original exactly: at bar t, the learned
    factor is computed from samples accumulated through bar t-1 (the
    Pine script computes the percentile BEFORE pushing bar t's own
    excursion into the array), so there is no lookahead -- bar t's own
    pullback never influences bar t's own trailing-line placement.
  - `barstate.isconfirmed` (Pine's "this bar has closed") is dropped: a
    point-in-time replay here only ever sees already-closed bars by
    construction, so it's always true in this context.
"""

from collections import deque
from dataclasses import dataclass

import numpy as np
import pandas as pd

from candlestick_patterns import resample_ohlc
from indicator import atr as wilder_atr
from voters import Vote, neutral_vote


@dataclass
class AdaptiveSupertrendConfig:
    atr_length: int = 10
    fallback_factor: float = 3.0
    quantile: float = 85.0
    sample_length: int = 150
    minimum_samples: int = 25
    factor_smoothing: int = 5
    minimum_factor: float = 0.75
    maximum_factor: float = 6.0


# Tuned as a voter for THIS project's timeframe (2026-08-20, daily_reviews.md):
# the Pine script's own defaults above are presumably right for whatever
# timeframe its author charts on, but replayed on raw 1-min SPY bars they
# whipsaw badly -- 11-15 trend flips and a "bounce reaction" on 5-8% of ALL
# bars, consistently across 4 real trading days. Two changes, checked against
# the same 4 days before adopting: (1) resample to 5-min bars first, the same
# fix `support_resistance.py`/`candlestick_patterns.py` already use for the
# identical "too much noise below ~3min" reason -- this alone cut flips from
# ~12-15/day to ~2-5/day; (2) raise minimum_factor 0.75->2.0 and
# factor_smoothing 5->10, which combined with the resample gets to ~1-2
# flips/day and ~2-6 bounce reactions/day -- a reasonable, non-degenerate
# rate, in the same ballpark as support_resistance's own signal frequency.
VOTER_RESAMPLE_RULE = "5min"
VOTER_CONFIG = AdaptiveSupertrendConfig(minimum_factor=2.0, factor_smoothing=10)
MIN_RESAMPLED_BARS = 20  # ~100 minutes of 5-min bars before trusting a read at all


def _true_range(df: pd.DataFrame) -> pd.Series:
    high, low, close = df["High"], df["Low"], df["Close"]
    prev_close = close.shift(1)
    return pd.concat([(high - low), (high - prev_close).abs(), (low - prev_close).abs()], axis=1).max(axis=1)


def _percentile(samples: deque, pct: float, fallback: float) -> float:
    if len(samples) == 0:
        return fallback
    return float(np.percentile(np.asarray(samples, dtype=float), pct, method="linear"))


def _clamp(value: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, value))


def compute_adaptive_supertrend(df: pd.DataFrame, cfg: AdaptiveSupertrendConfig = None) -> pd.DataFrame:
    """`df` needs Open/High/Low/Close (Volume unused). Returns a copy of
    `df` with the decision-relevant columns added: trend (1/-1/0),
    super_trend (the active trailing line), bullish_factor/bearish_factor
    (the learned ATR multiples), bullish_sample_confidence/
    bearish_sample_confidence (0..1, ramps to 1.0 at minimum_samples),
    bullish_shift/bearish_shift (trend just flipped this bar),
    bullish_bounce_reaction/bearish_bounce_reaction (dipped into the
    bounce zone and closed back out this bar)."""
    cfg = cfg or AdaptiveSupertrendConfig()
    n = len(df)
    source = ((df["High"] + df["Low"]) / 2).to_numpy()  # hl2, matches sourceInput default
    high = df["High"].to_numpy()
    low = df["Low"].to_numpy()
    close = df["Close"].to_numpy()

    atr_vals = wilder_atr(df, cfg.atr_length).to_numpy()
    bounce_band_width = _true_range(df).rolling(cfg.atr_length).mean().to_numpy()  # ta.sma(ta.tr(true), len)

    bullish_samples = deque(maxlen=cfg.sample_length)
    bearish_samples = deque(maxlen=cfg.sample_length)
    required_samples = max(1, min(cfg.minimum_samples, cfg.sample_length))

    lower_band = np.full(n, np.nan)
    upper_band = np.full(n, np.nan)
    trend = np.zeros(n, dtype=int)
    super_trend = np.full(n, np.nan)
    trend_extreme = np.full(n, np.nan)
    bullish_factor = np.full(n, np.nan)
    bearish_factor = np.full(n, np.nan)
    bullish_conf = np.full(n, np.nan)
    bearish_conf = np.full(n, np.nan)
    bullish_shift = np.zeros(n, dtype=bool)
    bearish_shift = np.zeros(n, dtype=bool)
    bullish_bounce_line = np.full(n, np.nan)
    bearish_bounce_line = np.full(n, np.nan)
    bullish_bounce_reaction = np.zeros(n, dtype=bool)
    bearish_bounce_reaction = np.zeros(n, dtype=bool)

    bullish_factor_ema = None
    bearish_factor_ema = None
    ema_alpha = 2.0 / (cfg.factor_smoothing + 1)

    for t in range(n):
        valid_atr = not np.isnan(atr_vals[t]) and atr_vals[t] > 0.0

        # --- learned factor for THIS bar, from samples through bar t-1 ---
        bullish_q = _percentile(bullish_samples, cfg.quantile, np.nan)
        bearish_q = _percentile(bearish_samples, cfg.quantile, np.nan)
        b_conf = min(len(bullish_samples) / required_samples, 1.0)
        s_conf = min(len(bearish_samples) / required_samples, 1.0)
        bullish_conf[t] = b_conf
        bearish_conf[t] = s_conf

        bullish_obs = _clamp(cfg.fallback_factor if np.isnan(bullish_q) else bullish_q,
                              cfg.minimum_factor, cfg.maximum_factor)
        bearish_obs = _clamp(cfg.fallback_factor if np.isnan(bearish_q) else bearish_q,
                              cfg.minimum_factor, cfg.maximum_factor)
        bullish_target = cfg.fallback_factor * (1 - b_conf) + bullish_obs * b_conf
        bearish_target = cfg.fallback_factor * (1 - s_conf) + bearish_obs * s_conf

        bullish_factor_ema = bullish_target if bullish_factor_ema is None else \
            ema_alpha * bullish_target + (1 - ema_alpha) * bullish_factor_ema
        bearish_factor_ema = bearish_target if bearish_factor_ema is None else \
            ema_alpha * bearish_target + (1 - ema_alpha) * bearish_factor_ema
        bullish_factor[t] = bullish_factor_ema
        bearish_factor[t] = bearish_factor_ema

        # --- raw bands + ratchet ---
        if valid_atr:
            raw_lower = source[t] - bullish_factor_ema * atr_vals[t]
            raw_upper = source[t] + bearish_factor_ema * atr_vals[t]
        else:
            raw_lower = raw_upper = np.nan

        prev_lower = lower_band[t - 1] if t > 0 else np.nan
        prev_upper = upper_band[t - 1] if t > 0 else np.nan
        prev_close = close[t - 1] if t > 0 else np.nan

        if np.isnan(prev_lower):
            lower_band[t] = raw_lower
        elif not np.isnan(raw_lower) and (raw_lower > prev_lower or prev_close < prev_lower):
            lower_band[t] = raw_lower
        else:
            lower_band[t] = prev_lower

        if np.isnan(prev_upper):
            upper_band[t] = raw_upper
        elif not np.isnan(raw_upper) and (raw_upper < prev_upper or prev_close > prev_upper):
            upper_band[t] = raw_upper
        else:
            upper_band[t] = prev_upper

        # --- trend state machine ---
        prev_trend = trend[t - 1] if t > 0 else 0
        if not valid_atr:
            trend[t] = prev_trend
        elif prev_trend == 0:
            trend[t] = 1 if close[t] >= source[t] else -1
        elif prev_trend == 1:
            trend[t] = -1 if close[t] < lower_band[t] else 1
        else:
            trend[t] = 1 if close[t] > upper_band[t] else -1

        super_trend[t] = lower_band[t] if trend[t] == 1 else (upper_band[t] if trend[t] == -1 else np.nan)
        bullish_shift[t] = trend[t] == 1 and prev_trend == -1
        bearish_shift[t] = trend[t] == -1 and prev_trend == 1

        # --- trend extreme (running high/low since last flip) ---
        prev_extreme = trend_extreme[t - 1] if t > 0 else np.nan
        if trend[t] == 0:
            trend_extreme[t] = np.nan
        elif trend[t] != prev_trend or np.isnan(prev_extreme):
            trend_extreme[t] = high[t] if trend[t] == 1 else low[t]
        else:
            trend_extreme[t] = max(prev_extreme, high[t]) if trend[t] == 1 else min(prev_extreme, low[t])

        # --- this bar's adverse excursion (not yet visible to this bar's own factor) ---
        bullish_excursion = max(trend_extreme[t] - low[t], 0.0) / atr_vals[t] \
            if valid_atr and trend[t] == 1 else np.nan
        bearish_excursion = max(high[t] - trend_extreme[t], 0.0) / atr_vals[t] \
            if valid_atr and trend[t] == -1 else np.nan

        established_bullish = trend[t] == 1 and prev_trend == 1
        established_bearish = trend[t] == -1 and prev_trend == -1
        if established_bullish and not np.isnan(bullish_excursion):
            bullish_samples.append(bullish_excursion)
        if established_bearish and not np.isnan(bearish_excursion):
            bearish_samples.append(bearish_excursion)

        # --- bounce zone + reaction (needs t-1's bounce line too) ---
        bbw = bounce_band_width[t]
        if trend[t] == 1 and not np.isnan(bbw):
            bullish_bounce_line[t] = max(super_trend[t], min(super_trend[t] + bbw, source[t]))
        if trend[t] == -1 and not np.isnan(bbw):
            bearish_bounce_line[t] = min(super_trend[t], max(super_trend[t] - bbw, source[t]))

        if t > 0 and established_bullish and not np.isnan(bullish_bounce_line[t]) and not np.isnan(bullish_bounce_line[t - 1]):
            bullish_bounce_reaction[t] = (close[t] > bullish_bounce_line[t]
                                           and close[t - 1] <= bullish_bounce_line[t - 1]
                                           and close[t - 1] >= lower_band[t - 1])
        if t > 0 and established_bearish and not np.isnan(bearish_bounce_line[t]) and not np.isnan(bearish_bounce_line[t - 1]):
            bearish_bounce_reaction[t] = (close[t] < bearish_bounce_line[t]
                                           and close[t - 1] >= bearish_bounce_line[t - 1]
                                           and close[t - 1] <= upper_band[t - 1])

    out = df.copy()
    out["trend"] = trend
    out["super_trend"] = super_trend
    out["lower_band"] = lower_band
    out["upper_band"] = upper_band
    out["bullish_factor"] = bullish_factor
    out["bearish_factor"] = bearish_factor
    out["bullish_sample_confidence"] = bullish_conf
    out["bearish_sample_confidence"] = bearish_conf
    out["bullish_shift"] = bullish_shift
    out["bearish_shift"] = bearish_shift
    out["bullish_bounce_reaction"] = bullish_bounce_reaction
    out["bearish_bounce_reaction"] = bearish_bounce_reaction
    return out


def adaptive_supertrend_vote(intraday_df: pd.DataFrame, cfg: AdaptiveSupertrendConfig = None,
                              resample_rule: str = VOTER_RESAMPLE_RULE) -> Vote:
    """This is a trend-CONFIRMING voter, not a reversal-catcher like
    vwap_reversion/mfi_divergence -- it says "a trend is established/
    continuing" or "a trend just flipped," never "this move is
    exhausted." Confidence is deliberately tiered by how much the read
    is actually saying: a fresh trend flip (survived the full learned-
    pullback-room threshold, not just a tick) is the strongest read; a
    bounce reaction (a real but shallow dip that closed back toward the
    trend) is next; a bar that's simply still in an established trend
    with nothing new happening is the weakest, further scaled by how
    much the model has actually learned yet (`*_sample_confidence`)."""
    if intraday_df is None or len(intraday_df) < 5:
        return neutral_vote("adaptive_supertrend", "not enough intraday bars yet")

    resampled = resample_ohlc(intraday_df, resample_rule)
    if len(resampled) < MIN_RESAMPLED_BARS:
        return neutral_vote("adaptive_supertrend", f"not enough {resample_rule} bars yet to trust the trailing line")

    out = compute_adaptive_supertrend(resampled, cfg or VOTER_CONFIG)
    last = out.iloc[-1]
    trend = int(last["trend"])
    detail = {
        "super_trend": None if pd.isna(last["super_trend"]) else round(float(last["super_trend"]), 4),
        "bullish_factor": round(float(last["bullish_factor"]), 3) if not pd.isna(last["bullish_factor"]) else None,
        "bearish_factor": round(float(last["bearish_factor"]), 3) if not pd.isna(last["bearish_factor"]) else None,
        "resample_rule": resample_rule,
    }

    if trend == 0:
        return neutral_vote("adaptive_supertrend", "no valid trailing line yet (ATR not established)")

    active_sample_conf = float(last["bullish_sample_confidence"] if trend == 1 else last["bearish_sample_confidence"])

    if last["bullish_shift"] or last["bearish_shift"]:
        return Vote(name="adaptive_supertrend", direction=float(trend), confidence=0.55,
                    regime_tag="bullish_shift" if trend == 1 else "bearish_shift", detail=detail)
    if last["bullish_bounce_reaction"] or last["bearish_bounce_reaction"]:
        return Vote(name="adaptive_supertrend", direction=float(trend), confidence=0.45,
                    regime_tag="bullish_bounce" if trend == 1 else "bearish_bounce", detail=detail)

    confidence = min(0.35, 0.1 + 0.25 * active_sample_conf)
    return Vote(name="adaptive_supertrend", direction=float(trend), confidence=confidence,
                regime_tag="uptrend" if trend == 1 else "downtrend", detail=detail)
