"""
End-of-day calibration review.

The workflow this supports: run the system LOOSE for a while (a lower
`--signal-threshold` so it alerts more often), then at day's end run this
tool to grade every alert it actually fired against what price did
afterward, and see which voters were driving the wrong ones -- so you
have concrete evidence for tightening `--signal-threshold` back down,
instead of guessing.

This does not change anything persistent. It re-runs intraday_replay.py's
point-in-time replay (same no-lookahead guarantee -- only bars up to each
checkpoint are visible) at whatever `--signal-threshold` you pass, grades
the result, and prints/writes a breakdown. It never touches state/.

Usage:
    # widen the net -- e.g. half the live default of 0.35 -- and see what
    # would have fired plus whether it would have been right:
    python daily_review.py --webull-csv data/SPY_Webull_1min_20260706_to_20260814.csv \
        --date 2026-08-14 --interval 15 --signal-threshold 0.20

Grading, honestly stated: a fired CALL/PUT is graded "correct" if price
moved in the signaled direction by the day's close (`correct_by_close`)
and, separately, over just the next 30 minutes (`correct_by_30m`) for a
faster read. Flat/no-move outcomes count as incorrect for that alert
(there's no "close enough" fudge). Neither grading column feeds back into
anything -- this is a read-only research pass over one day's replay.
"""

import argparse

import numpy as np
import pandas as pd

from webull_data import load_webull_intraday_csv
from intraday_replay import replay_day, replay_day_votes
from scenario_engine import SIGNAL_THRESHOLD

MIN_VOTER_CONFIDENCE = 0.05  # ignore near-zero "no opinion" votes when building the breakdown


def grade_signals(replay_df: pd.DataFrame) -> pd.DataFrame:
    """Adds `correct_by_close` / `correct_by_30m` boolean columns (NaN
    where the signal was NONE, or where price_+30m wasn't available e.g.
    the last checkpoint of the day) to a replay_day() DataFrame."""
    df = replay_df.copy()
    # object dtype so a column can hold a mix of True/False/NaN -- a plain
    # float64 column raises on assigning bool values in recent pandas.
    df["correct_by_close"] = pd.Series(np.nan, index=df.index, dtype=object)
    df["correct_by_30m"] = pd.Series(np.nan, index=df.index, dtype=object)

    fired = df["signal"].isin(["CALL", "PUT"])
    if not fired.any():
        return df

    sign = df["signal"].map({"CALL": 1, "PUT": -1})
    close_move_sign = np.sign(df["day_close"] - df["price"])
    df.loc[fired, "correct_by_close"] = (close_move_sign[fired] == sign[fired])

    has_30m = fired & df["price_+30m"].notna()
    m30_move_sign = np.sign(df["price_+30m"] - df["price"])
    df.loc[has_30m, "correct_by_30m"] = (m30_move_sign[has_30m] == sign[has_30m])

    return df


def voter_breakdown(graded_df: pd.DataFrame, votes_df: pd.DataFrame,
                     correctness_col: str = "correct_by_close",
                     min_confidence: float = MIN_VOTER_CONFIDENCE) -> pd.DataFrame:
    """Long-format table: one row per (fired checkpoint, voter that had a
    real opinion at that checkpoint), noting whether that voter agreed
    with the direction the ensemble actually fired, and whether that
    fired signal turned out right. This is the raw material for deciding
    which voters to trust less when tightening the threshold back up."""
    fired = graded_df[graded_df["signal"].isin(["CALL", "PUT"]) & graded_df[correctness_col].notna()]
    rows = []
    for t, row in fired.iterrows():
        sig_sign = 1 if row["signal"] == "CALL" else -1
        correct = bool(row[correctness_col])
        vt = votes_df[votes_df["time"] == t]
        for _, v in vt.iterrows():
            if v["confidence"] < min_confidence:
                continue
            voter_sign = 1 if v["direction"] > 0 else (-1 if v["direction"] < 0 else 0)
            rows.append({
                "time": t, "signal": row["signal"], "voter": v["voter"],
                "voter_direction": v["direction"], "voter_confidence": v["confidence"],
                "voter_regime_tag": v["regime_tag"],
                "agreed_with_fired_signal": voter_sign == sig_sign,
                "fired_signal_was_correct": correct,
            })
    return pd.DataFrame(rows)


def summarize_voter_reliability(breakdown_df: pd.DataFrame) -> pd.DataFrame:
    """Per voter: how many times it agreed with a fired signal that turned
    out right vs. wrong, and how many times it actually DISagreed with a
    signal that turned out wrong (i.e. it was right and got outvoted --
    the dilution pattern documented in README.md's Aug 14 case study).
    Sorted worst-first (most times agreeing with a wrong call) so the
    voters most worth distrusting when tightening show up at the top."""
    if breakdown_df.empty:
        return pd.DataFrame(columns=["agreed_and_right", "agreed_and_wrong",
                                      "disagreed_but_signal_wrong", "agree_accuracy"])

    rows = []
    for voter, g in breakdown_df.groupby("voter"):
        agreed = g[g["agreed_with_fired_signal"]]
        disagreed = g[~g["agreed_with_fired_signal"]]
        agreed_and_right = int(agreed["fired_signal_was_correct"].sum())
        agreed_and_wrong = int((~agreed["fired_signal_was_correct"]).sum())
        disagreed_but_signal_wrong = int((~disagreed["fired_signal_was_correct"]).sum())
        n_agreed = agreed_and_right + agreed_and_wrong
        rows.append({
            "voter": voter,
            "agreed_and_right": agreed_and_right,
            "agreed_and_wrong": agreed_and_wrong,
            "disagreed_but_signal_wrong": disagreed_but_signal_wrong,
            "agree_accuracy": round(agreed_and_right / n_agreed, 3) if n_agreed else np.nan,
        })
    out = pd.DataFrame(rows).set_index("voter")
    return out.sort_values("agreed_and_wrong", ascending=False)


def review_day(minute_df: pd.DataFrame, target_date, interval_minutes: int = 15,
               signal_threshold: float = SIGNAL_THRESHOLD, account_size: float = 25000.0, chain=None,
               daily_df: pd.DataFrame = None):
    """Runs the full loosen -> replay -> grade -> break-down pipeline for
    one day. `chain`: optional real ChainSnapshot for this day (see
    historical_chain.py) -- passed straight through to replay_day() so
    the gamma/vanna-charm/put-call-ratio/skew voters can be part of what
    gets graded. `daily_df`: optional real long daily-history DataFrame,
    the same kind live checkpoints use (e.g. ~750 days of Webull D bars)
    -- passed straight through to replay_day()/replay_day_votes() so this
    review reconstructs exactly what live saw instead of the old fallback
    of resampling a few weeks out of the intraday file itself (see
    daily_reviews.md's 2026-08-17 entry, proposal #1, and
    intraday_replay.py's `_resolve_daily_df`). Omit to keep the old
    resampled-fallback behavior. Returns (graded_replay_df, votes_df,
    breakdown_df, reliability_df)."""
    replay = replay_day(minute_df, target_date, interval_minutes=interval_minutes,
                         account_size=account_size, signal_threshold=signal_threshold, chain=chain,
                         daily_df=daily_df)
    votes = replay_day_votes(minute_df, target_date, interval_minutes=interval_minutes,
                              signal_threshold=signal_threshold, chain=chain, daily_df=daily_df)
    graded = grade_signals(replay)
    breakdown = voter_breakdown(graded, votes)
    reliability = summarize_voter_reliability(breakdown)
    return graded, votes, breakdown, reliability


def print_review(graded_df: pd.DataFrame, reliability_df: pd.DataFrame, signal_threshold: float):
    fired = graded_df[graded_df["signal"].isin(["CALL", "PUT"])]
    n_fired = len(fired)
    print(f"Signal threshold used: {signal_threshold}  ({n_fired} of {len(graded_df)} "
          f"checkpoints fired a CALL/PUT)")
    if n_fired == 0:
        print("No alerts fired at this threshold -- loosen --signal-threshold further to get any "
              "data to review.")
        return

    graded_fired = fired[fired["correct_by_close"].notna()].copy()
    # object dtype (see grade_signals) holds real Python bools once notna()
    # has dropped the NaNs -- cast to a proper bool Series so `~`/sum() do
    # boolean logic instead of bitwise-inverting Python bools as ints.
    graded_fired["correct_by_close"] = graded_fired["correct_by_close"].astype(bool)
    n_right = int(graded_fired["correct_by_close"].sum())
    n_wrong = len(graded_fired) - n_right
    win_rate = n_right / len(graded_fired) if len(graded_fired) else float("nan")
    print(f"Graded by day close: {n_right} right, {n_wrong} wrong ({win_rate:.1%} win rate)")

    print("\nWrong alerts (worth looking at first):")
    wrong = graded_fired[~graded_fired["correct_by_close"]]
    if wrong.empty:
        print("  (none)")
    else:
        print(wrong[["price", "signal", "direction", "confidence", "day_close"]].to_string())

    if not reliability_df.empty:
        print("\nPer-voter reliability across every fired alert (sorted worst-first):")
        print(reliability_df.to_string())
        print("\n  agreed_and_wrong: this voter agreed with the direction the ensemble fired, and")
        print("    it turned out wrong -- a high count here is a candidate to trust less.")
        print("  disagreed_but_signal_wrong: this voter disagreed and would have been right --")
        print("    a high count here means it's being outvoted when it shouldn't be (the same")
        print("    dilution pattern documented in README.md's 2026-08-14 case study).")


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--webull-csv", required=True)
    ap.add_argument("--date", required=True, help="YYYY-MM-DD, must be a day present in the CSV")
    ap.add_argument("--interval", type=int, default=15, help="minutes between checkpoints")
    ap.add_argument("--account-size", type=float, default=25000.0)
    ap.add_argument("--signal-threshold", type=float, default=round(SIGNAL_THRESHOLD / 2, 2),
                     help=f"defaults to half the live value ({SIGNAL_THRESHOLD}) to demonstrate "
                          f"widening the net -- pass your own to try other levels")
    ap.add_argument("--out-prefix", default=None, help="defaults to the date, e.g. 2026-08-14")
    ap.add_argument("--chain-dir", default=None,
                     help="a folder containing this day's Greek_YYYYMMDD_OData*.csv files (see "
                          "historical_chain.py) -- unlocks gamma/vanna-charm/put-call-ratio/skew "
                          "for whichever day is found there instead of them sitting out")
    ap.add_argument("--chain-symbol", default="SPY", help="ticker to pull out of --chain-dir's files")
    ap.add_argument("--daily-csv", default=None,
                     help="a CSV of real long daily OHLCV history (e.g. exported Webull D bars or "
                          "Nasdaq.com's export format, same as backtest.py --source csv) -- when "
                          "given, technical/hurst/hmm_regime are graded against the same real "
                          "history live checkpoints use, instead of the old fallback of resampling "
                          "just the days present in --webull-csv (see daily_reviews.md's "
                          "2026-08-17 entry, proposal #1, for why this matters)")
    args = ap.parse_args()

    minute_df = load_webull_intraday_csv(args.webull_csv)
    prefix = args.out_prefix or args.date

    chain = None
    if args.chain_dir:
        from historical_chain import build_chain_lookup_from_dir
        lookup = build_chain_lookup_from_dir(args.chain_dir, symbol=args.chain_symbol)
        chain = lookup.get(pd.Timestamp(args.date).date())
        if chain is None:
            print(f"[warn] no chain found for {args.date} in {args.chain_dir} -- continuing without one")

    daily_df = None
    if args.daily_csv:
        from backtest import load_data
        daily_df = load_data("csv", csv_path=args.daily_csv)
        print(f"[info] using real daily history from {args.daily_csv} ({len(daily_df)} days) "
              f"instead of resampling {args.webull_csv}")

    graded, votes, breakdown, reliability = review_day(
        minute_df, args.date, interval_minutes=args.interval,
        signal_threshold=args.signal_threshold, account_size=args.account_size, chain=chain,
        daily_df=daily_df,
    )

    graded.to_csv(f"{prefix}_review.csv")
    votes.to_csv(f"{prefix}_review_votes.csv", index=False)
    if not breakdown.empty:
        breakdown.to_csv(f"{prefix}_review_breakdown.csv", index=False)
    if not reliability.empty:
        reliability.to_csv(f"{prefix}_review_reliability.csv")

    print_review(graded, reliability, args.signal_threshold)
    print(f"\nWrote {prefix}_review.csv, {prefix}_review_votes.csv"
          + (f", {prefix}_review_breakdown.csv" if not breakdown.empty else "")
          + (f", {prefix}_review_reliability.csv" if not reliability.empty else ""))


if __name__ == "__main__":
    main()
