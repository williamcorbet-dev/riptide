# Daily indicator reviews

Dated log of what the live ensemble called, what actually happened, and any
adjustments made — automatic (voter-weight self-tuning via
`scenario_engine.record_outcome`) or applied-by-hand (structural/threshold
changes to the code, always logged here with the reasoning).

## 2026-08-17

**Mid-day finding (applied ~2:45pm ET, before market close):** Will noticed
SPY had been trending down most of the day and never got back above its own
intraday 21-EMA, yet the composite signal read CALL (confidence rising
0.667 -> 0.685 -> 0.780) through the 9:37am/10:30am/12:30pm checkpoints, only
drifting to NONE at 2:30pm as the drop got large enough for other voters to
react. That's a real miss, not noise, and it traced to a specific cause:

- `technical_vote` (the classic EMA/MACD/RSI/VWAP score — the "original"
  indicator) runs on `daily_df`, i.e. multi-week daily bars, not today's
  intraday chart. It was never going to see "price is below the 21-EMA
  today" because it isn't looking at today's bars in the first place.
- That same daily-bar technical voter had **zero confidence all day**
  (`conf=0.00` at every checkpoint) — gated to 0 by the ATR volatility-regime
  filter (`atr_low_pct`/`atr_high_pct` in `indicator.py`), so even its
  (wrong-timeframe) opinion didn't matter.
- What was actually driving CALL all morning: `hurst` (dir=+1.00,
  conf=0.30, regime=trending) and `hmm_regime` (dir=+0.50, conf=0.60,
  regime=calm) — both computed from `daily_df`, both structurally blind to
  today's intraday move, since neither takes intraday bars as input at all.
- Confirmed directly: on today's actual 1-min bars, price was below its own
  intraday 21-EMA for 206 of 302 bars so far (68%).

**Applied fix:** added `intraday_technical_vote()` to `composite_signal.py`
— the identical trend/momentum/location scoring formula as `technical_vote`,
but run on `inputs.intraday_df` (today's own bars) instead of `daily_df`, so
EMA(9)/EMA(21)/EMA(50) are today's intraday EMAs (a 21-bar EMA on 1-min bars
*is* the 21-EMA a discretionary trader is watching). Wired into
`generate_signal()` alongside the other intraday-reactive voters
(candlesticks, support/resistance). Its volatility-regime gate is loosened
(not removed on the daily voter, only this one) since the daily gate's
100-day lookback/percentile band don't translate to a 1-minute series;
needs ~60 bars (~1hr into the session) before it has a real opinion, same
spirit as the existing "not enough history yet" pattern used elsewhere in
this codebase. All 155 existing tests pass with this change
(`test_composite_signal.py`'s exact-voter-set test updated to include the
new name).

**Effect on today's real data (before -> after, ~2:45pm ET checkpoint):**
- New voter alone: direction=-0.296, confidence=0.847 — a real,
  high-confidence bearish read, in contrast to the old daily technical
  voter's conf=0.00 the whole day.
- Full ensemble direction: -0.098 -> -0.158 (still below the 0.35
  SIGNAL_THRESHOLD needed to fire PUT — `hurst`/`hmm_regime` are still
  pulling bullish off the longer daily trend, so this alone didn't flip the
  signal, it just gave today's actual move a real vote instead of no vote).

**Not done (proposal, not applied):** whether `hurst`/`hmm_regime` should
also get an intraday-aware counterpart, or whether their weight should be
capped relative to intraday-reactive voters during the trading day, is an
open question — worth watching over the next several sessions (via the
already-wired automatic voter-weight tuning) before deciding it's a real
pattern rather than one day's noise.

---

### End-of-day review (4:05pm ET)

**What happened:** SPY closed at $772.66, down from Friday's $776.34 close
(-0.47%). Basically a straight-line grind down all day — up small at the
open, chopped in the mid-morning, then sold off steadily from about 1pm
into the close.

**Replayed all 27 of today's 15-minute checkpoints** through the ensemble
(no-lookahead — each checkpoint only sees data up to that moment, same as
live) at two thresholds: the live default (0.35) and a loosened one (0.175)
used only to see what the system was "thinking" even when it didn't fire.

- **At the live threshold:** 5 alerts fired. 4 were CALL and wrong
  (9:30am, 10:30am, 11:30am, 12:15pm — SPY kept drifting down after every
  one). 1 was PUT and right (12:45pm). Win rate: 1 of 5.
- **At the loosened threshold:** 18 alerts fired, 7 right / 11 wrong
  (38.9%) — same lopsided pattern, mostly wrong CALLs early, with more PUT
  calls catching pieces of the afternoon decline once the bar was lower.

**Why the 4 CALLs were wrong — the "dilution" pattern (README's 2026-08-14
case study, again):** at all 4 wrong-CALL checkpoints, the classic
daily-bar `technical` voter was locked at a strong bullish reading
(direction +0.61, full confidence) and outvoted everything else. At 9:30am
nothing else had an opinion yet. By 10:30am–12:15pm, the *new* intraday
voter, candlesticks, and support/resistance were flagging real short-term
bounces/reversals in the moment (SPY did chop and bounce a few times
before the afternoon's real breakdown) — so it wasn't purely wrong to be
mixed, but the daily `technical` voter's fixed strong-bullish read tipped
several of these into CALL when the "in the moment" evidence was more
mixed-to-bearish.

**Methodology caveat (important, and specific to how the grading tool
works, not live trading):** the grading tool rebuilds its own "daily
history" from only the last ~30 days sitting inside the intraday data
file, rather than the full multi-year daily history the live scans used
today. That makes the `technical` voter behave differently in this replay
(pinned bullish, full confidence, all day) than it did live (where it was
silenced/near-zero most of the day because of a volatility filter). Same
bottom-line wrong CALLs either way, but the grading tool's math isn't a
perfect stand-in for what live trading actually saw. **Proposed fix (not
applied):** point the grading/replay tool at the same long daily-history
source the live scans use, so future EOD grading matches live conditions
exactly. Needs your sign-off since it touches how grading works, not just
a weight.

**Missed opportunities:** 17 of the 22 "no signal" checkpoints still had a
real move (0.10%+) left before the close — almost the whole afternoon
decline was sitting there unflagged. Looking at the votes underneath those
NONE readings from ~1pm onward: candlesticks, the new intraday-technical
voter, time-of-day, and (later) support/resistance were *already* leaning
bearish and correctly picking up the decline in real time. They were being
outweighed by the same locked-bullish `technical` voter described above —
so this wasn't a case of every voter being blind to the move, it was
correct votes getting diluted by one stuck vote. That's a big part of why
today's automatic weight change (below) makes sense.

**What changed automatically today (voter trust, via the built-in
self-tuning — no code or thresholds touched):**

| Voter | Before | After | Change |
|---|---|---|---|
| `intraday_technical` (new voter added today) | 1.00 | 2.32 | up — it was right and got diluted, so its vote counts more going forward |
| `support_resistance` | 1.00 | 1.18 | up slightly — mostly on the right side today |
| `time_of_day` | 1.00 | 0.86 | down slightly |
| `candlesticks` | 1.00 | 0.63 | down |
| `technical` (the old daily-bar voter) | 1.00 | 0.01 | down sharply — it was wrong or diluting the right answer at nearly every checkpoint today |

This is exactly the mechanism working as intended: the voter that kept
being wrong (or overriding correct in-the-moment reads) lost trust, and
the new voter that was catching the real move gained trust. This will
keep adjusting day by day as more real outcomes come in — one day's data
is a start, not a verdict, so I'll keep watching whether `technical`'s
weight stays this low or recovers once we hit a trending-up day where the
daily-bar read is actually right.

**Bigger proposals for your sign-off (not applied):**
1. Point the grading/replay tool at the same long daily-history source
   the live scans use (methodology fix described above).
2. Revisit whether `hurst`/`hmm_regime` (both daily-bar-only, from
   yesterday's mid-day note) need an intraday-aware version too, or
   whether today's near-total collapse of `technical`'s weight already
   solves most of the problem on its own — worth watching a few more
   days before deciding.

## 2026-08-18

**Data-source research (Will's request):** looked into paid data
providers (gexy.io, FlashAlpha, Alpha Vantage) that could fill in the
chain-dependent voters (`gamma_regime`, `vanna_charm`, `put_call_ratio`,
`skew_dynamics`) that have sat out of every live checkpoint so far for
lack of a live options chain. Connected Alpha Vantage (already in
Claude's official connector list, OAuth-based, no key ever shared in
chat) and tested it with real calls rather than trusting their docs:

- Real-time full options chain with open interest/greeks (what
  `gamma_regime`/`vanna_charm`/`skew_dynamics` actually need) is gated
  behind Alpha Vantage's priciest tiers ($199.99-$249.99/month) --
  confirmed by an actual API call, which returned obvious placeholder
  data with that tier requirement stated explicitly. Not worth it for
  this alone; gexy.io ($79.99/mo) and FlashAlpha ($63/mo) are the
  cheaper routes to that data if/when Will wants to pay for it.
  FlashAlpha's Claude connector errored out on first attempt (real
  server-side issue, not a setup mistake) -- retrying.
- Alpha Vantage's put/call ratio endpoint DID return real, full-chain
  data for free (every SPY expiration date, today included). That's
  useful today at zero cost.

**Applied (small, low-risk):** added `put_call_ratio_vote_from_ratio()`
to `vol_regime.py` -- same scoring logic as the existing chain-based
`put_call_ratio_vote`, just taking a pre-computed ratio directly instead
of raw per-contract volume. Wired into `composite_signal.py` via a new
optional `SignalInputs.put_call_ratio` field: when there's no live chain
(the normal case right now) but a ratio is supplied, the put/call voter
fires instead of sitting out; when a real chain IS supplied, behavior is
unchanged (chain-based path still used, no double-voting). Two new tests
added; full suite (157 tests) passes. Next live checkpoint should pass
Alpha Vantage's `REALTIME_PUT_CALL_RATIO` value in here.

**Proposal (Will's idea, not applied -- revisit after today's test):**
mark the pre-market high and low as key levels and feed them into
`support_resistance.py` alongside the existing prior-day high/low/close,
so the support/resistance voter (and potentially the entry-window logic
in `playbook.py`) can read whether the regular-session open is breaking
out of the overnight range or just chopping back inside it. This is a
real, standard concept (the overnight/pre-market range often acts as a
genuine support/resistance zone right at the open), and it's a natural
extension of a voter that already tracks levels -- reasonable scope,
needs Will's go-ahead before touching `support_resistance.py` /
`composite_signal.py` per the standing rule on structural changes.
Today's actual pre-market high/low will be grabbed once the 9:30am open
prints, so there's a real example on hand to design against.

**Proposal (Will's idea, not applied -- revisit after today's close):**
add a "daily" support/resistance factor to the support_resistance voter,
on top of the pre-market-range idea above. Right now that voter only
looks at ONE prior day's high/low/close -- Will wants a version that
looks further back (recent swing highs/lows over the last several days
or weeks) so the voter can catch multi-day structure, not just
yesterday's range. Needs a real design conversation before building --
open questions to bring to that discussion: how many days back is
"daily" (5? 20? matches the existing zigzag_legs() swing-detection logic
already in playbook.py, which could likely be reused here instead of
writing new swing-detection math); how to weight/pick among multiple
candidate levels once found (nearest to spot? most-touched/most
significant?); and how it should combine with the existing single-prior-
day levels and the pre-market-range proposal above rather than three
separate, possibly-conflicting sets of levels. Will asked to go over the
computation approach together after today's close -- do not implement
anything here without that discussion and his sign-off, per the standing
rule on structural changes to composite_signal.py/support_resistance.py.

**Real worked example (Will's observation, confirmed in live data):** a
distinct "intraday" version of the same idea, separate from the
multi-day one above -- a level that forms and gets retested WITHIN the
same session, with a stronger bounce read as the level being more
validated. Concrete case from today (2026-08-18): SPY touched $767.43 at
11:01am ET, bounced up toward ~$768.28 over the next several minutes,
drifted back down, and retested that same $767.43 level again at
11:25am ET (~24 minutes later). Will flagged this live as it happened,
saying the second bounce looked bigger than the first -- worth
confirming the exact magnitude once the full day's data is in, but the
pattern itself (touch, hold, retest) is exactly this proposal's core
idea and gives something concrete to design against: the voter would
need to (a) detect a bounce off a level once, (b) remember that level
for the rest of the session, and (c) weight a second successful test of
it more heavily than a first. This is functionally different machinery
than the multi-day swing-detection idea above (which looks backward at
history already known at the start of the day) -- this one has to build
up its own level list live, intraday, as the session unfolds.

**Applied (2026-08-17's proposal #1 -- grading tool now matches live history):**
`daily_review.py` / `intraday_replay.py` were silently grading every day
against a much shorter daily history than live checkpoints actually see --
they rebuilt "daily" bars by resampling whatever few weeks of intraday
data happened to be in the Webull export file, instead of the ~750 real
days (`hurst`/`hmm_regime` in particular need long real history to have
any statistical power at all). Added an optional `daily_df` parameter to
`replay_day()` / `replay_day_votes()` / `review_day()` (and a
`--daily-csv` flag on `daily_review.py`) so a real long daily-history file
can be passed straight through; omitting it keeps the old resampled
fallback, so nothing existing broke (`test_intraday_replay.py` and the
rest of the 157-test suite pass unchanged).

Confirmed this was a real gap, not just theoretical: re-ran the
2026-08-14 review both ways. With the old resampled ~30-day history,
`hurst` and `hmm_regime` don't even appear in that day's per-voter
reliability table -- they had "not enough history" and sat out the whole
grading pass. With the real 750-day history, both show up fully active
(3 right / 5 wrong each that day) -- meaning the old grading tool wasn't
just slightly off, it was missing two entire voters' contributions to
every wrong call it graded. Fired-alert count, timing, and confidence
also shifted (e.g. an 11:30am PUT the old grading fired no longer does;
a 12:30pm CALL fires that didn't before). This directly matters for the
automatic voter-weight tuning too -- `record_outcome()` running off a
review that silently excludes two voters can't correctly credit or blame
them.

**Held, not applied (2026-08-17's proposal #2 -- intraday-aware
hurst/hmm_regime):** leaving this alone for now. The 2026-08-17 review's
own recommendation was to watch several more days before deciding this is
a real pattern rather than one day's noise, and the automatic weight
tuning already responded hard to that one day (`technical` collapsed to
0.008, `intraday_technical` rose to 2.32) -- worth seeing whether that
alone resolves most of the practical problem before adding two more new
voters on a single day's evidence. Revisit once a few more real trading
days of `scan_log.csv`/adaptive-weight history exist to judge against.

**Applied: re-tuned voter weights against 3 years of real history, not
one day (Will's request -- "adjust the inputs so it tracks with the
market").** The weights in `state/voter_weights.json` were entirely a
product of ONE real trading day (2026-08-17) before this. That's not
enough evidence to trust, and it showed: a 3-year honest backtest (real
daily bars, `backtest.simulate_ensemble_trades`, current-at-the-time
weights held static, no state touched) found `technical` -- the voter
that got crushed to near-zero trust off that one bad day -- was actually
the best-calibrated of the daily-only voters historically (56.7%
directional accuracy, and the ONLY voter whose own confidence correlated
positively with being right, r=0.26). Meanwhile `hurst` was the real
problem: 45.5% accuracy across 112 real historical opinions -- worse than
a coin flip -- with its confidence telling you nothing about whether it
was right (r=0.02). One bad day had the wrong voter in the doghouse.

Fix applied: ran the project's own designed learning mechanism
(`scenario_engine.record_outcome`, the same bounded Hedge-style update
that already runs live) walking forward through all 3 years of real daily
history, so today's weights reflect that full track record instead of
one day. Backed up the pre-existing state first
(`/tmp/voter_weights_backup_before_full_history_learn.json` /
`scenario_history_backup_before_full_history_learn.json`, in case this
needs reverting). Result: `hurst` dropped to 0.21, `technical` recovered
to 0.09 (still low, but no longer near-zero), `hmm_regime` rose to 5.5
(consistently right slightly more than half the time, many times, over
3 years -- compounds under Hedge-style updates), `intraday_technical` /
`support_resistance` / `time_of_day` / `candlesticks` were left
untouched (this backtest has no intraday data, so it never touched
their weights -- exactly as designed). Also grew `scenario_history.json`
from a handful of entries to 39 tracked market-condition fingerprints,
one with 34 real samples -- past the 20-sample bar where the system's
more rigorous empirical-win-rate confidence method (rather than the
weighted-vote fallback) kicks in for that specific condition.

Verified this actually helped, not just plausible-sounding: re-ran the
same 3-year backtest with the new weights held static. Directional
accuracy: 57.8% -> 60.1%. Still a real, honest limitation worth
being upfront about: confidence and being-right are still only weakly
related even after this (correlation -0.17 -> -0.10 -- better, not
fixed) -- the highest-confidence bucket of calls is still not the most
accurate bucket. That points to something more structural than voter
weights alone: the confidence NUMBER itself, for the common case (no
exact-scenario match yet), is just "how strongly do the few active
voters lean," not something independently checked against a track record
-- worth a real look at `scenario_engine.aggregate`'s weighted_ensemble
confidence formula next, not just the weights feeding it.

**Also confirmed, not yet acted on:** PUT calls are meaningfully less
accurate than CALL calls (42.6% vs 68.8% in this same backtest). Some of
that is probably just the backdrop -- SPY was up 82.6% total and closed
up on 56.9% of days across this window, so betting against the trend is
structurally harder -- but it's not fully explained by that alone and is
worth watching rather than assuming away.

**Honest limitation of all of the above:** this is an in-sample backtest
-- the same 3 years of data used to set these weights was also used to
judge whether the new weights are better. That's evidence, not proof it
holds going forward. Real validation is watching live/paper results
against these new weights over the coming days and weeks, same as the
existing daily-review process already does.

**Applied: made the ensemble dynamic within a session, not just across
days (Will's request -- "it's got to be dynamic... intraday numbers
should start painting the picture clearer").** Replayed today
(2026-08-18) minute-by-minute through the ensemble and found the exact
mechanism behind Will's complaint: at the real ~11:20am low (three
intraday voters -- intraday_technical, candlesticks, support_resistance
-- unanimously and confidently reading a reversal there), the ensemble
still read a barely-positive +0.14, because `hmm_regime` alone (weight
5.5, frozen all day since it only reads daily bars) outweighed all three
of them combined. Every single 10-minute checkpoint across today read
positive-or-neutral -- direction never once went negative, despite two
real intraday down-legs (~9:41-11:20am, ~1:00-2:10pm). That's the literal
mechanism of "could have said PUT all day and missed the CALL-worthy
bounces."

Two changes to `scenario_engine.aggregate`'s weighted_ensemble fallback
(the path used ~100% of the time -- see the entry above on why the
empirical-scenario alternative rarely has enough samples yet):

1. Adaptive trust weights are now compressed (square root) before use.
   A weight of 1.0 is unaffected (every existing test's default), but a
   weight like `hmm_regime`'s 5.5 -- legitimately earned from a small,
   consistent edge compounding over 3 years of daily bars -- no longer
   gets to single-handedly outvote several other voters that disagree
   with it in the moment. Rank order (more-trusted still counts for
   more) is preserved; total override power isn't.
2. New: `intraday_technical` / `candlesticks` / `support_resistance` /
   `time_of_day` (the only voters that actually re-read today's own
   price action) get a boost that grows from 1x at the open to 2.5x by
   a full session's worth of bars, via a new `session_progress` value
   (computed from the intraday bars' own timestamps, 0.0->1.0). Every
   other voter (technical/hurst/hmm_regime/calendar/chain-based) is
   computed once and frozen for the session, so this is specifically
   "let live evidence outweigh a stale daily-bar snapshot as more of it
   arrives" -- not touching the daily-only backtest path at all
   (`session_progress` defaults to 0.0 = no boost when there's no
   intraday_df, which is every call `backtest.py` makes).

Both default to true no-ops when unused (weight 1.0 -> unaffected;
session_progress 0.0 -> unaffected), so all 157 existing tests pass
unchanged with no edits needed.

Verified both ways: re-replayed today minute-by-minute with the fix --
direction now correctly goes negative through both real down-legs
(e.g. -0.26 at 11:20am, -0.34 at 2:00pm, vs. never-once-negative before)
instead of staying pinned bullish/neutral. It came close to actually
firing PUT (2:00pm's -0.345 direction was one hundredth away from the
0.35 threshold) but didn't cross it today -- deliberately did NOT chase
that last step by lowering the threshold or hand-tuning further to make
today's specific data cross the line, since that's fitting to one day,
exactly the mistake being corrected elsewhere in this entry. Separately
re-ran the full 3-year daily-only accuracy check (same method as above)
to make sure the dampening half of this didn't quietly hurt the
already-validated case: 60.1% -> 62.7% directional accuracy, PUT
accuracy 42.6% -> 47.4% -- net positive there too, not just intraday.

**Still open, same honest caveat as above:** this is still one real day
of intraday validation (today) plus in-sample daily backtest evidence --
real proof is watching whether the ensemble actually starts firing
correctly-timed flips on more real trading days, not just leaning the
right direction without quite firing. Confidence-vs-accuracy calibration
(flagged above) is also still unresolved -- next real candidate if the
dynamic-weighting change above doesn't fully address it on its own over
the next several sessions.

## 2026-08-19

**Automatic end-of-day review (2nd day of the daily loop Will approved
2026-08-18).** SPY gapped up from yesterday's $767.45 close to open at
$770.36, dipped to a low of $768.11 at 9:51am, rallied hard to the day's
high of $772.47 at 11:01am (+$4.36 off the low -- the day's single
biggest move), then faded most of the rest of the session, closing at
$769.06 (-0.17% net for the day, but the real story was the rally then
the fade, not a straight line).

**How the indicator tracked it (replayed at ~10min checkpoints,
yesterday's fix in place):** mixed. It correctly read bearish right at
the 9:30-9:40am open (price was about to dip further), and correctly
flipped bearish again from ~11:20am onward and stayed mostly bearish
through the afternoon fade -- which was the day's dominant move, so that
part tracked well. But it completely missed the 9:51-11:01am rally: even
at 10:40am, with three intraday-reactive voters unanimously bullish
(intraday_technical, candlesticks, support_resistance all agreeing price
was rallying), the read stayed at a muted +0.32 -- never fired CALL.
Root cause is the same mechanism from yesterday's fix, just showing up on
an up-move this time instead of a down-move: `hmm_regime` stayed
bearish (-0.50) all day (it's a daily-bar snapshot, frozen for the whole
session) and yesterday's dampening/boost fix wasn't yet strong enough,
this early in the session (session_progress only ~0.18 by 10:40am), to
let three genuinely unanimous live voters overcome one large frozen one.
Confirms this is a real, recurring pattern -- not a one-off from
yesterday's specific down-day -- worth fixing further, not a coincidence.

**Tried and deliberately reverted, not shipped:** attempted the
"automatic voter-weight tuning is always fine" step using today's real
39 checkpoints, scoring each one against today's final close (the
existing project convention for the once-a-day EOD learning step). This
backfired: because the day's close (769.06) ended up below most
checkpoints' prices (the rally faded), a voter that was CONSTANTLY
bearish all day (hmm_regime, wrong during the 9:51-11:01 rally) still
scored as "right" for the majority of today's 39 checkpoints just by
virtue of the day's net direction -- pushing hmm_regime's weight even
higher (5.5 -> 7.0), the opposite of what's needed. That "reward
distance to end-of-day close" convention is fine for a once-a-day
decision (which is what it was designed for) but actively punishes
intraday responsiveness when applied to many same-day checkpoints
scored against one shared endpoint. Backed out immediately (state
restored from the pre-run backup) rather than ship it -- **no live
weights or logic changed today.** Real fix needs each intraday checkpoint
graded against a near-term forward move (e.g. the next 30-60min), not
the day's eventual close -- flagged as the next concrete thing to build
and test properly, with more time than a single automated pass allows,
rather than rushed tonight.

**Bottom line for the next review:** yesterday's fix is real progress
(confirmed again today: it does react to intraday moves now, just not
strongly enough yet early in the session) but not sufficient on its own.
Two concrete next steps, neither applied yet: (1) strengthen the
intraday-boost/daily-dampen balance in `scenario_engine.aggregate` --
tested a few candidate parameter values today but hit a compute timeout
before finishing a fair comparison, needs a cleaner/faster test harness
next time; (2) fix the reward convention for intraday-granularity
learning (near-term forward return, not end-of-day close) before
re-attempting any automatic tuning at checkpoint granularity.

**Added: `vwap_reversion.py`, a new voter (Will's complaint, same day --
built and shipped same-session).** Built an interactive slider chart
replaying today (2026-08-19) at 10-min checkpoints using real Webull
1-min bars pulled after the close (see `data/SPY_live_2026-08-19.csv`)
and real ~3yr daily history (`data/SPY_daily_webull.csv`, pulled via the
Webull MCP tool since yfinance is still network-blocked here). Will
looked at it and called out two concrete bad calls: CALL fired at 11:00am
-- exactly the day's high ($772.20) -- and PUT fired at 11:40am, right
where price bounced hard off session VWAP acting as support. Checked the
per-voter breakdown at both checkpoints and found the real mechanism:
`intraday_technical` was at *maximum* confidence (1.00) in both
directions at those exact moments -- +0.68 bullish at 11:00, -0.58
bearish at 11:40. That's not a bug, it's what a trend-CONFIRMING voter
(EMA spread/MACD/RSI) necessarily does: it needs the move already
underway to reach high confidence, so it structurally peaks right as the
move is exhausting. `candlesticks` does the same thing for the same
reason. Nothing in the ensemble was reading "how stretched is price from
a level real flow respects" or "did price just get rejected there."

`vwap_reversion.py` adds exactly that, keyed to session VWAP specifically
because -- unlike the swing-based levels in `support_resistance.py` -- it
needs no multi-bar confirmation lag; it's a cumulative volume-weighted
average known the instant a bar prints, so a bounce at it can be read in
real time. Two independently-gated reads: (1) bounce/rejection right at
VWAP (same shape as support_resistance's bounce_support/bounce_resistance,
same confidence, 0.55), and (2) an overextension fade when price sits
unusually far from VWAP relative to *today's own* realized range (not the
multi-week daily ATR used elsewhere) -- deliberately capped well below the
bounce case (confidence <=0.4) so it can dent a maximally-confident
momentum read without being able to flip a real breakout into a fade call
on its own. Added to `scenario_engine.INTRADAY_REACTIVE_VOTERS` since it
re-reads today's own bars exactly like intraday_technical/candlesticks/
support_resistance/time_of_day do, so it gets the same session-progress
boost. Starts in `AdaptiveWeights` at the default weight (1.0) like any
new voter -- no hand-tuning of its trust score, it earns that the same way
everything else does.

Re-ran today's replay with it in the ensemble: the 11:00am CALL survived
but got meaningfully de-fanged (confidence 0.44 -> 0.366, right at the
0.35 firing line instead of comfortably above it) -- `vwap_reversion` read
"extended_from_vwap" (-0.21) there, partially offsetting
`intraday_technical`'s maxed-out +0.68. At 11:40am itself it stayed
neutral ("at_vwap_undecided") since price was still ticking down in that
exact bar -- same honest real-time limitation `support_resistance.py`
already documents: you cannot call a bounce confirmed until price has
actually ticked back away from the level, not just stopped falling. But
one checkpoint later, 11:50am, it fired "vwap_bounce_support" at full
confidence (+0.55) right as the real reversal was confirmed, and the
ensemble accordingly went to NONE instead of staying bearish through the
bounce -- by 12:00pm `candlesticks`/`intraday_technical` caught up and the
ensemble correctly flipped CALL into the real continuation. Net effect on
this one day: less top-chasing, and it stops leaning the wrong way through
a real reversal one checkpoint sooner than before -- but it does NOT grant
prediction of a bounce before it starts; the 11:20-11:40 PUT reads during
the actual decline are not obviously wrong in hindsight (price WAS
falling then), just early relative to where the reversal actually printed.

Sanity-checked beyond today, to guard against exactly the overfitting
trap the reward-convention revert above is about: full test suite still
passes (164/164, one existing full-stack test updated to expect the new
voter name), 7 new unit tests cover bounds/bounce/fade/neutral cases, and
replayed 3 other real days from the existing bulk Webull export
(2026-08-12/13/14) -- no errors, sensible non-degenerate signal mix each
day, and `vwap_reversion` genuinely alternates between bounce/fade/
undecided reads across a different day's price action rather than reading
the same thing everywhere.

**Honest limitations, not yet resolved:** this is validated against real
replayed price action, not against real forward-return grading -- multi-
day PUT/CALL accuracy impact is still unknown and won't be until it's
watched live over real sessions, same as every other voter here.
Scenario fingerprints now include this voter's regime_tag, which means
existing entries in `state/scenario_history.json` no longer exact-match
new fingerprints -- the empirical_scenario path effectively resets and
falls back to weighted_ensemble until new fingerprints accumulate 20+
samples again (per the 2026-08-18 entry, that path rarely had enough
samples to matter day-to-day anyway, but flagging it since it's a real
side effect of adding any new voter, not just this one). No live
persistent weights were hand-set for this voter -- it starts neutral and
has to earn trust the same way everything else does.

**Checked before building, not after: does SMI or MFI add real
information (Will's question, same session).** Will asked whether adding
the Stochastic Momentum Index and Money Flow Index would help. Computed
both against the existing RSI on real data before writing any voter code:
RSI vs SMI correlation 0.83 across 30 real trading days
(`data/SPY_Webull_1min_20260706_to_20260814.csv`) -- same "position
within recent range" oscillator family as the RSI/MACD already inside
`indicator.compute_indicator`'s momentum component, so SMI would very
likely just be a relabeled copy of a vote already being cast. Skipped it.
RSI vs MFI correlation only 0.68 over the same 30 days, disagreeing by
>20 points (same 0-100 scale) on 12% of bars and >25 points on 5% -- MFI
folds in volume, RSI doesn't, and that empirically does carry different
information often enough to matter. Built `mfi_divergence.py`.

Added `money_flow_index()` to `indicator.py` (needed a NaN-when-no-flow-
at-all-but-100-when-purely-one-sided fix mid-build -- the naive ratio
formula divides by zero and goes NaN on a pure uptrend, which is exactly
backwards; a window with zero negative flow is the maximally bullish
case, not an undefined one). The voter has two independently-gated reads:
(1) divergence -- price moved one way over a lookback window while money
flow moved the other way (a rally not backed by real buying volume, or a
selloff not backed by real selling volume) -- the genuinely novel part,
since nothing else in this ensemble compares a price swing against a
volume-weighted read of that same swing; (2) a weaker extreme-reading
fade (MFI >=80 / <=20) for when there's no divergence but the raw reading
itself is stretched. Added to `INTRADAY_REACTIVE_VOTERS` for the same
session-progress-boost reason as vwap_reversion/etc.

Re-ran today's replay with it added on top of yesterday's vwap_reversion:
the 11:00am top -- which vwap_reversion alone had softened to 0.366
(barely above the 0.35 firing line) -- now reads 0.310 and doesn't fire
at all (`mfi_divergence` read "overbought", -0.194, on top of
`vwap_reversion`'s -0.205). That's the direct, concrete fix to Will's
original complaint: the ensemble no longer calls CALL at today's exact
high. 11:40pm's PUT is unchanged (MFI was at 23 at that exact checkpoint,
short of the 20 oversold threshold -- same honest checkpoint-granularity
limitation as vwap_reversion's bounce read; MFI crossed to 17.9 one
minute later at 11:41, just past this sampling grid).

**Honest tradeoff, not yet resolved either way:** comparing the full
day's checkpoints with vs without this voter, it didn't just soften the
11:00am top -- it measurably dampened confidence at MOST checkpoints
where MFI was reading stretched in either direction, not only the one
that motivated building it (e.g. 13:50pm's PUT went from confidence 0.57
to a non-firing 0.29; the 3-day sanity replay below shows fewer total
CALLs on 8/13 too, 17->15). That's the intended mechanism working as
designed, but it cuts both ways: on a day with one real, sustained
directional move instead of today's chop, the same mechanism would also
dampen genuinely correct trend-following calls, not just wrong ones at
the exhaustion point. Full test suite passes (172/172, 8 new unit tests,
one more full-stack test updated for the new voter name), and a 3-day
sanity replay (8/12-8/14) shows no crashes and a sensible, non-degenerate
signal mix -- but whether the dampening nets positive or negative over
real trending days is genuinely unknown until it's watched live. Same
weight-neutral starting point and same "no live retuning done" caveat as
vwap_reversion above.

## 2026-08-20

**Added: `adaptive_supertrend.py`, a third new voter (Will shared a Pine
Script indicator to port, not a bug complaint this time).** Unlike
`vwap_reversion`/`mfi_divergence` above, this is a faithful line-by-line
port of Will's actual Pine script -- not a reimplementation from the
general "SuperTrend" concept. It keeps every line that feeds a decision
(band ratchet, trend state machine, rolling percentile learning of the
Nth-percentile pullback size per direction, EMA-smoothed factor,
bounce-zone detection) and drops only the visual-only TradingView-chart
parts (pullback histogram, dashboard table, bar coloring) that have no
meaning outside that UI. Reused this project's existing Wilder-smoothed
`indicator.atr()` for `ta.atr()` rather than reimplementing it, matched
`arrayPercentile()`'s sort+linear-interpolation to numpy's default
`np.percentile` method, and preserved the original's no-lookahead sample
ordering (a bar's own pullback excursion is appended to the learning
array only after that bar's factor is already computed from bars through
t-1).

Whipsawed badly at the project's native 1-min bar resolution when first
run against real data -- 11-15 trend flips and a "bounce reaction" tag on
5-8% of ALL bars, consistent across 4 real trading days -- so it needed
the same fix already precedented twice in this codebase for the identical
sub-3-minute-noise problem (`support_resistance.py`, `candlestick_
patterns.py`): resample to 5-min bars first. That alone cut flips to
~2-5/day. Raising `minimum_factor` 0.75->2.0 and `factor_smoothing`
5->10 on top of the resample got to a final ~1-2 flips/day and ~2-6
bounce reactions/day -- checked against the same 4 days (today plus
8/12-8/14) before adopting, not just eyeballed on one. Sits out entirely
(0 confidence) until 20 resampled 5-min bars exist (~100 minutes into the
session), same honest "don't force an opinion before there's enough
signal" pattern as every other intraday-reactive voter here.

This voter is deliberately trend-CONFIRMING, not reversal-catching like
the two above it -- it never says "this move is exhausted," only "a
trend is established/continuing" or "a trend just flipped." Confidence is
tiered to match: a fresh flip that survived the full learned-pullback
threshold (0.55) > a bounce reaction, a real but shallow dip that closed
back toward the trend (0.45) > plain continuation with nothing new
happening, scaled further by how much the model has actually learned yet
(<=0.35). Re-ran today's (2026-08-19, the last completed trading day --
8/20 hadn't closed yet when this was built) replay with all three new
voters in the ensemble: at 11:00am, the exact top, it sits out entirely
(NaN/0 confidence -- only ~18-19 resampled bars existed that early, just
under the 20-bar minimum), leaving `vwap_reversion`/`mfi_divergence` to
do the softening work documented above unchanged. At 11:40am it
contributes a genuinely different, weak counter-lean (`uptrend`, +1.00
direction, 0.18 confidence) against the PUT chasing, because the 5-min-
resampled trend hadn't actually flipped bearish yet at that point (it
flips closer to 12:55). At 13:20pm it contributes `downtrend`, -1.00,
0.30 confidence -- now agreeing with the real, sustained afternoon
decline, adding conviction to a genuine trend rather than chasing noise.
That's the intended shape: quiet on choppy/early-session noise, present
on real sustained moves.

Full test suite passes (184/184 -- 172 before this voter, +9 new
`compute_adaptive_supertrend` unit tests covering zero-volatility/flat
series, first-trend-read fallback, clean-trend no-late-flip behavior,
factor bounds, sample-confidence ramp, no-lookahead under series
extension, and bounce-reaction gating, +3 vote-wrapper tests for the
not-enough-bars sit-out, confidence/direction bounds, and the confidence-
tier-matches-regime-tag invariant). A 3-day sanity replay (8/12-8/14)
produced no crashes and a sensible non-degenerate mix each day (8/12:
`{NONE:23, CALL:4}`, 8/13: `{CALL:17, NONE:10}`, 8/14: `{NONE:19, CALL:4,
PUT:4}`). Added to `INTRADAY_REACTIVE_VOTERS` for the same session-
progress-boost reason as the other two, and its regime_tag now also
feeds `scenario_fingerprint()` -- so, same caveat as the 2026-08-18/19
entries above, this again resets which historical fingerprints in
`state/scenario_history.json` exact-match new ones; the empirical-
scenario path falls back to weighted_ensemble until new fingerprints
re-accumulate 20+ samples.

**Honest limitations, not yet resolved:** this is a faithful port and its
internal mechanics were checked against Pine's documented semantics
(band ratchet direction, state machine transitions, no-lookahead sample
ordering) and against real replayed price action across 4 days -- not
against real forward-return grading. Whether a trend-confirming voter
tuned this way actually improves multi-day PUT/CALL accuracy, versus just
adding a third correlated-but-not-identical read alongside
`intraday_technical`/`candlesticks` (which are also, in their own way,
trend-confirming), is genuinely unknown until it's watched live over real
sessions. Starts at the default weight (1.0) like every other voter here
-- no hand-tuning of its trust score.

**Evaluated and NOT added: `anchored_vwap_swings.py`, a second Pine
Script indicator Will shared ("Anchored VWAP Origin Chronicle") -- two
AVWAPs anchored to the most recent confirmed swing-high/swing-low pivot,
with price classified as above both, below both, or between them.**
Ported the decision-relevant subset (confirmed-pivot detection, ATR
prominence + cooldown filter, cumulative anchored VWAP, pair
classification; skipped the manual anchor and ~500 lines of pure chart
UI) and gave it the same 5-min resample tuning as adaptive_supertrend.
11 unit tests pass (195/195 total). Then checkpoint-replayed it
standalone (not wired into composite_signal.py) across 8/12-8/14 and
8/19 to decide whether it's worth adding, per Will's ask.

Two findings argue against adding it as-is: (1) it needs a CONFIRMED
swing high AND a confirmed swing low before it says anything at all --
on 8/19, the day with the original bad-call complaints, that didn't
happen until 13:50pm, so it would have had zero opinion through the
11:00am top, the 11:40am bounce, and the 13:20pm decline entirely. Sits
out 50-95% of checkpoints across all 4 days tested (78% average), far
sparser than any existing intraday voter. (2) On the 35 checkpoints
across all 4 days where it DID have an opinion, `adaptive_supertrend`
also had one every single time, and agreed on direction 29/35 (83%) of
those -- it's mostly telling the ensemble something `adaptive_supertrend`
already said, just less often. The 6 disagreements aren't uniformly
wrong either (one -- 8/12 ~13:40pm -- had `anchored_vwap_swings` correctly
leading a continued rally that `adaptive_supertrend`'s slower-to-flip
5-min trend was still calling a downtrend on), so there may be a real
edge case here, but it's thin and unconfirmed.

Verdict: not adding it in its current tuning. The mechanism (two
independent swing-anchored VWAPs) is genuinely different from every
existing voter, but pivot_left=8/pivot_right=5 plus a 1.0 ATR minimum
prominence on 5-min bars makes it too rare to be useful most days, and
when it fires, it isn't clearly adding information `adaptive_supertrend`
lacks. Left both new files in the repo (`anchored_vwap_swings.py` +
tests) but did NOT add it to `composite_signal.py`/
`scenario_engine.INTRADAY_REACTIVE_VOTERS` -- revisit if a looser pivot
window (shorter left/right, lower prominence) is tried and shown to fire
more often without just re-deriving `adaptive_supertrend`'s read.

**Evaluated, mixed result, NOT added: `market_structure.py`.** Third
tool Will described (a "market structure score" -- HH/HL/LH/LL pivot
classification into a weighted -100..+100 score, plus CHoCH/BOS break
labels) -- built to spec from a written description only, no source
this time, so several formulas (the score normalization, treating the
very first break with no established bias as a CHoCH) are stated,
documented assumptions rather than verified matches. 13 new unit tests
(208/208 total); one real bug caught by a test along the way -- a
dropped, weaker same-type pivot candidate was incorrectly re-arming the
break detector using its own (rejected) price, which would have let a
disarmed level fire a second break it shouldn't have.

Unlike the last two, this one's OWN documentation recommends
pivot_sensitivity 2-3 on 1m-15m charts, and checked against real 1-min
SPY bars that held up -- no resample needed, 2-5 zero-crossings/day, a
non-degenerate regime mix, and real signal at 45% of 8/19's checkpoints
(vs. `anchored_vwap_swings`'s 5%). It's also far less redundant: when it
had an opinion on 8/19, `adaptive_supertrend` agreed only 7/18 times
(39%, vs. the anchored-VWAP tool's 83%) -- genuinely different
information, not just an echo.

But it has a real, concrete miss: at 10:10am on 8/19 it read Strong Bear
at 0.35 confidence (its max tier), right before the day's rally to the
11:01am high -- the exact "confidently wrong at the worst moment"
failure this whole project has been chasing out of other voters. It also
threw a fresh bullish CHoCH at 3:59pm, the day's last bar, unconfirmed by
anything after it -- an artifact of scoring right up to the data edge,
not necessarily a real signal. Verdict: promising mechanism, not proven
-- lower redundancy and better coverage than the last candidate, but at
least one high-confidence miss on the one real day tested closely. Left
in the repo, not wired into the ensemble; would want either a fix for
the edge-of-data false-confidence issue or a few more real days of
checking before reconsidering.

**Evaluated and NOT added: `price_action.py`.** Will asked for a
"price-action voter" directly; scoped via AskUserQuestion to three
concepts not already covered elsewhere (`candlestick_patterns.py` and
`support_resistance.py` already own single/multi-candle shapes and
multi-bar-confirmed level bounces): liquidity sweep/stop hunt (a
same-bar pierce-and-reject past a recent high/low), momentum thrust
(N consecutive same-direction closes with non-doji bodies), and range
compression -> expansion (an NR-7 squeeze followed by a directional
breakout). Built as three independently-gated reads on 5-min-resampled
bars, checked in sweep -> breakout -> thrust priority order, returning
whichever fires first. 16 new unit tests (224/224 total).

Checkpoint-replayed across 8/12, 8/13, 8/14, 8/19, and 8/20 (partial, through
1:30pm) at 10-min intervals, 185 checkpoints total. Two findings, one good,
one bad. Good: when it does have an opinion, it's genuinely different from
what's already in the ensemble -- direction agreement with `adaptive_
supertrend` was only 33% (5/15) and with `market_structure` 40% (4/10),
both well below the 83% that sank `anchored_vwap_swings`. Bad: it's even
sparser than that already-rejected voter -- 15/185 checkpoints active (8%,
vs. anchored_vwap's 22% average), and 0/25 so far today. Worse, a crude
same-direction check on those 15 real activations (does price move the
called way over the next 10/30 minutes) came back below a coin flip --
4/15 (27%) at +10min, 6/15 (40%) at +30min. Small sample, not a real
backtest, but it includes a concrete repeat of a previously-documented
failure: at 11:40am on 8/19, the exact bar `vwap_reversion` was built to
fix (ensemble PUT at the VWAP-support bounce low), this voter read
`momentum_thrust_down_continuation` at 0.39 confidence -- agreeing with
the wrong-direction chase, not correcting it. Verdict: not adding. Too
rare to matter most sessions, and the handful of real signals it did
produce leaned wrong more often than right in the one window tested,
including the specific bad moment this project has already had to design
around once. Left in the repo, not wired in; would want either a much
higher activation rate or real evidence of positive edge on a larger
sample before reconsidering.

---

### End-of-day review (3rd day of the daily loop Will approved 2026-08-18)

**What happened:** SPY opened at $765.93, chopped in a $762.05-$768.15
range through the morning with no sustained direction (touched a high of
$768.15 around 11:06am, a minor local peak at $766.45 by 12:40pm), then
sold off steadily and without much relief from 12:40pm into the close,
finishing at $762.60 -- down 0.84% from yesterday's $769.06 close. Unlike
8/19 (rally then fade) or 8/18 (gap up, dip, big rally, fade), today's
dominant move was one clean, sustained afternoon decline with a choppy,
range-bound morning ahead of it.

**How the indicator tracked it (replayed at 10-min checkpoints, current
live weights, no lookahead):** well, on balance. 21 of 40 checkpoints
fired a signal; of those, 19/21 (90.5%) were on the correct side of the
day's eventual close, and 14/21 (66.7%) were already right within the
next 30 minutes (noisier, as expected at that horizon). The whole
afternoon decline from 13:20pm to the close was called PUT continuously,
confidence climbing from 0.40 to 0.59 as the move developed -- the
dominant move of the day was well-tracked, not just retroactively
correct.

**The one real miss:** a CALL fired at 12:40pm (766.45, direction
+0.474) right before the afternoon selloff started -- price was down
0.81 thirty minutes later and never recovered. Checked the per-voter
breakdown: `intraday_technical` (dir +0.355, conf 1.00 -- maxed out),
`support_resistance` (+0.775, conf 0.725, "bounce_support"), and
`adaptive_supertrend` (+1.00, conf 0.35, "uptrend") were all reading a
bullish bounce off the morning's range at that exact bar -- the same
trend-confirming-voters-peak-at-the-exhaustion-point mechanism this
project has hit before (8/19's `vwap_reversion`/`mfi_divergence` were
built specifically to counter it). This time those two dampeners didn't
help: both sat at exactly 0 confidence at 12:40pm (`at_vwap_undecided`,
`neutral_flow`) -- the reversal hadn't happened yet in a way they could
detect, the same honest real-time limitation already documented for
them. One checkpoint later (12:50pm) the ensemble had already backed off
to NONE as the real direction became clearer. Not proposing a fix for
this specific gap tonight -- it's the known, accepted cost of how those
two voters work (can't confirm a reversal before it's happened), not a
new bug.

**Picked up the open WEIGHT_DAMPEN_EXPONENT/INTRADAY_BOOST_MAX issue
(from 8/18/8/19) with a faster test harness, per the standing to-do.**
Last time, testing candidate values against the full 3-year daily
backtest hit a compute timeout before finishing a fair comparison. Root
cause: `AdaptiveWeights.update()` and `ScenarioStore.record_outcome()`
don't depend on either parameter at all -- only `aggregate()`'s final
direction/confidence/signal does. So the expensive part (recomputing
every voter, refitting HMM/Hurst, walking weights forward across ~100
sampled trading days) only needs to run ONCE; the exponent/boost grid can
then be swept cheaply by replaying just `aggregate()`'s arithmetic over
cached votes. Built this as a standalone harness
(`/tmp/dampen_test.py`/`/tmp/boost_test.py`, not committed -- exploratory
tooling, not part of the shipped codebase); ran cleanly in under a
minute total, no timeout.

Two honest findings, neither strong enough to ship a change:

1. **WEIGHT_DAMPEN_EXPONENT, held-static 3-year daily backtest (matching
   the validated 2026-08-18 methodology -- live weights held static, not
   re-learning):** accuracy was flat and noisy across 0.5 (current) down
   to 0.25 -- 48.9%, 48.8%, 48.8%, 49.4%, 48.7%. No monotonic trend, no
   candidate meaningfully better than today's 0.5. (Note: this run's
   absolute accuracy doesn't match the 8/18 entry's cited 62.7% -- almost
   certainly because `scenario_history.json` has since accumulated real
   samples from that same walk-forward, so a growing share of backtest
   days now route through the empirical-scenario path rather than
   weighted_ensemble, which isn't the same comparison. Relative ranking
   across exponent values is still apples-to-apples since every candidate
   was scored off the identical cached votes/scenario state.) Verdict:
   no evidence for a change here.

2. **INTRADAY_BOOST_MAX, spot-checked against the exact known trouble
   checkpoints (8/18 11:20am, 8/19 10:40am and 11:00am -- pulled real
   saved intraday bars for 8/18 specifically since it hadn't been kept
   from that session).** More interesting and more useful than a clean
   answer: the group of `INTRADAY_REACTIVE_VOTERS` this fix boosts has
   grown since the issue was diagnosed -- `vwap_reversion` and
   `mfi_divergence` (added 8/19, after the original 8/18 analysis) are
   also members. At 8/19 10:40am, `intraday_technical`/`candlesticks`/
   `support_resistance` are still unanimously bullish exactly as
   originally described (+0.648/+0.540/+0.525) -- but `vwap_reversion`
   (-0.170, "extended_from_vwap") and `mfi_divergence` (-0.339,
   "overbought") are now voting bearish at that same bar, by design
   (that's exactly the exhaustion-fade behavior they were built for).
   Cranking `INTRADAY_BOOST_MAX` from 1.5 to 6.0 (4x) only moved this
   checkpoint from +0.197 to +0.257 confidence -- nowhere near the 0.35
   threshold -- because boosting the whole group boosts both the
   momentum-chasers AND the fade-voters now sitting inside it. The 8/18
   11:20am checkpoint moved more (NONE at -0.338 -> PUT at -0.458 as
   boost rises 1.5->6.0), but a fresh per-voter check shows it's no
   longer the clean "3 unanimous bullish voters vs. one frozen bearish
   one" case from the original write-up either -- with today's full
   voter roster, `intraday_technical`/`candlesticks`/`support_resistance`
   read BEARISH at that exact bar now, not bullish, so the original
   specific narrative doesn't replay identically against the current
   ensemble.

**Verdict: no change shipped, same as 8/19 -- and for a better reason
this time.** It's not just "ran out of time to test carefully" anymore;
the actual finding is that a flat, blanket boost multiplier on the whole
`INTRADAY_REACTIVE_VOTERS` set is the wrong shape of fix now that the set
contains both momentum-confirming AND mean-reversion-fading voters that
can legitimately disagree with each other -- boosting the group
uniformly doesn't resolve genuine internal disagreement, it just amplifies
both sides toward the same weighted average. The real next step isn't a
bigger constant, it's making the boost responsive to how UNANIMOUS the
reactive group actually is on a given bar (e.g. only boost when reactive
voters agree in direction, scaled by how much they agree) rather than
applying a flat multiplier regardless. Not building that tonight --
flagging it as the concrete next design, with real evidence behind why
the simple version doesn't work, rather than another untested guess.
State backups taken before any of this (`/tmp/voter_weights_backup_
20260820.json`, `/tmp/scenario_history_backup_20260820.json`) and
restored/confirmed unchanged afterward -- nothing in `state/` was
touched by any of today's testing. Full test suite still passes
(224/224, no code changed).

**Also pulled and kept `data/SPY_live_2026-08-18.csv`** (390 real 1-min
RTH bars) while investigating the above -- it hadn't been saved from that
day's original session, so it wasn't available for this kind of
after-the-fact spot-check until now. Keeping it going forward alongside
8/19 and 8/20's saved intraday files.

## 2026-08-21

### End-of-day review (4th day of the daily loop Will approved 2026-08-18)

**Correction to yesterday's (8/20) review -- found a real methodology bug
while building today's review, fixed it, and it changes yesterday's
headline finding.** `intraday_replay.replay_day()`/`replay_day_votes()`
have always used fresh, throwaway `ScenarioStore`/`AdaptiveWeights`
instances (by design -- so a replay can never touch the real `state/`
files), which defaults every voter's trust to 1.0 and every scenario to
"no history." That's the right default for "what does each voter say in
isolation," but yesterday's review said it was replaying "using the
CURRENT live state/weights" -- and it wasn't; there was no parameter to
actually pass real weights in, so it silently used the all-1.0 defaults
instead. Concretely: `hmm_regime` currently has a live-earned weight of
~5.5 (trust ~2.35x after the sqrt dampener) -- yesterday's replay gave it
the same trust as every other voter, understating its real influence at
every checkpoint.

Fixed by adding `adaptive_weights_seed`/`scenario_history_seed`
parameters to both replay functions (in-memory only, still never
touching `state/` -- see the new `TestAdaptiveWeightsSeed` test class in
`test_intraday_replay.py`, 3 new tests, 227/227 total). Re-ran 8/20 with
the real weights properly seeded this time: the headline numbers barely
moved (22/40 fired vs. yesterday's 21/40, 95.5% correct vs. day close vs.
90.5%) -- **but the one specific miss called out yesterday, the 12:40pm
CALL right before the afternoon selloff, does NOT happen with the real
weights.** Correctly seeded, that checkpoint reads direction +0.347,
just under the 0.35 firing threshold -- NONE, not CALL. Every single one
of 8/20's 22 real fired signals was PUT, and the ensemble never once
called a wrong-direction CALL that day. That's a meaningfully better
result than what was reported to Will yesterday, and worth being direct
about: the "one real miss" in yesterday's message was an artifact of
testing with the wrong weights, not a real live-equivalent miss. Told
Will this correction directly (see message below) rather than letting it
stand uncorrected.

**Today's session:** SPY opened at $766.10 (gapping up from yesterday's
$762.60 close), chopped in a $764.17-$767.85 range all day with no
sustained direction either way, and closed at $765.72 (+0.41% vs.
yesterday, but that's a poor summary of the day -- it round-tripped
several times). A genuinely different regime than 8/20's clean
trend-then-selloff day: choppy and mean-reverting throughout.

**How the indicator tracked it (10-min checkpoints, real live weights
properly seeded this time):** 15 of 40 checkpoints fired -- all PUT in
the morning (9:30-10:30, catching a real early dip toward $764.5), one
PUT at 11:20am, a cluster of PUT calls 13:40-14:40pm (catching a real
mid-afternoon dip toward $765.1-765.4), then CALL 15:00-15:40pm as price
pushed back toward $766.2 into the close. Directional hit rate vs. the
next 30 minutes: 40% (6/15) -- weak, but this was a genuinely hard,
choppy day with no sustained edge to catch, not a day where a clear
opportunity was missed. Hit rate vs. the day's eventual close: 0/15 --
but that number is close to meaningless here and is itself useful
confirming evidence for something already flagged (8/19's review): SPY's
close ($765.72) landed almost exactly back where the morning started
($765.37), so EVERY PUT call correctly catching an intraday dip, and
EVERY CALL call correctly catching an intraday bounce, reads as "wrong"
against the end-of-day close purely because the day round-tripped. Not
re-litigating that finding tonight, just noting today is a clean second
data point for it.

**Checked one whipsaw point in detail (11:20am PUT -> 11:40am CALL, a
~$1.70 swing in 20 minutes)** to see if it was a real ensemble problem or
just genuinely volatile price action: at 11:20am `candlesticks` was at
max confidence (-0.938, "reversal") reading the local top rolling over;
by 11:40am price had actually rallied $1.70 and `candlesticks`/
`intraday_technical` correctly flipped to reading the new move
(+0.741/+0.699). `vwap_reversion`/`mfi_divergence` correctly leaned
against the new move once it got extended (-0.230/-0.352) but not enough
to prevent the flip. This reads as the trend-confirming voters doing
their job on genuinely fast, real price swings, not a new bug -- same
honest, already-documented limitation as 8/20's miss, not something new
to fix.

**No code or weight changes shipped today** (beyond the replay-seeding
bug fix above, which is a test-tooling correctness fix, not a change to
any live voter/weight/threshold). Did not attempt the
unanimity-weighted-boost prototype flagged in 8/20's entry -- today's
data (a genuinely choppy day with real, fast, legitimate voter
disagreement) is exactly the kind of case that idea needs to handle
carefully, so it's better validated against a clean design + both a
trend day and a chop day together, not rushed. State backups taken
(`/tmp/voter_weights_backup_20260821.json`,
`/tmp/scenario_history_backup_20260821.json`), confirmed unchanged
afterward. Full test suite: 227/227 (224 existing + 3 new, all for the
replay-seeding fix).

**Scheduling:** this was review #4. Per the standing instruction, review
#5 was not auto-scheduled -- asked Will whether to keep the daily loop
going. Answer: pause it. No further automatic EOD reviews scheduled;
will resume only if/when Will asks again.

### Reversal-point investigation (same day, after the loop was paused)

Will flagged three concrete bad moments from today's live trading: PUTs
at 10:00am and 11:20am, no flip to CALL by 11:30am despite an observed
9-EMA bounce, and a PUT firing right at the 2:30-2:50pm bottom (765.12)
after an hour-long low-volatility grind down. He then pushed back hard
on the pattern of him having to spot these instead of the system
catching them itself, and asked me to keep trying for a real fix.

**10:00am PUT:** a stale-snapshot call with zero live confirmation --
`hmm_regime` (frozen per-day read) and `technical` (daily-scale) drove
it while `intraday_technical` had no real opinion yet. Not investigated
further today; the 11:20-11:40 and 2:30-2:50 windows were the real focus.

**11:20-11:40 (should have flipped to CALL by 11:30):** diagnosed
precisely -- `intraday_technical`/`candlesticks` read the rally
correctly and fast, but `hmm_regime` (frozen, trust=2.35, the single
highest-weighted voter in the whole ensemble) and `mfi_divergence`
(bearish-divergence read) kept dragging the aggregate below the 0.35
threshold. At 11:30 direction was -0.249; even removing every lagging
voter (`hmm_regime`, `mfi_divergence`, `adaptive_supertrend`) entirely
only got it to +0.30, still short. **This one is a genuinely closer
call than 2:30pm** -- not a clean miss.

**2:30-2:50pm (PUT fired at the exact low):** worse. At 2:30pm, right
at 765.12-765.15 (the actual low of the whole hour-long grind), the
ensemble fired a live PUT at -0.70 direction/confidence. It stayed
PUT-biased through 2:40, was still NONE at 2:50 with price already up
$0.60, and didn't flip CALL until 3:00pm -- after $1.10+ of the move was
already gone.

**Built a real proactive-detection tool instead of only re-checking
Will's two examples** (`find_reversals.py`, now committed): scans 1-min
bars for genuine "grind for 30+ min, then reverse at least $0.40 the
other way" points, one trading session at a time, tuned/validated
against the two known cases above before trusting it on the rest.
Run against all available data (the ~30-day `SPY_Webull_1min_...csv`
plus all 5 live days, 2026-07-06 through 2026-08-21) -- found 14 real
reversal points, not just the 2 Will happened to be watching live.

**Graded the ensemble at all 14** (properly live-weight-seeded, real
`daily_df` history from `SPY_daily_webull.csv`, checkpoints every 5 min
from -20 to +75 min around each point): **6 of 14 (43%) had the
ensemble fire an actively wrong-direction signal at/near the turning
point** (the same pattern as 2:30pm today); **6 of 14 (43%) never
caught the correct direction at all within 75 minutes**; when it did
eventually catch it, the median lag was 15 minutes. This is a real,
recurring, quantified failure mode, not two unlucky moments -- that's
the honest answer to "why do I have to point these out to you": up to
today this was being investigated reactively, one flagged moment at a
time, instead of scanned for proactively. That gap is now closed with a
reusable tool; the fix itself is not yet found.

**Root-caused which voter drives it:** across all 14 points,
`intraday_technical` was on the wrong (trend-extrapolating) side 12 of
14 times it had an opinion, at 0.70 average confidence when wrong --by
far the worst of any voter, and it carries real trust (0.844, boosted
intraday). Mechanism: its EMA/MACD/RSI/VWAP formula is pure momentum
confirmation with no exhaustion term, its ATR regime gate is fully
disabled (0.0-1.0, unlike the daily voter's 0.15 floor) so a near-zero
ATR during a grind still lets tiny EMA spreads saturate the
ATR-normalized score toward +-1 -- confirmed directly: 4 of the 6
wrong-signal cases had `atr_pct_rank` <= 0.10 at the moment of the bad
call (0.017, 0.017, 0.05, 0.10).

**Tried four candidate fixes against the full 14-point set -- none
moved the numbers (still 6/14 wrong, 6/14 missed, 15min median lag on
every one):**
1. Global `weight_dampen_exponent` / `INTRADAY_BOOST_MAX` grid sweep
   (already ruled out on 8/20, re-confirmed today's data doesn't change that).
2. Splitting `INTRADAY_REACTIVE_VOTERS` into boosted-fast vs.
   unboosted-slow tiers -- moved direction the right way but nowhere
   near the 0.35 threshold (11:30 today: -0.249 -> -0.123 at 2.5x boost).
3. Discounting `intraday_technical`'s confidence directly (RSI-exhaustion
   + low-ATR-grind discount, up to ~65-70% reduction) -- confirmed the
   discount fires correctly, but the ensemble's final call didn't change
   at a single one of the 14 points. Checked why directly at the 2:30pm
   case: with `intraday_technical` discounted, `candlesticks` (-0.709,
   conf 0.80) and `adaptive_supertrend` (-1.0, conf 0.35) simply absorbed
   the freed-up weight and the aggregate got slightly *more* wrong
   (-0.77 vs -0.68), not less.
4. Adding the (already-built, previously unshipped) `price_action.py`
   compression/sweep/thrust voter as a genuine extra vote -- it only
   fired at 9 of the 112 checkpoints checked around the 14 points (8%
   activation), and even then was right only 7 of 10 times when it had
   an opinion. Confirms the earlier small-sample evaluation: too sparse
   and not reliable enough to lean on.

**Honest conclusion:** this isn't a single-voter bug or a tunable
parameter. Multiple independent voters (`intraday_technical`,
`adaptive_supertrend`, `hmm_regime`, `candlesticks`, at different
moments) share the same structural blind spot -- none of them has a
real exhaustion/reversal-recognition model, they're all reading "what
just happened" and extrapolating it -- so discounting or reweighting
any single one just lets the others (equally or more wrong) absorb the
freed-up trust. A real fix needs a genuinely different mechanism, not
another reweighting pass. Two honest paths forward, neither attempted
yet: (a) a materially better reversal/exhaustion voter than
`price_action.py`'s current rule-based one, validated against this same
14-point set before ever being considered for wiring in; (b) accept
this as a structural weak spot near likely turning points and change
how the system is *used* there (e.g. a real-time "low-reliability zone"
flag near a fresh multi-leg extreme) rather than trying to make
direction itself correct at the moment of the turn.

**No code or weight changes shipped today.** `find_reversals.py` is a
new read-only analysis tool (does not touch `state/`), committed to the
repo since it's now the reusable way to find these points going
forward instead of waiting for one to happen live.

### Continued push (same day) -- three more candidate mechanisms tried

Will asked to keep pushing. Checked whether a real chart pattern existed
into the 2:30pm low: fit trendlines to the 5-min swing highs/lows over
the preceding 90 minutes. It's a genuine geometric compression (swing
highs falling at -$0.062/5min bar, swing lows falling slower at
-$0.040/bar -- the range really was narrowing, ~35% convergence), but
it's a descending wedge, not a textbook symmetrical triangle (that needs
one line flat/rising). No triangle-pattern detector exists anywhere in
the codebase (`candlestick_patterns.py` is single/2/3-candle patterns
only; `price_action.py`'s compression check is a single-bar NR-N rule,
not real trendline geometry).

**Tried three more candidates against the 14-point benchmark:**

5. A naive converging-trendline (triangle/wedge) breakout detector,
   built and tested standalone first: only 47.4% accuracy on its own
   breakout calls (38 signals across all 14 events), and the swing-point
   trendline fits are unstable with only 2-4 points in a 90-min window
   (some fits produced nonsensical extrapolated "position" values like
   -12 or +14). Not reliable enough to build on.

6. An ensemble-level low-ATR confidence gate -- first attempt had a real
   bug in the test harness (multiplicative confidence discount can never
   reach exactly zero, so it never actually changed a CALL/PUT/NONE
   classification; looked like zero effect, wasn't a real test). Fixed
   by requiring a minimum confidence-to-fire (0.15) rather than a pure
   multiplier, so a strong enough grind can suppress a signal to NONE
   entirely.

7. The corrected gate (floor: atr_pct_rank < 0.20-0.25, min-confidence-
   to-fire 0.15) is the first mechanism today that moved the reversal-
   point numbers at all: wrong-signal-at-point dropped 6/14 -> 5/14 (the
   2026-08-17 case got suppressed to NONE instead of firing wrong).
   Did NOT fix today's exact 2:30pm case -- by 14:30 (the actual worst
   moment) ATR had already ticked back up to 0.167, not low enough for
   the discount to clear the confidence floor; only 14:10-14:20 were
   suppressed.

   **Regression-checked this gate against 3 normal (non-reversal) days**
   (2026-07-22/24/27, full-day 10-min checkpoints, graded vs. price
   +30min) before considering it further -- this is the right discipline
   before trusting a fix that only looks good on the trouble cases.
   Result: net negative. Baseline 52.2% correct (76 signals fired);
   gated 47.2% correct (60 fired) -- the gate suppressed 16 checkpoints,
   and 11 of those 16 were checkpoints where the ORIGINAL call had been
   right. On ordinary low-volatility stretches (which are common and not
   all reversal-prone), this gate throws away more good signals than bad
   ones. Not worth shipping as-is.

**Updated honest conclusion:** 7 candidate mechanisms tried today across
two sessions (parameter sweeps, fast/slow voter split, direct voter
discount, added price_action as a vote, triangle/wedge detector, and two
versions of an ATR confidence gate) -- one showed a narrow, real
improvement on the flagged trouble spots but failed regression on normal
days, the rest were flat or negative. This is real elimination work, not
wasted effort -- it substantially narrows what's left to try -- but
nothing found today is ready to ship. No code or weight changes made;
`find_reversals.py` remains the one durable output of today's push.

### Second continued push -- options flow angle + scanner upgrade

Will asked to try the options-flow angle, try a flag-instead-of-predict
approach, and keep improving the scanner.

**Options flow:** checked `gamma_regime`/`skew_dynamics` against the 6 of
14 reversal points that have real historical chain data (`data/
chains_bulk`, which only covers through 2026-07-31 -- the 8 August
points, including today's, have no chain coverage). `gamma_regime` was
correct 4/6 (66.7%), `skew_dynamics` 2/6 (33%). Tried pulling August
chains via the Alpha Vantage MCP's HISTORICAL_OPTIONS tool to extend the
sample -- hit a premium-tier paywall, no other historical-options source
available in this environment. So: a hint that `gamma_regime` may carry
real signal here, but n=6 is too small to act on and can't currently be
extended to cover the August cases that actually matter. Worth
revisiting if/when more historical chain data becomes available -- not
pursued further today.

**Flag-instead-of-predict, tested rigorously rather than assumed:** added
a real, causal, no-lookahead version of the grind detector --
`is_grinding_now()` in `find_reversals.py` (now covered by 8 new tests,
including two dedicated no-lookahead checks; full suite 235/235). This
is usable live (only ever looks backward from `now`), unlike the
original hindsight scanner which needs the after-leg to confirm a
reversal happened.

Before trusting "suppress confidence when flagged," tested whether the
flag actually predicts ensemble error rate -- first on the 3 regression
days (tiny sample, only 2 fired signals inside a flagged grind), then
broadened to all 30 days in `SPY_Webull_1min_20260706_to_20260814.csv`
at 20-min checkpoints (600 checkpoints total) to get a real sample.

**Result: real, positive, and different from the ATR-percentile gate
tried earlier today.** Only 20 of 600 checkpoints (3.3%) were ever
flagged -- `is_grinding_now()`'s 1-min realized-vol ceiling is much more
selective than the ATR-percentile criterion, which is likely why it
survives regression where that one didn't. Inside flagged zones the
ensemble fires MORE often (75% vs 49% fire rate) and is LESS accurate
when it does (46.2% vs 56.8% correct vs +30min, 13 fired-and-graded
signals inside vs 241 outside) -- confirms the mechanism suspected
earlier: several voters normalize by ATR/realized range, so a near-zero
denominator during a real low-vol coil inflates confidence instead of
reducing it, on ordinary days generally, not just at the 14 flagged
reversal points.

**Shipped.** Wired `is_grinding_now()` into `generate_signal()`
(`composite_signal.py`): when flagged, a fired CALL/PUT is downgraded to
NONE (direction/confidence/votes are left completely unchanged, so
`record_outcome()`/adaptive-weight learning is unaffected -- only the
tradeable classification changes). Added `FinalSignal.grind_suppressed`
so this is visible/auditable rather than a silent override. Is a
complete no-op whenever `intraday_df` isn't supplied, so the validated
3-year daily backtest is unaffected by construction (added a test that
asserts the check is never even called in that path). 4 new tests in
`tests/test_composite_signal.py` (`TestGrindGate`), full suite now
239/239. State backed up first (`/tmp/voter_weights_backup_20260821_v2.
json`, `/tmp/scenario_history_backup_20260821_v2.json`) though this
change doesn't touch either file's shape.

**Important honesty check -- re-ran the ORIGINAL 14-point reversal
benchmark against the real, now-wired `generate_signal()` (not a
simulation) before calling this done:** wrong-signal-at-point is still
6/14, never-caught is still 6/14 -- unchanged from the unpatched
baseline, including today's exact 2:30pm case (the gate suppressed a
nearby checkpoint in that window, but not the 2:30pm checkpoint itself
-- same reason the ATR gate missed it: by the moment of the worst call,
realized vol had already ticked up just enough to clear this gate's
ceiling too). **So: this is a real, validated, shipped improvement to
general day-to-day accuracy (fewer bad low-conviction trades in genuine
coils), but it is NOT a fix for the specific reversal-point complaint
Will raised today.** Those remain two different problems -- one now has
a real, if partial, answer; the other still doesn't.

This mirrors the lesson from the ATR-gate regression check earlier
today, now doubly confirmed: a mechanism that looks right on the
trouble cases needs to be checked against ordinary days before it's
trusted (reversal points are a biased sample -- grinds that happened to
reverse, most grinds don't), AND a mechanism validated on ordinary days
doesn't automatically transfer back to the trouble cases either. The
two gates tried today (ATR-percentile: helps the 14 points, fails
broad regression; realized-vol grind flag: passes broad regression,
doesn't help the 14 points) are evidence these are measuring genuinely
different things -- worth a combined criterion in a future session
rather than assuming either one alone is the answer.
