"""
Price-action voter: pure OHLC-geometry reads that don't overlap with the
project's other price-action voters. Scope picked via AskUserQuestion
(Will, 2026-08-20) -- three independently-gated reads, checked in
priority order and returning the first that fires (same waterfall
pattern as vwap_reversion.py, since only one is likely live on a given
bar and a blended score across unrelated mechanisms would be harder to
reason about than "here's the single strongest thing that just
happened").

Why these three and not something candlestick_patterns.py or
support_resistance.py already do:
  1. Liquidity sweep / stop hunt -- a SAME-BAR pierce-and-reject past a
     recent high/low. support_resistance.py's bounce read needs the
     approach + reaction to unfold over several resampled bars; this
     fires the instant the wick prints, before that confirmation exists.
  2. Momentum thrust -- N consecutive same-direction closes with
     non-doji bodies. adaptive_supertrend reads a smoothed trailing
     band; market_structure reads swing-point HH/HL/LH/LL classification.
     Neither reads raw bar-to-bar persistence directly.
  3. Range compression -> expansion -- an NR-N volatility squeeze
     followed by a directional breakout. None of the other voters treat
     volatility contraction itself as informative.

All three read `resample_rule`-resampled bars (default 5-min, the same
default adaptive_supertrend/anchored_vwap_swings landed on after
checking raw 1-min was too noisy for THEM) -- this is a starting
assumption, not yet verified for this specific voter; see
daily_reviews.md for whatever the empirical evaluation found and
whether the default held.
"""

from dataclasses import dataclass

import numpy as np
import pandas as pd

from candlestick_patterns import resample_ohlc
from indicator import atr as wilder_atr
from voters import Vote, neutral_vote


@dataclass
class PriceActionConfig:
    atr_length: int = 14
    compression_window: int = 7              # NR-N: current bar's range must be the tightest of the last N
    compression_expansion_mult: float = 1.5   # breakout bar's range vs. the squeeze bar's range
    compression_breakout_atr_mult: float = 0.1  # close must clear the squeeze bar's high/low by this much ATR
    sweep_lookback: int = 6                   # bars defining "recent" high/low for the sweep read
    sweep_pierce_atr_mult: float = 0.15       # min wick pierce beyond that level, in ATR
    sweep_close_back_atr_mult: float = 0.05   # how far back inside the level the close must land
    thrust_min_consecutive: int = 4           # consecutive same-direction closes to call a thrust
    thrust_body_atr_floor_mult: float = 0.1   # bodies smaller than this (in ATR) don't extend the streak


def compute_price_action(df: pd.DataFrame, cfg: PriceActionConfig = None) -> pd.DataFrame:
    """Per-bar columns, causal only -- every rolling window is trailing
    and inclusive of the current bar, so no future data touches any
    row (verified by the no-lookahead test)."""
    cfg = cfg or PriceActionConfig()
    out = df.copy()
    high, low, close, open_ = out["High"], out["Low"], out["Close"], out["Open"]

    atr = wilder_atr(out, period=cfg.atr_length).replace(0, np.nan)
    rng = high - low
    body = (close - open_).abs()

    # --- range compression / expansion ---
    window_min = rng.rolling(cfg.compression_window).min()
    is_nr = rng <= window_min
    prior_is_nr = is_nr.shift(1).fillna(False)
    prior_range = rng.shift(1)
    prior_high = high.shift(1)
    prior_low = low.shift(1)
    expanded_enough = rng >= cfg.compression_expansion_mult * prior_range
    breakout_up = prior_is_nr & expanded_enough & (close > prior_high + cfg.compression_breakout_atr_mult * atr)
    breakout_down = prior_is_nr & expanded_enough & (close < prior_low - cfg.compression_breakout_atr_mult * atr)

    # --- liquidity sweep / stop hunt ---
    prior_n_high = high.shift(1).rolling(cfg.sweep_lookback).max()
    prior_n_low = low.shift(1).rolling(cfg.sweep_lookback).min()
    sweep_high = (high > prior_n_high + cfg.sweep_pierce_atr_mult * atr) & \
                 (close < prior_n_high - cfg.sweep_close_back_atr_mult * atr)
    sweep_low = (low < prior_n_low - cfg.sweep_pierce_atr_mult * atr) & \
                (close > prior_n_low + cfg.sweep_close_back_atr_mult * atr)

    # --- momentum thrust ---
    close_up = close > close.shift(1)
    close_down = close < close.shift(1)
    has_body = body >= cfg.thrust_body_atr_floor_mult * atr
    up_bar = (close_up & has_body).to_numpy()
    down_bar = (close_down & has_body).to_numpy()

    up_streak = np.zeros(len(out), dtype=int)
    down_streak = np.zeros(len(out), dtype=int)
    for i in range(len(out)):
        if up_bar[i]:
            up_streak[i] = up_streak[i - 1] + 1 if i > 0 else 1
        if down_bar[i]:
            down_streak[i] = down_streak[i - 1] + 1 if i > 0 else 1

    out["atr"] = atr
    out["range"] = rng
    out["is_nr"] = is_nr
    out["prior_n_high"] = prior_n_high
    out["prior_n_low"] = prior_n_low
    out["breakout_up"] = breakout_up.fillna(False)
    out["breakout_down"] = breakout_down.fillna(False)
    out["sweep_high"] = sweep_high.fillna(False)
    out["sweep_low"] = sweep_low.fillna(False)
    out["up_streak"] = up_streak
    out["down_streak"] = down_streak
    return out


VOTER_RESAMPLE_RULE = "5min"
VOTER_CONFIG = PriceActionConfig()
MIN_RESAMPLED_BARS = 20  # ~100 minutes of 5-min bars, same floor as adaptive_supertrend/anchored_vwap_swings


def price_action_vote(intraday_df: pd.DataFrame, cfg: PriceActionConfig = None,
                       resample_rule: str = VOTER_RESAMPLE_RULE) -> Vote:
    """Checks liquidity sweep, then range-expansion breakout, then
    momentum thrust, in that order, and returns the first that fires --
    see module docstring for why. Confidence tiering: a sweep (the
    sharpest, rarest event -- price already reversed same-bar) is
    highest; a breakout is a definitive but less-proven event; a fresh
    thrust is next; a thrust that's still extending gets progressively
    less confidence, on the theory that a long streak is closer to
    exhausted than a fresh one. A pure squeeze with no breakout yet, or
    a bar with no read at all, returns confidence 0 with an honest
    reason -- never a forced opinion."""
    if intraday_df is None or len(intraday_df) < 5:
        return neutral_vote("price_action", "not enough intraday bars yet")

    resampled = resample_ohlc(intraday_df, resample_rule)
    if len(resampled) < MIN_RESAMPLED_BARS:
        return neutral_vote("price_action", f"not enough {resample_rule} bars yet to trust range/streak reads")

    cfg = cfg or VOTER_CONFIG
    out = compute_price_action(resampled, cfg)
    last = out.iloc[-1]
    detail_base = {
        "resample_rule": resample_rule,
        "atr": None if pd.isna(last["atr"]) else round(float(last["atr"]), 4),
    }

    if bool(last["sweep_high"]):
        return Vote(name="price_action", direction=-1.0, confidence=0.5, regime_tag="liquidity_sweep_high",
                    detail={**detail_base, "swept_level": round(float(last["prior_n_high"]), 4)})
    if bool(last["sweep_low"]):
        return Vote(name="price_action", direction=1.0, confidence=0.5, regime_tag="liquidity_sweep_low",
                    detail={**detail_base, "swept_level": round(float(last["prior_n_low"]), 4)})

    if bool(last["breakout_up"]):
        return Vote(name="price_action", direction=1.0, confidence=0.4, regime_tag="range_expansion_up",
                    detail={**detail_base, "range": round(float(last["range"]), 4)})
    if bool(last["breakout_down"]):
        return Vote(name="price_action", direction=-1.0, confidence=0.4, regime_tag="range_expansion_down",
                    detail={**detail_base, "range": round(float(last["range"]), 4)})

    up_streak = int(last["up_streak"])
    down_streak = int(last["down_streak"])
    if up_streak >= cfg.thrust_min_consecutive:
        fresh = up_streak == cfg.thrust_min_consecutive
        confidence = 0.45 if fresh else max(0.15, 0.45 - 0.03 * (up_streak - cfg.thrust_min_consecutive))
        return Vote(name="price_action", direction=1.0, confidence=confidence,
                    regime_tag="momentum_thrust_up" if fresh else "momentum_thrust_up_continuation",
                    detail={**detail_base, "consecutive_closes": up_streak})
    if down_streak >= cfg.thrust_min_consecutive:
        fresh = down_streak == cfg.thrust_min_consecutive
        confidence = 0.45 if fresh else max(0.15, 0.45 - 0.03 * (down_streak - cfg.thrust_min_consecutive))
        return Vote(name="price_action", direction=-1.0, confidence=confidence,
                    regime_tag="momentum_thrust_down" if fresh else "momentum_thrust_down_continuation",
                    detail={**detail_base, "consecutive_closes": down_streak})

    if bool(last["is_nr"]):
        return Vote(name="price_action", direction=0.0, confidence=0.0, regime_tag="range_compressing",
                    detail={**detail_base, "reason": f"NR{cfg.compression_window} squeeze forming, no breakout yet"})

    return neutral_vote("price_action", "no sweep, breakout, or thrust on this bar")
