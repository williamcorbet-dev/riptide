"""
Black-Scholes pricing utilities used to approximate 1DTE option premiums
in the backtest, since free historical options-chain data isn't generally
available. See README.md for the limitations of this approach.
"""

import numpy as np
from scipy.stats import norm


def bs_price(S: float, K: float, T: float, r: float, sigma: float, option_type: str = "call") -> float:
    """Black-Scholes theoretical price. T is time to expiration in years.

    Falls back to intrinsic value at/after expiration (T <= 0) or when
    sigma <= 0, to avoid divide-by-zero.
    """
    if T <= 0 or sigma <= 0:
        if option_type == "call":
            return max(0.0, S - K)
        return max(0.0, K - S)

    d1 = (np.log(S / K) + (r + 0.5 * sigma ** 2) * T) / (sigma * np.sqrt(T))
    d2 = d1 - sigma * np.sqrt(T)

    if option_type == "call":
        return S * norm.cdf(d1) - K * np.exp(-r * T) * norm.cdf(d2)
    return K * np.exp(-r * T) * norm.cdf(-d2) - S * norm.cdf(-d1)


def nearest_strike(spot: float, increment: float = 1.0) -> float:
    """Round spot to the nearest listed strike increment (SPY lists $1
    strikes near the money)."""
    return round(spot / increment) * increment
