# Project name: Riptide

Will named this SPY 1DTE directional indicator "Riptide" on 2026-08-21 --
use that name when talking about it instead of "the indicator." Fits the
theme: an undercurrent pulling against the visible surface move, which is
exactly the grind-then-reversal pattern this project has spent the most
effort on (see daily_reviews.md, 2026-08-21 entries).
