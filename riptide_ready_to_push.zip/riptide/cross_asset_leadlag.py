"""
Cross-asset lead-lag scanner.

SPY doesn't move in a vacuum. Overnight index futures, the handful of
mega-cap names that dominate the S&P 500's weight, treasury yields, and
the dollar all sometimes carry information that reaches the tape before
SPY's own price fully reflects it. Rather than assuming any particular
instrument leads by fiat, this module measures -- empirically, per
candidate leader, from the same free daily OHLCV data as everything else
-- how predictive each one's OWN recent return has actually been for
SPY's NEXT return, and only weights a leader's current signal by however
much lead-lag correlation it has actually shown historically.

Fully backtestable: every input here is ordinary daily OHLCV via yfinance,
same as the technical/Hurst/HMM voters.
"""

import numpy as np
import pandas as pd

from voters import Vote

# QQQ: proxy for mega-cap tech / Nasdaq-style lead
# AAPL/MSFT/NVDA: individually large enough to move SPX/SPY mechanically
#   given their index weight, and often move on their own news first
# TLT: long-bond ETF, an inverse-ish proxy for the 10Y yield
# UUP: dollar index ETF
DEFAULT_LEADERS = ["QQQ", "AAPL", "MSFT", "NVDA", "TLT", "UUP"]


def compute_leadlag_strength(leader_close: pd.Series, target_close: pd.Series, lookback: int = 250) -> float:
    """Correlation between the leader's return on day t and the target's
    return on day t+1, over the trailing `lookback` days. Positive means
    the leader's move tends to precede a same-direction move in the
    target the next day; negative means it tends to precede an opposite-
    direction move (still useful -- just invert the read)."""
    leader_ret = np.log(leader_close / leader_close.shift(1))
    target_ret = np.log(target_close / target_close.shift(1))
    aligned = pd.concat(
        [leader_ret.shift(1), target_ret], axis=1, keys=["leader_lag1", "target"]
    ).dropna()
    if len(aligned) < 30:
        return np.nan
    window = aligned.iloc[-lookback:]
    corr = window["leader_lag1"].corr(window["target"])
    return float(corr) if not np.isnan(corr) else 0.0


def leadlag_vote(leader_data: dict, target_close: pd.Series, lookback: int = 250,
                  min_abs_corr: float = 0.05, strong_corr: float = 0.30) -> Vote:
    """
    leader_data: {ticker: pd.Series of Close prices} -- need not share
        target_close's exact index; each is reindexed/forward-filled to it.
    target_close: the traded instrument's (e.g. SPY's) Close series.

    Only leaders whose historical |correlation| clears `min_abs_corr` get
    a say at all -- most candidate leaders on most days will show no real
    lead-lag relationship, and should be silently excluded rather than
    forced to vote noise.
    """
    contributions = []
    detail_per_leader = {}

    for ticker, leader_close in leader_data.items():
        aligned_leader = leader_close.reindex(target_close.index).ffill().dropna()
        if len(aligned_leader) < 30:
            detail_per_leader[ticker] = {"used": False, "reason": "insufficient overlapping history"}
            continue

        corr = compute_leadlag_strength(aligned_leader, target_close, lookback)
        if np.isnan(corr) or abs(corr) < min_abs_corr:
            detail_per_leader[ticker] = {"correlation": corr, "used": False}
            continue

        leader_ret = float(np.log(aligned_leader.iloc[-1] / aligned_leader.iloc[-2]))
        # If historical correlation is negative, this leader is an inverse
        # indicator -- flip its current move before counting it.
        signal = float(np.sign(leader_ret) * np.sign(corr))
        weight = min(1.0, abs(corr) / strong_corr)
        contributions.append((signal, weight))
        detail_per_leader[ticker] = {
            "correlation": corr, "leader_return": leader_ret, "weight": weight, "used": True,
        }

    if not contributions:
        return Vote(
            name="cross_asset_leadlag", direction=0.0, confidence=0.0,
            detail={"reason": "no leader showed meaningful historical lead-lag correlation",
                    "per_leader": detail_per_leader},
        )

    weight_total = sum(w for _, w in contributions)
    weighted_sum = sum(s * w for s, w in contributions)
    direction = float(np.clip(weighted_sum / weight_total, -1, 1)) if weight_total > 0 else 0.0

    agreeing_weight = sum(w for s, w in contributions if np.sign(s) == np.sign(direction) and direction != 0)
    agreement = (agreeing_weight / weight_total) if weight_total > 0 else 0.0
    breadth = len(contributions) / max(len(leader_data), 1)  # how many candidates actually had a real signal
    confidence = float(min(1.0, agreement * (0.5 + 0.5 * breadth)))

    return Vote(
        name="cross_asset_leadlag",
        direction=direction if confidence > 0 else 0.0,
        confidence=confidence,
        regime_tag="leaders_agree" if agreement > 0.75 and len(contributions) > 1 else None,
        detail={"per_leader": detail_per_leader, "n_leaders_used": len(contributions)},
    )
