"""
Dynamic intraday support/resistance.

Classic technical analysis, but computed fresh from the actual day's price
action rather than hand-drawn: swing highs and lows that form during the
session ARE the levels, and how price behaves the next time it revisits
one -- bouncing (rejected) or breaking through (continuing) -- is the
vote. Levels are found on RESAMPLED bars (5-minute by default), not raw
1-minute data, for the same "too much noise below 3 minutes" reason the
candlestick engine excludes anything faster. Because levels are
recomputed from live intraday data on every call, they naturally shift
during the day as new swings form -- there is no fixed "today's support
is $X" table to maintain; today's data IS the table.

Two honest limitations, stated up front rather than hidden:

1. A swing point can only be CONFIRMED once `order` bars exist on both
   sides of it on the resample timeframe -- e.g. order=3 on 5-minute bars
   means a swing isn't confirmed until 15 minutes after it happened. You
   cannot know in real time that a bar was a local extreme until you've
   seen what came after it. Prior-day daily High/Low/Close are included
   as additional seed levels specifically because they don't have this
   lag -- they're known the instant the session opens.

2. Bounce vs. breakout is inherently uncertain in real time. This module
   only calls a bounce once the most recent bar has actually ticked back
   away from the level (not just "hasn't broken yet," which could just be
   sitting flat), and it deliberately caps breakout confidence lower than
   bounce confidence, since intraday false breakouts are common.
"""

from dataclasses import dataclass
from typing import List, Optional

import numpy as np
import pandas as pd

from candlestick_patterns import resample_ohlc
from voters import Vote, neutral_vote


@dataclass
class Level:
    price: float
    strength: int              # number of swing touches clustered into this level
    last_touch: pd.Timestamp
    source: str                 # "swing", "prior_day_high"/"prior_day_low"/"prior_day_close", or a "+"-joined mix


def find_swing_points(df: pd.DataFrame, order: int = 3) -> pd.DataFrame:
    """`df` should already be resampled to the desired base timeframe --
    this does not resample itself. Returns `df` with `swing_high`/
    `swing_low` boolean columns. A swing point is only confirmed once
    `order` bars exist on both sides of it -- see module docstring."""
    high, low = df["High"], df["Low"]
    n = len(df)
    swing_high = np.zeros(n, dtype=bool)
    swing_low = np.zeros(n, dtype=bool)
    for i in range(order, n - order):
        window_h = high.iloc[i - order:i + order + 1]
        window_l = low.iloc[i - order:i + order + 1]
        if high.iloc[i] == window_h.max() and (window_h == high.iloc[i]).sum() == 1:
            swing_high[i] = True
        if low.iloc[i] == window_l.min() and (window_l == low.iloc[i]).sum() == 1:
            swing_low[i] = True
    out = df.copy()
    out["swing_high"] = swing_high
    out["swing_low"] = swing_low
    return out


def build_levels(intraday_df: pd.DataFrame, atr: float, timeframe: str = "5min",
                  order: int = 3, cluster_atr_mult: float = 0.25,
                  prior_day_levels: Optional[dict] = None) -> List[Level]:
    """Builds today's support/resistance levels from confirmed swing
    points on `timeframe`-resampled bars, optionally seeded with the
    prior day's High/Low/Close (`prior_day_levels`, e.g.
    `{"high": ..., "low": ..., "close": ...}`) -- classic reference
    levels that don't need swing confirmation to be valid from bar one."""
    atr = max(atr, 1e-6)
    touches = []  # (price, timestamp, source)

    if prior_day_levels and len(intraday_df) > 0:
        seed_ts = intraday_df.index[0]
        for name, price in prior_day_levels.items():
            if price is not None and not (isinstance(price, float) and np.isnan(price)):
                touches.append((float(price), seed_ts, f"prior_day_{name}"))

    resampled = resample_ohlc(intraday_df, timeframe)
    if len(resampled) >= 2 * order + 1:
        swings = find_swing_points(resampled, order=order)
        for ts, row in swings.iterrows():
            if row["swing_high"]:
                touches.append((float(row["High"]), ts, "swing"))
            if row["swing_low"]:
                touches.append((float(row["Low"]), ts, "swing"))

    if not touches:
        return []

    # Simple greedy 1D clustering: sort by price, merge points within
    # cluster_atr_mult * atr of the running cluster's mean.
    touches.sort(key=lambda t: t[0])
    clusters = []
    for price, ts, source in touches:
        if clusters and abs(price - clusters[-1]["mean"]) <= cluster_atr_mult * atr:
            c = clusters[-1]
            c["prices"].append(price)
            c["mean"] = float(np.mean(c["prices"]))
            c["last_touch"] = max(c["last_touch"], ts)
            c["sources"].add(source)
        else:
            clusters.append({"prices": [price], "mean": price, "last_touch": ts, "sources": {source}})

    return [
        Level(price=c["mean"], strength=len(c["prices"]), last_touch=c["last_touch"],
              source="+".join(sorted(c["sources"])))
        for c in clusters
    ]


def support_resistance_vote(intraday_df: pd.DataFrame, atr: float, timeframe: str = "5min",
                             order: int = 3, proximity_atr_mult: float = 0.3,
                             lookback_bars: int = 4, prior_day_levels: dict = None) -> Vote:
    """Finds the nearest known level to the current price and reads
    whether the last few bars are bouncing off it or breaking through
    it. Returns a neutral (confidence 0) vote, with an honest reason, at
    every stage where there isn't yet a real read: too little data, no
    confirmed levels yet, not currently near any level, or at a level
    with no clear resolution yet."""
    if intraday_df is None or len(intraday_df) < 2:
        return neutral_vote("support_resistance", "not enough intraday bars yet")

    atr = max(atr, 1e-6)
    levels = build_levels(intraday_df, atr, timeframe=timeframe, order=order, prior_day_levels=prior_day_levels)
    if not levels:
        return neutral_vote("support_resistance", "no confirmed levels yet today")

    price_now = float(intraday_df["Close"].iloc[-1])
    nearest = min(levels, key=lambda lv: abs(lv.price - price_now))
    distance_atr = abs(price_now - nearest.price) / atr
    if distance_atr > proximity_atr_mult:
        return Vote(
            name="support_resistance", direction=0.0, confidence=0.0,
            detail={"reason": "not currently near a known level", "nearest_level": nearest.price,
                    "distance_atr": round(distance_atr, 3), "n_levels_tracked": len(levels)},
        )

    resampled = resample_ohlc(intraday_df, timeframe)
    if len(resampled) < 2:
        return neutral_vote("support_resistance", "not enough resampled bars to read the approach")

    lookback = min(lookback_bars, len(resampled) - 1)
    price_then = float(resampled["Close"].iloc[-1 - lookback])
    last_close = float(resampled["Close"].iloc[-1])
    prev_close = float(resampled["Close"].iloc[-2])

    approached_from_above = price_then > nearest.price
    approached_from_below = price_then < nearest.price
    broke_below = last_close < nearest.price - 0.1 * atr
    broke_above = last_close > nearest.price + 0.1 * atr
    ticking_up = last_close > prev_close
    ticking_down = last_close < prev_close

    strength_conf = min(1.0, nearest.strength / 4)
    detail_base = {"level": round(nearest.price, 4), "strength": nearest.strength,
                    "source": nearest.source, "distance_atr": round(distance_atr, 3)}

    if approached_from_above and not broke_below and ticking_up:
        return Vote(
            name="support_resistance", direction=min(1.0, 0.4 + 0.5 * strength_conf),
            confidence=min(0.85, 0.35 + 0.5 * strength_conf), regime_tag="bounce_support",
            detail=detail_base,
        )
    if approached_from_below and not broke_above and ticking_down:
        return Vote(
            name="support_resistance", direction=-min(1.0, 0.4 + 0.5 * strength_conf),
            confidence=min(0.85, 0.35 + 0.5 * strength_conf), regime_tag="bounce_resistance",
            detail=detail_base,
        )

    recent_move = last_close - prev_close
    if broke_below and ticking_down:
        detail_base["note"] = "intraday breakouts are noisy -- confidence capped below bounce confidence"
        return Vote(
            name="support_resistance", direction=-min(1.0, 0.3 + abs(recent_move) / atr),
            confidence=min(0.6, 0.25 + abs(recent_move) / atr), regime_tag="breakdown",
            detail=detail_base,
        )
    if broke_above and ticking_up:
        detail_base["note"] = "intraday breakouts are noisy -- confidence capped below bounce confidence"
        return Vote(
            name="support_resistance", direction=min(1.0, 0.3 + abs(recent_move) / atr),
            confidence=min(0.6, 0.25 + abs(recent_move) / atr), regime_tag="breakout",
            detail=detail_base,
        )

    detail_base["reason"] = "at a known level but no clear bounce/break resolution yet"
    return Vote(name="support_resistance", direction=0.0, confidence=0.0,
                 regime_tag="at_level_undecided", detail=detail_base)
