"""
Backtest the SPY 1DTE composite indicator.

Data source:
  --source yfinance   (default; requires `pip install yfinance` and internet access)
  --source csv        (columns: Date,Open,High,Low,Close,Volume -- pass --csv-path.
                        Also accepts Nasdaq.com's free historical-data export format
                        directly -- "Date,Close/Last,Volume,Open,High,Low", newest-
                        first, prices optionally "$"-prefixed -- no reformatting needed.)

The indicator is evaluated on daily bars. Each signal is treated as an
entry at that day's close, priced with Black-Scholes at the nearest strike,
and held to the next trading day's close (approximating next-day expiration,
i.e. the worst-case theta scenario since it assumes no earlier exit).
See README.md for why this is an approximation, not a precise historical
options backtest.

Usage:
    python backtest.py --source yfinance --ticker SPY --period 3y
    python backtest.py --source csv --csv-path my_spy_daily.csv
"""

import argparse

import numpy as np
import pandas as pd

from indicator import IndicatorConfig, compute_indicator
from options_pricing import bs_price, nearest_strike


def load_data(source: str, csv_path: str = None, ticker: str = "SPY",
              period: str = "2y", interval: str = "1d") -> pd.DataFrame:
    if source == "yfinance":
        import yfinance as yf

        df = yf.download(ticker, period=period, interval=interval,
                          auto_adjust=False, progress=False)
        if isinstance(df.columns, pd.MultiIndex):
            df.columns = df.columns.get_level_values(0)
    else:
        if not csv_path:
            raise ValueError("--csv-path is required when --source csv")
        df = pd.read_csv(csv_path, parse_dates=[0], index_col=0)

        # Nasdaq.com's free historical-data export uses "Close/Last" instead
        # of "Close", sometimes "$"-prefixes prices, and lists newest-first
        # -- normalize all of that so it's a drop-in --source csv input
        # without the user needing to reformat anything by hand.
        df = df.rename(columns={"Close/Last": "Close", "Close/last": "Close"})
        for col in ("Open", "High", "Low", "Close"):
            if col in df.columns and df[col].dtype == object:
                df[col] = df[col].astype(str).str.replace("$", "", regex=False).astype(float)
        df = df.sort_index()

    df = df.rename(columns=str.title)
    df = df[["Open", "High", "Low", "Close", "Volume"]].dropna()
    return df


def simulate_trades(ind: pd.DataFrame, assumed_iv: float = 0.16, iv_markup: float = 1.15,
                     r: float = 0.05, strike_increment: float = 1.0,
                     hours_to_expiry: float = 24.0) -> pd.DataFrame:
    """
    ind: output of compute_indicator() on DAILY bars. For each non-NONE
    signal on day i, enters an ATM option at day i's close and marks it to
    intrinsic value at day i+1's close (next-day expiration).

    assumed_iv / iv_markup: since real historical 1DTE implied vol isn't
    used here, entry premium is priced with (trailing-vol-free) assumed_iv
    scaled up by iv_markup to roughly reflect the fact that short-dated IV
    usually trades above realized vol. Tune these to your own data if you
    have real IV history.
    """
    trades = []
    idx = ind.index
    for i in range(len(ind) - 1):
        sig = ind["signal"].iloc[i]
        if sig == "NONE":
            continue

        entry_spot = float(ind["Close"].iloc[i])
        exit_spot = float(ind["Close"].iloc[i + 1])
        option_type = "call" if sig == "CALL" else "put"
        strike = nearest_strike(entry_spot, strike_increment)

        iv = assumed_iv * iv_markup
        t_entry = hours_to_expiry / (24 * 365)
        entry_premium = bs_price(entry_spot, strike, t_entry, r, iv, option_type)
        exit_value = (max(0.0, exit_spot - strike) if option_type == "call"
                      else max(0.0, strike - exit_spot))

        pnl = exit_value - entry_premium
        pnl_pct = pnl / entry_premium if entry_premium > 0 else np.nan

        trades.append({
            "entry_date": idx[i],
            "exit_date": idx[i + 1],
            "signal": sig,
            "score": float(ind["score"].iloc[i]),
            "entry_spot": entry_spot,
            "exit_spot": exit_spot,
            "strike": strike,
            "entry_premium": entry_premium,
            "exit_value": exit_value,
            "pnl": pnl,
            "pnl_pct": pnl_pct,
        })

    return pd.DataFrame(trades)


def summarize(trades: pd.DataFrame) -> None:
    if trades.empty:
        print("No trades were generated. Try lowering signal_threshold in IndicatorConfig.")
        return

    win_rate = (trades["pnl"] > 0).mean()
    avg_pnl_pct = trades["pnl_pct"].mean()
    median_pnl_pct = trades["pnl_pct"].median()
    naive_compounded = (1 + trades["pnl_pct"].fillna(-1)).prod() - 1

    print(f"Trades:                {len(trades)}")
    print(f"Win rate:               {win_rate:.1%}")
    print(f"Avg P&L per trade:      {avg_pnl_pct:.1%}")
    print(f"Median P&L per trade:   {median_pnl_pct:.1%}")
    print(f"Naive compounded return: {naive_compounded:.1%}")
    print("  (assumes 100% of size re-risked every trade back-to-back -- unrealistic,")
    print("   shown only as a rough directional-edge summary, not a P&L projection)")
    print()
    print(trades.groupby("signal")["pnl_pct"].agg(["count", "mean", "median"]))

    if "sized_pnl_dollars" in trades.columns:
        total_dollar_pnl = trades["sized_pnl_dollars"].sum()
        zero_sized = int((trades["contracts"] == 0).sum())
        print()
        print(f"Risk-sized total P&L:   ${total_dollar_pnl:,.0f}  "
              f"(via risk_management.size_position(), NOT re-risking growth -- "
              f"a fixed-fraction-of-account budget per trade)")
        if zero_sized:
            print(f"  {zero_sized}/{len(trades)} signals sized to 0 contracts "
                  f"(risk budget too small at that premium/confidence) and were skipped")
        print("  Note: this only sizes entries -- it does NOT simulate the stop-loss/")
        print("  profit-target/trailing-stop exit rules mid-trade (no intraday bars here).")


def plot_equity_curve(trades: pd.DataFrame, out_path: str = "equity_curve.png") -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    if trades.empty:
        return

    equity = (1 + trades["pnl_pct"].fillna(-1)).cumprod()
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.plot(trades["entry_date"], equity, marker="o", markersize=3)
    ax.set_title("Naive equity curve (100% re-risked each trade) -- illustrative only")
    ax.set_ylabel("Growth of $1")
    ax.set_xlabel("Entry date")
    ax.grid(alpha=0.3)
    fig.autofmt_xdate()
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    print(f"Saved equity curve to {out_path}")


def simulate_ensemble_trades(daily_df: pd.DataFrame, vix_df: pd.DataFrame = None,
                              leader_data: dict = None, risk_cfg=None, chain_by_date: dict = None,
                              refit_every: int = 5, assumed_iv: float = 0.16, iv_markup: float = 1.15,
                              r: float = 0.05, strike_increment: float = 1.0, hours_to_expiry: float = 24.0,
                              min_history: int = 260, learn: bool = True) -> pd.DataFrame:
    """Walk-forward backtest of the FULL ENSEMBLE (composite_signal.py) --
    but only the modules that are honestly backtestable for free: technical
    composite, Hurst regime, HMM regime, FOMC calendar, VIX term structure
    (if `vix_df` is supplied), and cross-asset lead-lag (if `leader_data`
    is supplied -- daily OHLCV only, so it's fully backtestable too).
    Gamma positioning, vanna/charm, put/call ratio, and skew dynamics
    normally sit out for every day (no free historical chain data) -- but
    if `chain_by_date` is supplied (a {date: ChainSnapshot}, see
    historical_chain.build_chain_lookup_from_dir()) those voters DO run,
    for real, on whichever days a chain is available. Days without an
    entry in `chain_by_date` still degrade honestly to a neutral vote,
    same as before -- this only adds coverage, never fabricates it.

    `leader_data`: {ticker: pd.Series of Close}, full history -- each
    leader's series is truncated to `daily_df.index[i]` inside the loop
    before being handed to the ensemble, so no future leader data leaks
    into a past day's signal (same point-in-time discipline as `daily_df`
    itself via `.iloc[:i + 1]`).

    `risk_cfg`: if supplied (a risk_management.RiskConfig), each non-NONE
    signal is also sized via risk_management.size_position() using the
    same Black-Scholes-approximated entry premium already computed for the
    trade -- adds `contracts`/`dollar_risk`/`sized_pnl_dollars` columns so
    you can see what the risk layer would have actually done, not just the
    raw per-contract P&L%. This only sizes; it can't simulate the
    stop-loss/profit-target/trailing-stop exit rules mid-trade, since this
    backtest only has daily (not intraday) bars -- see README.

    `refit_every`: the HMM and Hurst estimators are refit from scratch on
    every evaluated day, which is not cheap. To keep multi-year backtests
    tractable, the ensemble is only evaluated every `refit_every` trading
    days by default (set to 1 for an exhaustive day-by-day backtest, at
    the cost of runtime).

    `learn`: if True, each realized outcome is fed back into the scenario
    engine and adaptive voter weights via record_outcome() AS THE BACKTEST
    WALKS FORWARD -- so later trades in the backtest benefit from what the
    system learned on earlier trades, same as it would in live use. This
    also means running the backtest is itself a way of building up the
    persistent state in `state/`.
    """
    from composite_signal import SignalInputs, generate_signal
    from scenario_engine import ScenarioStore, AdaptiveWeights, record_outcome as _record_outcome
    from risk_management import size_position
    from vanna_charm import VannaCharmHistoryStore
    from skew_dynamics import SkewHistoryStore

    scenario_store = ScenarioStore()
    adaptive_weights = AdaptiveWeights()
    # Real (not throwaway) stores -- same "walking the backtest forward IS
    # how this accumulates real history" philosophy as scenario_store/
    # adaptive_weights above, so a long --chain-dir backtest naturally
    # earns vanna_charm/skew_dynamics real confidence once it's walked past
    # ~20 days with a chain available, instead of every day reporting "no
    # history yet." Passed explicitly (rather than relying on skew_vote's
    # own default) so this is a documented design choice, not an accident
    # of what the default happens to be.
    vanna_charm_store = VannaCharmHistoryStore()
    skew_store = SkewHistoryStore()

    trades = []
    idx = daily_df.index
    for i in range(min_history, len(daily_df) - 1, refit_every):
        window_df = daily_df.iloc[:i + 1]
        window_vix = vix_df.iloc[:i + 1] if vix_df is not None else None
        # Point-in-time slice: only leader data up to (and including) today
        # is visible -- prevents look-ahead bias from the full leader
        # history that was fetched once up front.
        window_leaders = ({t: s.loc[:idx[i]] for t, s in leader_data.items()}
                           if leader_data else None)
        today = idx[i].date()
        chain = chain_by_date.get(today) if chain_by_date else None
        inputs = SignalInputs(daily_df=window_df, vix_df=window_vix, leader_data=window_leaders,
                               chain=chain, vanna_charm_store=vanna_charm_store,
                               skew_store=skew_store, today=today)
        sig = generate_signal(inputs, scenario_store=scenario_store, adaptive_weights=adaptive_weights)

        entry_spot = float(daily_df["Close"].iloc[i])
        exit_spot = float(daily_df["Close"].iloc[i + 1])
        realized_return = float(np.log(exit_spot / entry_spot))

        if learn:
            _record_outcome(sig, realized_return, scenario_store=scenario_store, adaptive_weights=adaptive_weights)

        if sig.signal == "NONE":
            continue

        option_type = "call" if sig.signal == "CALL" else "put"
        strike = nearest_strike(entry_spot, strike_increment)
        iv = assumed_iv * iv_markup
        t_entry = hours_to_expiry / (24 * 365)
        entry_premium = bs_price(entry_spot, strike, t_entry, r, iv, option_type)
        exit_value = (max(0.0, exit_spot - strike) if option_type == "call"
                      else max(0.0, strike - exit_spot))
        pnl = exit_value - entry_premium
        pnl_pct = pnl / entry_premium if entry_premium > 0 else np.nan

        row = {
            "entry_date": idx[i], "exit_date": idx[i + 1], "signal": sig.signal,
            "direction": sig.direction, "confidence": sig.confidence, "method": sig.method,
            "entry_spot": entry_spot, "exit_spot": exit_spot, "strike": strike,
            "entry_premium": entry_premium, "exit_value": exit_value, "pnl": pnl, "pnl_pct": pnl_pct,
        }

        if risk_cfg is not None:
            size = size_position(sig, entry_premium=entry_premium, cfg=risk_cfg)
            row["contracts"] = size.contracts
            row["dollar_risk"] = size.dollar_risk
            row["sized_pnl_dollars"] = pnl * size.contracts * 100

        trades.append(row)

    return pd.DataFrame(trades)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--source", choices=["yfinance", "csv"], default="yfinance")
    ap.add_argument("--csv-path", default=None)
    ap.add_argument("--ticker", default="SPY")
    ap.add_argument("--period", default="3y")
    ap.add_argument("--interval", default="1d")
    ap.add_argument("--assumed-iv", type=float, default=0.16)
    ap.add_argument("--out", default="trades.csv")
    ap.add_argument("--plot", action="store_true")
    ap.add_argument("--ensemble", action="store_true",
                     help="run the full backtestable ensemble (technical+Hurst+HMM+FOMC[+VIX][+lead-lag]) "
                          "instead of the technical-only score")
    ap.add_argument("--refit-every", type=int, default=5,
                     help="ensemble mode only: re-evaluate every N trading days (HMM/Hurst refits are costly)")
    ap.add_argument("--no-leadlag", action="store_true",
                     help="ensemble mode only: skip fetching cross-asset leader history")
    ap.add_argument("--account-size", type=float, default=None,
                     help="ensemble mode only: if set, also sizes each trade via risk_management.py "
                          "and reports risk-sized $ P&L alongside the raw per-contract P&L%%")
    ap.add_argument("--chain-dir", default=None,
                     help="ensemble mode only: a folder containing Greek_YYYYMMDD_OData*.csv files "
                          "(see historical_chain.py) -- on days found there, gamma/vanna-charm/"
                          "put-call-ratio/skew all run against the REAL historical chain instead of "
                          "sitting out")
    ap.add_argument("--chain-symbol", default=None,
                     help="ticker to pull out of --chain-dir's files if it differs from --ticker "
                          "(defaults to --ticker)")
    args = ap.parse_args()

    df = load_data(args.source, args.csv_path, args.ticker, args.period, args.interval)

    if args.ensemble:
        vix_df = None
        leader_data = None
        if args.source == "yfinance":
            try:
                from vol_regime import fetch_vix_term_structure_yfinance
                vix_df = fetch_vix_term_structure_yfinance(period=args.period)
            except Exception as e:
                print(f"[warn] couldn't fetch VIX term structure ({e}); running without it")

            if not args.no_leadlag:
                from cross_asset_leadlag import DEFAULT_LEADERS
                leader_data = {}
                for ticker in DEFAULT_LEADERS:
                    try:
                        leader_data[ticker] = load_data("yfinance", ticker=ticker,
                                                         period=args.period, interval=args.interval)["Close"]
                    except Exception as e:
                        print(f"[warn] couldn't fetch leader {ticker} ({e}); skipping it")
                leader_data = leader_data or None

        risk_cfg = None
        if args.account_size is not None:
            from risk_management import RiskConfig
            risk_cfg = RiskConfig(account_size=args.account_size)

        chain_by_date = None
        if args.chain_dir:
            from historical_chain import build_chain_lookup_from_dir
            chain_by_date = build_chain_lookup_from_dir(args.chain_dir, symbol=args.chain_symbol or args.ticker)
            print(f"[info] loaded {len(chain_by_date)} day(s) of real historical chain data from {args.chain_dir}")

        trades = simulate_ensemble_trades(df, vix_df=vix_df, leader_data=leader_data,
                                           risk_cfg=risk_cfg, chain_by_date=chain_by_date,
                                           refit_every=args.refit_every)
    else:
        ind = compute_indicator(df, IndicatorConfig())
        trades = simulate_trades(ind, assumed_iv=args.assumed_iv)

    trades.to_csv(args.out, index=False)
    summarize(trades)
    if args.plot:
        plot_equity_curve(trades)


if __name__ == "__main__":
    main()
