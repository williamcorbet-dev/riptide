"""Re-run the 2026-08-14 10:15/13:45 case study, but now with the REAL
persistent vanna_charm/skew stores (just warmed up with 46 real historical
days via warm_up_history.py) instead of throwaway ones, to see whether
those two voters now contribute a real (non-zero-confidence) opinion and
how that shifts the aggregate read versus the earlier before/after
comparisons documented in the README."""
import pandas as pd

from webull_data import load_webull_intraday_csv, derive_daily_from_intraday
from composite_signal import SignalInputs, generate_signal
from scenario_engine import ScenarioStore, AdaptiveWeights, SIGNAL_THRESHOLD
from vanna_charm import VannaCharmHistoryStore
from skew_dynamics import SkewHistoryStore
from historical_chain import build_chain_lookup_from_dir

MARKET_CLOSE_HOUR = 16
TARGET_DATE = "2026-08-14"
CHECK_TIMES = ["10:15", "13:45"]

minute_df = load_webull_intraday_csv("data/SPY_Webull_1min_20260706_to_20260814.csv")
target_date = pd.Timestamp(TARGET_DATE).normalize()
all_days = minute_df.index.normalize()
history_bars = minute_df[all_days < target_date]
day_bars = minute_df[all_days == target_date]
daily_df = derive_daily_from_intraday(history_bars)

lookup = build_chain_lookup_from_dir("data/chains_2026-08-14", symbol="SPY", min_days_out=1)
chain = lookup.get(target_date.date())
print(f"chain for {TARGET_DATE}: spot={chain.spot}, {len(chain.strike)} strikes\n")

# REAL persistent stores -- these now have 46 days of real history each.
vc_store = VannaCharmHistoryStore()
skew_store = SkewHistoryStore()
print(f"vanna_charm real history entries: {len(vc_store.history(9999))}")
print(f"skew real history entries:        {len(skew_store.history(9999))}\n")

# Throwaway scenario/adaptive-weight stores just for this standalone probe
# (we don't want this ad hoc script's aggregate() calls polluting the real
# scenario_engine state -- unrelated to the vanna_charm/skew stores above,
# which we WANT to be real).
store = ScenarioStore(path="/tmp/_revalidate_scenarios.json")
weights = AdaptiveWeights(path="/tmp/_revalidate_weights.json")

for hhmm in CHECK_TIMES:
    t = pd.Timestamp(f"{TARGET_DATE} {hhmm}")
    intraday_today = day_bars[day_bars.index <= t]
    price_now = float(intraday_today["Close"].iloc[-1])
    hours_to_close = max(0.0, MARKET_CLOSE_HOUR - (t.hour + t.minute / 60))

    inputs = SignalInputs(
        daily_df=daily_df, intraday_df=intraday_today,
        intraday_history=history_bars if len(history_bars) > 0 else None,
        chain=chain, vanna_charm_store=vc_store, skew_store=skew_store,
        today=target_date.date(), hours_to_close=hours_to_close,
    )
    sig = generate_signal(inputs, scenario_store=store, adaptive_weights=weights,
                           signal_threshold=SIGNAL_THRESHOLD)
    print(f"=== {hhmm}  (price={price_now:.2f}, hours_to_close={hours_to_close:.2f}) ===")
    print(f"  FINAL: signal={sig.signal}  direction={sig.direction:+.3f}  confidence={sig.confidence:.3f}  method={sig.method}")
    for v in sig.votes:
        print(f"    {v.name:18s} dir={v.direction:+.3f}  conf={v.confidence:.3f}"
              + (f"  [{v.regime_tag}]" if v.regime_tag else ""))
    print()
