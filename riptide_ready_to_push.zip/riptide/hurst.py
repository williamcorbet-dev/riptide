"""
Hurst exponent: a fractal/self-similarity measure of whether price action is
trending (persistent), mean-reverting (anti-persistent), or behaving like a
random walk -- independent of, and complementary to, the HMM statistical
regime detector and the gamma-positioning mechanistic regime read. When all
three agree, that's a materially higher-conviction regime call than any one
alone (see scenario_engine.py).

H > 0.5: persistent / trending -- past direction tends to continue
H < 0.5: anti-persistent / mean-reverting -- past direction tends to reverse
H ~ 0.5: random walk -- no exploitable memory in the series

Method: classic rescaled-range (R/S) analysis (Hurst, 1951; Mandelbrot).
"""

import numpy as np
import pandas as pd

from voters import Vote


def _rs_for_window(x: np.ndarray) -> float:
    """Rescaled range for a single chunk of (mean-adjusted, cumulative) data."""
    mean = x.mean()
    dev = x - mean
    cumdev = np.cumsum(dev)
    r = cumdev.max() - cumdev.min()
    s = x.std(ddof=1)
    if s == 0 or np.isnan(s):
        return np.nan
    return r / s


def hurst_exponent(series: np.ndarray, min_window: int = 8, num_windows: int = 15) -> float:
    """Estimate the Hurst exponent of `series` (e.g. log returns) via R/S
    analysis across a log-spaced range of window sizes. Returns np.nan if
    there isn't enough data to estimate reliably."""
    series = np.asarray(series, dtype=float)
    series = series[~np.isnan(series)]
    n = len(series)
    max_window = n // 2
    if max_window < min_window * 2:
        return np.nan

    window_sizes = np.unique(
        np.logspace(np.log10(min_window), np.log10(max_window), num_windows).astype(int)
    )
    window_sizes = window_sizes[window_sizes >= min_window]

    log_rs, log_n = [], []
    for w in window_sizes:
        n_chunks = n // w
        if n_chunks < 1:
            continue
        rs_vals = [
            _rs_for_window(series[i * w:(i + 1) * w])
            for i in range(n_chunks)
        ]
        rs_vals = [v for v in rs_vals if not np.isnan(v) and v > 0]
        if not rs_vals:
            continue
        log_rs.append(np.log(np.mean(rs_vals)))
        log_n.append(np.log(w))

    if len(log_n) < 3:
        return np.nan

    slope, _ = np.polyfit(log_n, log_rs, 1)
    return float(slope)


# ---------------------------------------------------------------------------
# Small-sample bias correction
# ---------------------------------------------------------------------------
# Classic R/S analysis is known to be biased on finite samples (Anis &
# Lloyd, 1976) -- testing this module against synthetic anti-persistent
# AR(1) series confirmed it empirically: even strongly mean-reverting
# input (phi=-0.7) produced raw H estimates clustered around 0.44-0.52
# across multiple seeds, rarely crossing into "mean_reverting" territory.
# Rather than transcribe the Anis-Lloyd closed-form correction (easy to
# get subtly wrong -- their formula involves a gamma-function piecewise
# definition), this calibrates the bias directly against the exact
# estimator/parameters in use via Monte Carlo: run the same estimator on
# many independent white-noise series (true H=0.5 by construction) and
# subtract the average deviation from 0.5. Same "bump and reprice"
# philosophy as vanna_charm.py's numerical greeks -- verify empirically
# rather than trust a hand-derived formula.

_BIAS_CACHE = {}


def _estimate_bias(n: int, min_window: int, num_windows: int,
                    n_trials: int = 200, seed: int = 12345) -> float:
    rng = np.random.default_rng(seed)
    estimates = []
    for _ in range(n_trials):
        white_noise = rng.normal(0, 1, n)
        h = hurst_exponent(white_noise, min_window, num_windows)
        if not np.isnan(h):
            estimates.append(h)
    return float(np.mean(estimates) - 0.5) if estimates else 0.0


def hurst_exponent_debiased(series: np.ndarray, min_window: int = 8, num_windows: int = 15,
                             n_bias_trials: int = 200) -> float:
    """Same as hurst_exponent(), but subtracts this estimator's own
    empirically-measured bias at this sample size -- so a true random walk
    should average out much closer to 0.5, and genuine mean-reversion has
    a real chance of actually being classified as such instead of getting
    washed out by the estimator's own upward bias."""
    raw = hurst_exponent(series, min_window, num_windows)
    if np.isnan(raw):
        return raw

    clean = np.asarray(series, dtype=float)
    clean = clean[~np.isnan(clean)]
    key = (len(clean), min_window, num_windows)
    if key not in _BIAS_CACHE:
        _BIAS_CACHE[key] = _estimate_bias(len(clean), min_window, num_windows, n_bias_trials)

    return raw - _BIAS_CACHE[key]


def rolling_hurst(close: pd.Series, window: int = 100, min_window: int = 8,
                   num_windows: int = 15, step: int = 5, bias_correct: bool = True) -> pd.Series:
    """Rolling Hurst exponent computed on log returns, evaluated every
    `step` bars and forward-filled in between (R/S analysis is not cheap
    enough to run on every single bar for long histories). Bias-corrected
    by default -- see hurst_exponent_debiased()."""
    log_ret = np.log(close / close.shift(1)).dropna()
    idx = log_ret.index
    values = pd.Series(index=idx, dtype=float)
    estimator = hurst_exponent_debiased if bias_correct else hurst_exponent

    for i in range(window, len(log_ret), step):
        chunk = log_ret.iloc[i - window:i].to_numpy()
        values.iloc[i] = estimator(chunk, min_window, num_windows)

    return values.reindex(close.index).ffill()


def hurst_regime(h: float, neutral_band: float = 0.05) -> str:
    if np.isnan(h):
        return "unknown"
    if h > 0.5 + neutral_band:
        return "trending"
    if h < 0.5 - neutral_band:
        return "mean_reverting"
    return "random_walk"


def hurst_vote(close: pd.Series, window: int = 100, trend_lookback: int = 10,
               reversion_lookback: int = 5) -> Vote:
    """Turns the Hurst regime read into a directional vote:
      - trending regime -> direction follows the recent realized trend
      - mean-reverting regime -> direction fades the recent short-term move
      - random walk / unknown -> no opinion (confidence 0)
    Confidence scales with |H - 0.5|, i.e. how far from a pure random walk
    we are -- a Hurst of 0.51 says almost nothing, a Hurst of 0.75 says a lot.
    """
    h_series = rolling_hurst(close, window=window)
    h = h_series.iloc[-1]
    regime = hurst_regime(h)

    if regime in ("unknown", "random_walk"):
        return Vote(name="hurst", direction=0.0, confidence=0.0,
                     regime_tag=regime, detail={"hurst": h})

    confidence = float(min(1.0, abs(h - 0.5) / 0.25))  # H=0.75 or H=0.25 -> confidence 1.0

    if regime == "trending":
        recent_ret = np.log(close.iloc[-1] / close.iloc[-trend_lookback])
        direction = np.sign(recent_ret)
    else:  # mean_reverting
        recent_ret = np.log(close.iloc[-1] / close.iloc[-reversion_lookback])
        direction = -np.sign(recent_ret)

    return Vote(
        name="hurst",
        direction=float(direction),
        confidence=confidence,
        regime_tag=regime,
        detail={"hurst": float(h), "window": window},
    )
