"""
Builds the interactive slider-chart HTML (price + signal + full voter
breakdown per checkpoint, scrubbable) from intraday_replay.py's two output
CSVs (`<prefix>_replay.csv` and `<prefix>_replay_votes.csv`).

This is deliberately a separate, reusable step from generating the replay
itself -- `intraday_replay.py --webull-csv ... --date ... --interval ...`
(with a real `daily_df` passed through in code, not just its CLI, for the
long real history -- see daily_reviews.md 2026-08-19) produces the CSVs;
this script turns them into the same self-contained HTML page every time,
whether that's a full completed session (see e.g.
outputs/spy_indicator_replay_2026-08-19.html) or a partial "still live"
day (pass --live so the header/labels say so honestly instead of implying
the session is over).

Usage:
    python build_replay_chart.py --replay-csv 2026-08-20_replay.csv \\
        --votes-csv 2026-08-20_replay_votes.csv --date 2026-08-20 \\
        --out spy_indicator_replay_2026-08-20.html --live

No dependencies beyond pandas (already a project requirement).
"""

import argparse
import json

import pandas as pd

VOTER_LABELS = {
    "technical": "technical (daily chart)",
    "hurst": "hurst",
    "hmm_regime": "hmm regime",
    "fomc_calendar": "fomc / calendar",
    "gamma_regime": "gamma / fomc",
    "vanna_charm": "vanna / charm",
    "put_call_ratio": "put/call ratio",
    "vix_term_structure": "vix term structure",
    "intraday_technical": "intraday technical",
    "candlesticks": "candlesticks",
    "support_resistance": "support/resistance",
    "vwap_reversion": "vwap reversion",
    "mfi_divergence": "money flow index",
    "adaptive_supertrend": "adaptive supertrend",
    "time_of_day": "time of day",
    "cross_asset_leadlag": "cross-asset lead/lag",
    "skew_dynamics": "skew dynamics",
}


def _fmt_time_label(ts: pd.Timestamp) -> str:
    h = ts.hour
    ampm = "pm" if h >= 12 else "am"
    h12 = h % 12 or 12
    return f"{h12}:{ts.minute:02d}{ampm}"


def build_chart_data(replay_csv: str, votes_csv: str, interval_minutes: int,
                      signal_threshold: float = 0.35) -> dict:
    replay = pd.read_csv(replay_csv, parse_dates=["time"])
    votes = pd.read_csv(votes_csv, parse_dates=["time"])

    checkpoints = []
    for _, row in replay.iterrows():
        t = row["time"]
        vrows = votes[votes["time"] == t]
        voter_list = []
        for _, v in vrows.iterrows():
            voter_list.append({
                "key": v["voter"],
                "label": VOTER_LABELS.get(v["voter"], str(v["voter"])),
                "direction": round(float(v["direction"]), 3),
                "confidence": round(float(v["confidence"]), 3),
                "regime_tag": None if pd.isna(v["regime_tag"]) else str(v["regime_tag"]),
            })
        price_plus_30m = row.get("price_+30m")
        checkpoints.append({
            "time": t.strftime("%Y-%m-%d %H:%M:%S"),
            "price": round(float(row["price"]), 2),
            "signal": row["signal"],
            "direction": round(float(row["direction"]), 3),
            "confidence": round(float(row["confidence"]), 3),
            "price_plus_30m": None if price_plus_30m is None or pd.isna(price_plus_30m) else round(float(price_plus_30m), 2),
            "voters": voter_list,
        })

    day_close = float(replay["day_close"].iloc[-1]) if "day_close" in replay.columns else float(replay["price"].iloc[-1])
    return {
        "date": replay["time"].iloc[0].strftime("%Y-%m-%d"),
        "day_close": round(day_close, 2),
        "interval_minutes": interval_minutes,
        "signal_threshold": signal_threshold,
        "checkpoints": checkpoints,
    }


def render_html(data: dict, live: bool = False) -> str:
    n = len(data["checkpoints"])
    first_t = pd.Timestamp(data["checkpoints"][0]["time"])
    last_t = pd.Timestamp(data["checkpoints"][-1]["time"])
    date_disp = first_t.strftime("%a %b ") + str(first_t.day) + first_t.strftime(", %Y")
    time_range = f"{_fmt_time_label(first_t)}–{_fmt_time_label(last_t)} ET" + (" so far" if live else "")

    if live:
        title_suffix = "Live Replay"
        subhead = (
            "Still live: every ~%d minutes of today's real regular-session price action so far, replayed "
            "point-in-time through the composite signal (only bars up to each moment were visible to it — no "
            "lookahead). This page was regenerated just now and will keep being refreshed through the close. "
            "Drag the slider or click a point on the chart to see exactly what the indicator read and why, at "
            "any checkpoint so far. Built from a fresh, throwaway scenario/weights store the same way "
            "<code>intraday_replay.py</code> always does, so treat this as &ldquo;how the logic reads today's "
            "tape&rdquo; rather than a guaranteed match to what the live scanner's own checkpoints fire (those "
            "use the persistent, slower-moving adaptive weights in <code>state/</code>)."
        ) % data["interval_minutes"]
        checkpoints_heading = f"All {n} checkpoints so far"
        table_footnote = "Click any row to jump the slider to that checkpoint. Still live — last price $%.2f." % data["checkpoints"][-1]["price"]
        reading_note = (
            "This reconstructs the indicator's read using real 1-minute SPY bars pulled just now, so every "
            "checkpoint here is a genuine point-in-time snapshot (later bars were not visible to earlier "
            "checkpoints). It uses a fresh scenario/weights store rather than the persistent one the live "
            "scanner uses, so the exact numbers can differ a little from what fired live — this is meant for "
            "seeing the shape of how the read is evolving today, not as an audit of the live log."
        )
    else:
        title_suffix = "Today's Replay"
        subhead = (
            "Every %d minutes of today's real regular-session price action, replayed point-in-time through the "
            "composite signal (only bars up to each moment were visible to it — no lookahead). Drag the slider "
            "or click a point on the chart to see exactly what the indicator read and why, at any moment today. "
            "Built from a fresh, throwaway scenario/weights store the same way <code>intraday_replay.py</code> "
            "always does, so treat this as &ldquo;how the logic reads today's tape&rdquo; rather than a "
            "guaranteed match to what the live scanner's checkpoints fired (those use the persistent, "
            "slower-moving adaptive weights in <code>state/</code>)."
        ) % data["interval_minutes"]
        checkpoints_heading = f"All {n} checkpoints today"
        table_footnote = "Click any row to jump the slider to that checkpoint. Day closed at $%.2f." % data["day_close"]
        reading_note = (
            "This reconstructs the indicator's read using real 1-minute SPY bars pulled after today's close, so "
            "every checkpoint here is a genuine point-in-time snapshot (later bars were not visible to earlier "
            "checkpoints). It uses a fresh scenario/weights store rather than the persistent one the live "
            "scanner uses, so the exact numbers can differ a little from what fired live during the day — this "
            "is meant for seeing the shape of how the read evolved, not as an audit of the live log."
        )

    data_json = json.dumps(data, separators=(",", ":"))

    html = HTML_TEMPLATE
    html = html.replace("__TITLE_SUFFIX__", title_suffix)
    html = html.replace("__DATE_DISP__", date_disp)
    html = html.replace("__TIME_RANGE__", time_range)
    html = html.replace("__SUBHEAD__", subhead)
    html = html.replace("__CHECKPOINTS_HEADING__", checkpoints_heading)
    html = html.replace("__TABLE_FOOTNOTE__", table_footnote)
    html = html.replace("__READING_NOTE__", reading_note)
    html = html.replace("__DATA_JSON__", data_json)
    html = html.replace("__MAXIDX__", str(n - 1))
    return html


HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SPY 1DTE Indicator — __TITLE_SUFFIX__</title>
<style>
  .viz-root {
    color-scheme: light;
    --surface-1:      #fcfcfb;
    --page-plane:     #f9f9f7;
    --text-primary:   #0b0b0b;
    --text-secondary: #52514e;
    --text-muted:     #898781;
    --gridline:       #e1e0d9;
    --baseline:       #c3c2b7;
    --border:         rgba(11,11,11,0.10);
    --blue:           #2a78d6;
    --blue-seq-100:   #cde2fb;
    --blue-seq-700:   #0d366b;
    --red:            #e34948;
    --neutral-mid:    #f0efec;
    --good-text:      #006300;
    --crosshair:      #c3c2b7;
  }
  @media (prefers-color-scheme: dark) {
    :root:where(:not([data-theme="light"])) .viz-root {
      color-scheme: dark;
      --surface-1:      #1a1a19;
      --page-plane:     #0d0d0d;
      --text-primary:   #ffffff;
      --text-secondary: #c3c2b7;
      --text-muted:     #898781;
      --gridline:       #2c2c2a;
      --baseline:       #383835;
      --border:         rgba(255,255,255,0.10);
      --blue:           #3987e5;
      --blue-seq-100:   #cde2fb;
      --blue-seq-700:   #0d366b;
      --red:            #e66767;
      --neutral-mid:    #383835;
      --good-text:      #0ca30c;
      --crosshair:      #383835;
    }
  }
  :root[data-theme="dark"] .viz-root {
    color-scheme: dark;
    --surface-1:      #1a1a19;
    --page-plane:     #0d0d0d;
    --text-primary:   #ffffff;
    --text-secondary: #c3c2b7;
    --text-muted:     #898781;
    --gridline:       #2c2c2a;
    --baseline:       #383835;
    --border:         rgba(255,255,255,0.10);
    --blue:           #3987e5;
    --blue-seq-100:   #cde2fb;
    --blue-seq-700:   #0d366b;
    --red:            #e66767;
    --neutral-mid:    #383835;
    --good-text:      #0ca30c;
    --crosshair:      #383835;
  }

  * { box-sizing: border-box; }
  body {
    margin: 0;
    font-family: system-ui, -apple-system, "Segoe UI", sans-serif;
    background: var(--page-plane);
    color: var(--text-primary);
  }
  .viz-root { padding: 24px 16px 60px; max-width: 920px; margin: 0 auto; }

  .topbar { display: flex; justify-content: space-between; align-items: baseline; flex-wrap: wrap; gap: 8px; margin-bottom: 4px; }
  h1 { font-size: 20px; margin: 0; font-weight: 700; }
  .asof { font-size: 13px; color: var(--text-muted); }
  .subhead { font-size: 13px; color: var(--text-secondary); margin: 4px 0 20px; line-height: 1.5; }

  .card {
    background: var(--surface-1);
    border: 1px solid var(--border);
    border-radius: 12px;
    padding: 18px 20px;
    margin-bottom: 16px;
  }
  .card h2 {
    font-size: 13px;
    text-transform: uppercase;
    letter-spacing: 0.04em;
    color: var(--text-muted);
    margin: 0 0 14px;
    font-weight: 600;
  }

  /* chart */
  .chart-wrap { position: relative; user-select: none; -webkit-user-select: none; }
  svg#chart-svg { display: block; width: 100%; height: auto; overflow: visible; touch-action: none; }
  .gridline { stroke: var(--gridline); stroke-width: 1; }
  .axis-label { fill: var(--text-muted); font-size: 11px; font-variant-numeric: tabular-nums; }
  .price-line { fill: none; stroke: var(--blue); stroke-width: 2; stroke-linejoin: round; stroke-linecap: round; }
  .mark-ring { fill: var(--surface-1); }
  .mark-dot.call { fill: var(--blue); }
  .mark-dot.put { fill: var(--red); }
  .mark-dot.none { fill: var(--text-muted); opacity: 0.55; }
  .mark-hit { fill: transparent; cursor: pointer; }
  .crosshair-line { stroke: var(--crosshair); stroke-width: 1; pointer-events: none; }
  .cursor-dot { pointer-events: none; }
  .cursor-dot .ring { fill: var(--surface-1); }
  .cursor-dot .core { }

  .tooltip {
    position: absolute;
    pointer-events: none;
    background: var(--text-primary);
    color: var(--surface-1);
    font-size: 12px;
    padding: 8px 10px;
    border-radius: 8px;
    line-height: 1.5;
    white-space: nowrap;
    transform: translate(-50%, -100%);
    top: 0; left: 0;
    opacity: 0;
    transition: opacity 0.08s ease;
    z-index: 5;
  }
  .tooltip.visible { opacity: 1; }
  .tooltip .tt-time { color: var(--text-muted); font-size: 11px; margin-bottom: 3px; }
  .tooltip .tt-row { display: flex; justify-content: space-between; gap: 14px; }
  .tooltip .tt-val { font-weight: 700; font-variant-numeric: tabular-nums; }

  .chart-legend { display: flex; gap: 18px; font-size: 12px; color: var(--text-secondary); margin-top: 12px; }
  .legend-item { display: flex; align-items: center; gap: 6px; }
  .legend-swatch { width: 10px; height: 10px; border-radius: 50%; flex: none; }

  /* slider */
  .slider-row { margin-top: 18px; }
  .slider-time { font-size: 13px; font-weight: 700; color: var(--text-primary); margin-bottom: 8px; font-variant-numeric: tabular-nums; }
  input[type="range"] {
    -webkit-appearance: none; appearance: none;
    width: 100%; height: 22px; background: transparent; cursor: pointer; margin: 0;
  }
  input[type="range"]::-webkit-slider-runnable-track {
    height: 6px; border-radius: 3px; background: var(--gridline);
  }
  input[type="range"]::-webkit-slider-thumb {
    -webkit-appearance: none; appearance: none;
    width: 18px; height: 18px; border-radius: 50%;
    background: var(--blue); border: 3px solid var(--surface-1);
    box-shadow: 0 0 0 1px var(--border);
    margin-top: -6px;
  }
  input[type="range"]::-moz-range-track {
    height: 6px; border-radius: 3px; background: var(--gridline);
  }
  input[type="range"]::-moz-range-thumb {
    width: 18px; height: 18px; border-radius: 50%;
    background: var(--blue); border: 3px solid var(--surface-1);
    box-shadow: 0 0 0 1px var(--border);
  }
  .slider-ticks { display: flex; justify-content: space-between; font-size: 10.5px; color: var(--text-muted); margin-top: 4px; font-variant-numeric: tabular-nums; }

  .step-btns { display: flex; gap: 8px; margin-top: 12px; }
  .step-btn {
    font: inherit; font-size: 12px; font-weight: 600; color: var(--text-secondary);
    background: var(--page-plane); border: 1px solid var(--border); border-radius: 6px;
    padding: 6px 12px; cursor: pointer;
  }
  .step-btn:hover { color: var(--text-primary); }
  .step-btn:disabled { opacity: 0.4; cursor: default; }
  #play-btn { min-width: 76px; }

  .hero-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
  @media (max-width: 560px) { .hero-row { grid-template-columns: 1fr; } }

  .price-figure { font-size: 40px; font-weight: 700; line-height: 1; letter-spacing: -0.01em; font-variant-numeric: normal; }
  .price-delta { font-size: 15px; margin-top: 6px; font-weight: 600; }
  .price-delta.down { color: var(--red); }
  .price-delta.up { color: var(--good-text); }
  .price-delta.flat { color: var(--text-muted); }
  .price-note { font-size: 12px; color: var(--text-muted); margin-top: 8px; }

  .signal-figure { font-size: 32px; font-weight: 700; letter-spacing: -0.01em; display: flex; align-items: center; gap: 10px; }
  .signal-dot { width: 14px; height: 14px; border-radius: 50%; flex: none; }
  .signal-dot.call { background: var(--blue); }
  .signal-dot.put { background: var(--red); }
  .signal-dot.none { background: var(--text-muted); }
  .conf-track { height: 8px; border-radius: 4px; background: var(--gridline); margin-top: 12px; overflow: hidden; }
  .conf-fill { height: 100%; border-radius: 4px; transition: width 0.12s ease; }
  .conf-fill.call { background: var(--blue); }
  .conf-fill.put { background: var(--red); }
  .conf-fill.none { background: var(--text-muted); }
  .conf-label { font-size: 12px; color: var(--text-muted); margin-top: 6px; }

  .voter-row { display: grid; grid-template-columns: 150px 1fr 56px; align-items: center; gap: 10px; padding: 7px 0; border-bottom: 1px solid var(--gridline); font-size: 13px; }
  .voter-row:last-child { border-bottom: none; }
  .voter-name { color: var(--text-secondary); }
  .voter-track { position: relative; height: 18px; background: var(--gridline); border-radius: 3px; }
  .voter-mid { position: absolute; left: 50%; top: -3px; bottom: -3px; width: 1px; background: var(--baseline); }
  .voter-fill { position: absolute; top: 0; bottom: 0; border-radius: 3px; cursor: default; transition: left 0.12s ease, width 0.12s ease, right 0.12s ease; }
  .voter-fill.pos { background: var(--blue); left: 50%; }
  .voter-fill.neg { background: var(--red); right: 50%; }
  .voter-fill.zero { background: var(--text-muted); opacity: 0.35; left: 49.3%; width: 1.4%; }
  .voter-val { text-align: right; color: var(--text-muted); font-variant-numeric: tabular-nums; font-size: 12px; }
  .voter-tip { display: none; position: absolute; bottom: 22px; left: 0; background: var(--text-primary); color: var(--surface-1); font-size: 11px; padding: 5px 8px; border-radius: 6px; white-space: nowrap; z-index: 2; }
  .voter-fill:hover .voter-tip, .voter-fill:focus .voter-tip { display: block; }

  .legend { display: flex; gap: 18px; font-size: 12px; color: var(--text-secondary); margin-top: 10px; }

  table { width: 100%; border-collapse: collapse; font-size: 12.5px; }
  th { text-align: left; color: var(--text-muted); font-weight: 600; font-size: 11px; text-transform: uppercase; letter-spacing: 0.03em; padding: 6px 8px; border-bottom: 1px solid var(--gridline); position: sticky; top: 0; background: var(--surface-1); }
  td { padding: 7px 8px; border-bottom: 1px solid var(--gridline); color: var(--text-secondary); font-variant-numeric: tabular-nums; }
  tr:last-child td { border-bottom: none; }
  tr.current-row td { background: var(--blue-seq-100); }
  .sig-pill { display: inline-block; padding: 2px 8px; border-radius: 10px; font-size: 11px; font-weight: 700; }
  .sig-pill.call { background: var(--blue-seq-100); color: var(--blue-seq-700); }
  .sig-pill.put { background: var(--neutral-mid); color: var(--red); }
  .sig-pill.none { background: var(--gridline); color: var(--text-muted); }
  .table-scroll { max-height: 320px; overflow-y: auto; border-radius: 8px; }
  tr.table-row-btn { cursor: pointer; }
  tr.table-row-btn:hover td { background: var(--page-plane); }

  .table-toggle {
    font: inherit; font-size: 12px; font-weight: 600; color: var(--text-secondary);
    background: none; border: 1px solid var(--border); border-radius: 6px;
    padding: 6px 12px; cursor: pointer; margin-bottom: 12px;
  }
  .table-toggle:hover { color: var(--text-primary); }

  .foot-note { font-size: 12px; color: var(--text-muted); line-height: 1.5; margin-top: 4px; }
</style>
</head>
<body>
<div class="viz-root">

  <div class="topbar">
    <h1>SPY 1DTE Indicator — __TITLE_SUFFIX__</h1>
    <div class="asof">__DATE_DISP__ · __TIME_RANGE__</div>
  </div>
  <div class="subhead">__SUBHEAD__</div>

  <div class="card">
    <h2>Price &amp; signal through the day</h2>
    <div class="chart-wrap" id="chart-wrap">
      <svg id="chart-svg" viewBox="0 0 800 300" preserveAspectRatio="xMidYMid meet"></svg>
      <div class="tooltip" id="tooltip"></div>
    </div>
    <div class="chart-legend">
      <div class="legend-item"><span class="legend-swatch" style="background:var(--blue)"></span>CALL</div>
      <div class="legend-item"><span class="legend-swatch" style="background:var(--red)"></span>PUT</div>
      <div class="legend-item"><span class="legend-swatch" style="background:var(--text-muted); opacity:0.55"></span>NONE (no fire)</div>
    </div>

    <div class="slider-row">
      <div class="slider-time" id="slider-time">—</div>
      <input type="range" id="slider" min="0" max="__MAXIDX__" step="1" value="0" aria-label="Checkpoint time today">
      <div class="slider-ticks" id="slider-ticks"></div>
      <div class="step-btns">
        <button class="step-btn" id="prev-btn" type="button" aria-label="Previous checkpoint">&larr; prev</button>
        <button class="step-btn" id="play-btn" type="button" aria-label="Play through the day">&#9654; play</button>
        <button class="step-btn" id="next-btn" type="button" aria-label="Next checkpoint">next &rarr;</button>
      </div>
    </div>
  </div>

  <div class="hero-row">
    <div class="card">
      <h2>SPY price at this checkpoint</h2>
      <div class="price-figure" id="price-figure">—</div>
      <div class="price-delta" id="price-delta">—</div>
      <div class="price-note" id="price-note">—</div>
    </div>
    <div class="card">
      <h2>Signal at this checkpoint</h2>
      <div class="signal-figure" id="signal-figure"><span class="signal-dot none" id="signal-dot"></span><span id="signal-text">—</span></div>
      <div class="conf-track"><div class="conf-fill none" id="conf-fill" style="width: 0%"></div></div>
      <div class="conf-label" id="conf-label">—</div>
    </div>
  </div>

  <div class="card">
    <h2>What each component was voting at this checkpoint</h2>
    <div id="voter-rows"></div>
    <div class="legend">
      <div class="legend-item"><span class="legend-swatch" style="background:var(--blue); border-radius:2px;"></span>leaning up (CALL)</div>
      <div class="legend-item"><span class="legend-swatch" style="background:var(--red); border-radius:2px;"></span>leaning down (PUT)</div>
      <div class="legend-item"><span class="legend-swatch" style="background:var(--text-muted); opacity:0.35; border-radius:2px;"></span>no opinion / sat out</div>
    </div>
  </div>

  <div class="card">
    <h2>__CHECKPOINTS_HEADING__</h2>
    <button class="table-toggle" id="table-toggle" type="button" aria-expanded="false">Show table view</button>
    <div class="table-scroll" id="table-scroll" style="display:none;">
      <table>
        <thead><tr><th>Time (ET)</th><th>SPY</th><th>Signal</th><th>Direction</th><th>Confidence</th></tr></thead>
        <tbody id="table-body"></tbody>
      </table>
    </div>
    <p class="foot-note" style="margin-top:10px;">__TABLE_FOOTNOTE__</p>
  </div>

  <div class="card">
    <h2>Reading this replay</h2>
    <p class="foot-note">__READING_NOTE__</p>
  </div>

</div>

<script id="chart-data" type="application/json">__DATA_JSON__</script>
<script>
(function() {
  "use strict";
  var raw = JSON.parse(document.getElementById("chart-data").textContent);
  var checkpoints = raw.checkpoints;
  var n = checkpoints.length;
  var dayClose = raw.day_close;
  var threshold = raw.signal_threshold;

  function sigClass(sig) {
    if (sig === "CALL") return "call";
    if (sig === "PUT") return "put";
    return "none";
  }
  function fmtTime(tstr) {
    var parts = tstr.split(" ")[1].split(":");
    var h = parseInt(parts[0], 10);
    var m = parts[1];
    var ampm = h >= 12 ? "pm" : "am";
    var h12 = h % 12; if (h12 === 0) h12 = 12;
    return h12 + ":" + m + ampm;
  }
  function fmtTimeFull(tstr) { return fmtTime(tstr) + " ET"; }

  var sliderTicks = document.getElementById("slider-ticks");
  [0, 0.25, 0.5, 0.75, 1].forEach(function(f) {
    var idx = Math.round((n - 1) * f);
    var span = document.createElement("span");
    span.textContent = fmtTime(checkpoints[idx].time);
    sliderTicks.appendChild(span);
  });

  var svgNS = "http://www.w3.org/2000/svg";
  var svg = document.getElementById("chart-svg");
  var W = 800, H = 300;
  var padL = 52, padR = 14, padT = 14, padB = 30;
  var plotW = W - padL - padR, plotH = H - padT - padB;

  var prices = checkpoints.map(function(c) { return c.price; });
  var pMin = Math.min.apply(null, prices), pMax = Math.max.apply(null, prices);
  var pad = Math.max(0.4, (pMax - pMin) * 0.15);
  pMin -= pad; pMax += pad;

  function xOf(i) { return n > 1 ? padL + (plotW * i) / (n - 1) : padL + plotW / 2; }
  function yOf(price) { return padT + plotH * (1 - (price - pMin) / (pMax - pMin)); }

  function el(tag, attrs) {
    var e = document.createElementNS(svgNS, tag);
    for (var k in attrs) e.setAttribute(k, attrs[k]);
    return e;
  }

  function buildChart() {
    while (svg.firstChild) svg.removeChild(svg.firstChild);

    var steps = 4;
    for (var s = 0; s <= steps; s++) {
      var price = pMin + ((pMax - pMin) * s) / steps;
      var y = yOf(price);
      svg.appendChild(el("line", { x1: padL, x2: W - padR, y1: y, y2: y, class: "gridline" }));
      var t = el("text", { x: padL - 8, y: y + 4, class: "axis-label", "text-anchor": "end" });
      t.textContent = "$" + price.toFixed(2);
      svg.appendChild(t);
    }

    var labelIdx = [0, Math.round((n - 1) * 0.25), Math.round((n - 1) * 0.5), Math.round((n - 1) * 0.75), n - 1];
    labelIdx.forEach(function(i) {
      var t = el("text", { x: xOf(i), y: H - 8, class: "axis-label", "text-anchor": "middle" });
      t.textContent = fmtTime(checkpoints[i].time);
      svg.appendChild(t);
    });

    var d = checkpoints.map(function(c, i) {
      return (i === 0 ? "M" : "L") + xOf(i).toFixed(2) + "," + yOf(c.price).toFixed(2);
    }).join(" ");
    svg.appendChild(el("path", { d: d, class: "price-line" }));

    checkpoints.forEach(function(c, i) {
      var cx = xOf(i), cy = yOf(c.price);
      var cls = sigClass(c.signal);
      if (c.signal !== "NONE") {
        svg.appendChild(el("circle", { cx: cx, cy: cy, r: 6, class: "mark-ring" }));
        svg.appendChild(el("circle", { cx: cx, cy: cy, r: 4, class: "mark-dot " + cls }));
      } else {
        svg.appendChild(el("circle", { cx: cx, cy: cy, r: 2.5, class: "mark-dot " + cls }));
      }
      var hit = el("circle", { cx: cx, cy: cy, r: 14, class: "mark-hit", "data-idx": i, tabindex: "0", role: "button", "aria-label": fmtTimeFull(c.time) + ", price $" + c.price.toFixed(2) + ", " + c.signal });
      svg.appendChild(hit);
    });

    var crosshair = el("line", { x1: 0, x2: 0, y1: padT, y2: H - padB, class: "crosshair-line", id: "crosshair", visibility: "hidden" });
    svg.appendChild(crosshair);

    var cursorGroup = el("g", { id: "cursor-dot", class: "cursor-dot", visibility: "hidden" });
    cursorGroup.appendChild(el("circle", { r: 7, class: "ring", id: "cursor-ring" }));
    cursorGroup.appendChild(el("circle", { r: 4.5, id: "cursor-core" }));
    svg.appendChild(cursorGroup);
  }
  buildChart();

  var crosshairEl = document.getElementById("crosshair");
  var cursorGroupEl = document.getElementById("cursor-dot");
  var cursorCoreEl = document.getElementById("cursor-core");
  var tooltip = document.getElementById("tooltip");
  var chartWrap = document.getElementById("chart-wrap");

  function nearestIdxFromClientX(clientX) {
    var rect = svg.getBoundingClientRect();
    var scale = W / rect.width;
    var svgX = (clientX - rect.left) * scale;
    var frac = (svgX - padL) / plotW;
    var idx = Math.round(frac * (n - 1));
    if (idx < 0) idx = 0;
    if (idx > n - 1) idx = n - 1;
    return idx;
  }

  function positionTooltip(idx) {
    var rect = svg.getBoundingClientRect();
    var scale = rect.width / W;
    var cx = xOf(idx) * scale;
    var cy = yOf(checkpoints[idx].price) * scale;
    tooltip.style.left = cx + "px";
    tooltip.style.top = (cy - 12) + "px";
  }

  function fillTooltip(idx) {
    var c = checkpoints[idx];
    tooltip.innerHTML = "";
    var timeDiv = document.createElement("div");
    timeDiv.className = "tt-time";
    timeDiv.textContent = fmtTimeFull(c.time);
    tooltip.appendChild(timeDiv);

    var priceRow = document.createElement("div");
    priceRow.className = "tt-row";
    var priceLbl = document.createElement("span"); priceLbl.textContent = "SPY";
    var priceVal = document.createElement("span"); priceVal.className = "tt-val"; priceVal.textContent = "$" + c.price.toFixed(2);
    priceRow.appendChild(priceLbl); priceRow.appendChild(priceVal);
    tooltip.appendChild(priceRow);

    var sigRow = document.createElement("div");
    sigRow.className = "tt-row";
    var sigLbl = document.createElement("span"); sigLbl.textContent = "signal";
    var sigVal = document.createElement("span"); sigVal.className = "tt-val"; sigVal.textContent = c.signal + " (" + c.confidence.toFixed(2) + ")";
    sigRow.appendChild(sigLbl); sigRow.appendChild(sigVal);
    tooltip.appendChild(sigRow);
  }

  function showHoverAt(idx) {
    var cx = xOf(idx), cy = yOf(checkpoints[idx].price);
    crosshairEl.setAttribute("x1", cx); crosshairEl.setAttribute("x2", cx);
    crosshairEl.setAttribute("visibility", "visible");
    cursorGroupEl.setAttribute("transform", "translate(" + cx + "," + cy + ")");
    cursorGroupEl.setAttribute("visibility", "visible");
    var cls = sigClass(checkpoints[idx].signal);
    var color = cls === "call" ? "var(--blue)" : cls === "put" ? "var(--red)" : "var(--text-muted)";
    cursorCoreEl.setAttribute("fill", color);
    fillTooltip(idx);
    positionTooltip(idx);
    tooltip.classList.add("visible");
  }
  function hideHover() { tooltip.classList.remove("visible"); }

  svg.addEventListener("pointermove", function(ev) { showHoverAt(nearestIdxFromClientX(ev.clientX)); });
  svg.addEventListener("pointerleave", function() { hideHover(); syncCrosshairToSlider(); });
  svg.addEventListener("pointerdown", function(ev) { setIndex(nearestIdxFromClientX(ev.clientX)); });
  svg.querySelectorAll(".mark-hit").forEach(function(hit) {
    hit.addEventListener("focus", function() { showHoverAt(parseInt(hit.getAttribute("data-idx"), 10)); });
    hit.addEventListener("blur", function() { hideHover(); syncCrosshairToSlider(); });
    hit.addEventListener("click", function() { setIndex(parseInt(hit.getAttribute("data-idx"), 10)); });
  });

  function syncCrosshairToSlider() {
    showHoverAt(currentIdx);
    hideHover();
    crosshairEl.setAttribute("visibility", "visible");
    cursorGroupEl.setAttribute("visibility", "visible");
  }

  var slider = document.getElementById("slider");
  var currentIdx = 0;
  var playTimer = null;

  var voterRowsEl = document.getElementById("voter-rows");
  var tableBody = document.getElementById("table-body");

  function buildVoterRows(c) {
    voterRowsEl.innerHTML = "";
    c.voters.forEach(function(v) {
      var row = document.createElement("div");
      row.className = "voter-row";

      var nameEl = document.createElement("div");
      nameEl.className = "voter-name";
      nameEl.textContent = v.label;
      row.appendChild(nameEl);

      var track = document.createElement("div");
      track.className = "voter-track";
      var mid = document.createElement("div");
      mid.className = "voter-mid";
      track.appendChild(mid);

      var fill = document.createElement("div");
      var valText;
      if (v.confidence === 0) {
        fill.className = "voter-fill zero";
        valText = "sat out";
      } else {
        var pct = Math.min(50, Math.abs(v.direction) * 50);
        fill.className = v.direction >= 0 ? "voter-fill pos" : "voter-fill neg";
        fill.style.width = pct + "%";
        fill.style.opacity = Math.max(0.35, Math.min(1, 0.35 + v.confidence * 0.65));
        valText = (v.direction >= 0 ? "+" : "") + v.direction.toFixed(2);
      }
      var tip = document.createElement("span");
      tip.className = "voter-tip";
      var tipText = "direction " + (v.direction >= 0 ? "+" : "") + v.direction.toFixed(2) +
                    ", confidence " + v.confidence.toFixed(2);
      if (v.regime_tag) tipText += " (" + v.regime_tag.replace(/_/g, " ") + ")";
      tip.textContent = tipText;
      fill.appendChild(tip);
      track.appendChild(fill);
      row.appendChild(track);

      var valEl = document.createElement("div");
      valEl.className = "voter-val";
      valEl.textContent = valText;
      row.appendChild(valEl);

      voterRowsEl.appendChild(row);
    });
  }

  function buildTable() {
    tableBody.innerHTML = "";
    checkpoints.forEach(function(c, i) {
      var tr = document.createElement("tr");
      tr.className = "table-row-btn";
      tr.setAttribute("data-idx", i);

      var tdTime = document.createElement("td"); tdTime.textContent = fmtTime(c.time);
      var tdPrice = document.createElement("td"); tdPrice.textContent = "$" + c.price.toFixed(2);
      var tdSig = document.createElement("td");
      var pill = document.createElement("span");
      pill.className = "sig-pill " + sigClass(c.signal);
      pill.textContent = c.signal;
      tdSig.appendChild(pill);
      var tdDir = document.createElement("td"); tdDir.textContent = (c.direction >= 0 ? "+" : "") + c.direction.toFixed(2);
      var tdConf = document.createElement("td"); tdConf.textContent = c.confidence.toFixed(2);

      tr.appendChild(tdTime); tr.appendChild(tdPrice); tr.appendChild(tdSig); tr.appendChild(tdDir); tr.appendChild(tdConf);
      tr.addEventListener("click", function() { setIndex(i); });
      tableBody.appendChild(tr);
    });
  }
  buildTable();

  var priceFigure = document.getElementById("price-figure");
  var priceDelta = document.getElementById("price-delta");
  var priceNote = document.getElementById("price-note");
  var signalDot = document.getElementById("signal-dot");
  var signalText = document.getElementById("signal-text");
  var confFill = document.getElementById("conf-fill");
  var confLabel = document.getElementById("conf-label");
  var sliderTime = document.getElementById("slider-time");
  var tableScroll = document.getElementById("table-scroll");

  function setIndex(idx) {
    if (idx < 0) idx = 0;
    if (idx > n - 1) idx = n - 1;
    currentIdx = idx;
    slider.value = idx;
    render(idx);
  }

  function render(idx) {
    var c = checkpoints[idx];
    var cls = sigClass(c.signal);

    sliderTime.textContent = fmtTimeFull(c.time) + " — checkpoint " + (idx + 1) + " of " + n;

    priceFigure.textContent = "$" + c.price.toFixed(2);
    var deltaToClose = dayClose - c.price;
    var deltaPct = c.price ? (deltaToClose / c.price) * 100 : 0;
    var arrow = deltaToClose > 0.005 ? "▲" : deltaToClose < -0.005 ? "▼" : "—";
    var deltaCls = deltaToClose > 0.005 ? "up" : deltaToClose < -0.005 ? "down" : "flat";
    priceDelta.className = "price-delta " + deltaCls;
    priceDelta.textContent = arrow + " $" + Math.abs(deltaToClose).toFixed(2) + " (" + Math.abs(deltaPct).toFixed(2) + "%) vs latest $" + dayClose.toFixed(2);
    priceNote.textContent = idx === n - 1 ? "This is the latest checkpoint available." : "30 min later: " + (c.price_plus_30m !== null ? "$" + c.price_plus_30m.toFixed(2) : "n/a");

    signalDot.className = "signal-dot " + cls;
    signalText.textContent = c.signal;
    var confPct = Math.min(100, c.confidence * 100);
    confFill.className = "conf-fill " + cls;
    confFill.style.width = confPct + "%";
    confLabel.textContent = "confidence " + c.confidence.toFixed(2) + " · needs ≥ " + threshold.toFixed(2) + " to fire" +
      (c.signal === "NONE" && c.confidence >= threshold * 0.85 ? " — close to the edge" : "");

    buildVoterRows(c);
    syncCrosshairToSlider();

    var rows = tableBody.querySelectorAll("tr");
    rows.forEach(function(r) { r.classList.remove("current-row"); });
    var activeRow = rows[idx];
    if (activeRow) {
      activeRow.classList.add("current-row");
      if (tableScroll.style.display !== "none") activeRow.scrollIntoView({ block: "nearest" });
    }
  }

  slider.addEventListener("input", function() { stopPlay(); setIndex(parseInt(slider.value, 10)); });
  document.getElementById("prev-btn").addEventListener("click", function() { stopPlay(); setIndex(currentIdx - 1); });
  document.getElementById("next-btn").addEventListener("click", function() { stopPlay(); setIndex(currentIdx + 1); });

  var playBtn = document.getElementById("play-btn");
  function stopPlay() {
    if (playTimer) { clearInterval(playTimer); playTimer = null; playBtn.innerHTML = "&#9654; play"; }
  }
  playBtn.addEventListener("click", function() {
    if (playTimer) { stopPlay(); return; }
    playBtn.innerHTML = "&#10074;&#10074; pause";
    playTimer = setInterval(function() {
      if (currentIdx >= n - 1) { stopPlay(); return; }
      setIndex(currentIdx + 1);
    }, 450);
  });

  chartWrap.setAttribute("tabindex", "0");
  chartWrap.addEventListener("keydown", function(ev) {
    if (ev.key === "ArrowLeft") { stopPlay(); setIndex(currentIdx - 1); ev.preventDefault(); }
    if (ev.key === "ArrowRight") { stopPlay(); setIndex(currentIdx + 1); ev.preventDefault(); }
  });

  var tableToggle = document.getElementById("table-toggle");
  tableToggle.addEventListener("click", function() {
    var showing = tableScroll.style.display !== "none";
    tableScroll.style.display = showing ? "none" : "block";
    tableToggle.textContent = showing ? "Show table view" : "Hide table view";
    tableToggle.setAttribute("aria-expanded", showing ? "false" : "true");
  });

  window.addEventListener("resize", function() { render(currentIdx); });

  setIndex(n - 1);
})();
</script>
</body>
</html>
"""


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--replay-csv", required=True)
    ap.add_argument("--votes-csv", required=True)
    ap.add_argument("--interval", type=int, default=10, help="minutes between checkpoints (label only)")
    ap.add_argument("--signal-threshold", type=float, default=0.35)
    ap.add_argument("--out", required=True)
    ap.add_argument("--live", action="store_true",
                     help="label this as a still-in-progress session instead of a completed day, and default "
                          "the slider to the LATEST checkpoint instead of the first")
    args = ap.parse_args()

    data = build_chart_data(args.replay_csv, args.votes_csv, args.interval, args.signal_threshold)
    html = render_html(data, live=args.live)
    with open(args.out, "w") as f:
        f.write(html)
    print(f"Wrote {args.out} ({len(html)} bytes, {len(data['checkpoints'])} checkpoints)")


if __name__ == "__main__":
    main()
