"""
Historical daily options-chain snapshots from purchased end-of-day Greek
data (a "DG_<Month><Year>.zip" export -- see README's "Historical options
chains" section for where this comes from and how to get more days).

The vendor ships one CSV pair per trading day, `Greek_YYYYMMDD_OData1.csv`
/ `Greek_YYYYMMDD_OData2.csv`, splitting that day's ~5,600 optionable
tickers roughly in half across the two files (not alphabetically or by
any other predictable rule, based on the one real day inspected while
building this -- so both files always need to be checked for a given
symbol, not just one). Each row is ONE option contract (one strike, one
expiration, one side: call or put) as of that day's snapshot, with real
Greeks (IV, Delta, Gamma, Vega, Rho, Theta) already computed by the
vendor. This is an end-of-day read, not intraday and not tick-by-tick --
same spirit as the daily OHLCV `backtest.py` already uses, just for the
options chain instead of the underlying.

Why this matters: `gamma_positioning.py`, `vanna_charm.py`,
`vol_regime.py`'s put/call ratio, and `skew_dynamics.py` have all only
ever been able to run against a LIVE chain (today's, via
`fetch_chain_yfinance`) -- there was no free source of historical chains,
so they sat out of every backtest, contributing a neutral vote. This
module turns a folder of these vendor CSVs into the same `ChainSnapshot`
shape `fetch_chain_yfinance()` produces, so those voters can run for real
on historical days for the first time. See `backtest.py --chain-dir`.
"""

import glob
import os
import re
from datetime import datetime, date as date_cls
from typing import Dict, List

import pandas as pd

from gamma_positioning import ChainSnapshot

FILENAME_DATE_RE = re.compile(r"Greek_(\d{8})_OData\d+\.csv$")

USE_COLUMNS = ["Symbol", "ExpirationDate", "PutCall", "StrikePrice",
               "Volume", "OpenInterest", "UnderlyingPrice", "ImpliedVolatility", "DataDate"]


def load_symbol_from_greek_csvs(paths: List[str], symbol: str) -> pd.DataFrame:
    """Reads one or more Greek_YYYYMMDD_OData*.csv files and returns only
    the rows for `symbol` (exact match on the Symbol column), concatenated
    across whichever file(s) actually contain it -- pass both OData1 and
    OData2 for a given day since which half a symbol lands in isn't
    predictable. Raises if `symbol` isn't found in ANY of the files --
    that almost always means the wrong day's files were passed in, not
    that the symbol genuinely has zero contracts that day."""
    frames = []
    for path in paths:
        df = pd.read_csv(path, usecols=USE_COLUMNS)
        match = df[df["Symbol"] == symbol]
        if len(match):
            frames.append(match)
    if not frames:
        raise ValueError(f"'{symbol}' not found in any of {paths} -- check these are the right "
                          f"day's OData1/OData2 files, and that '{symbol}' is spelled/cased exactly "
                          f"as the vendor lists it")
    return pd.concat(frames, ignore_index=True)


def list_expirations(symbol_df: pd.DataFrame) -> pd.DataFrame:
    """Available expirations for this symbol/day, with row counts -- the
    quickest way to see which expiration is the 0DTE/1DTE contract."""
    return (symbol_df.groupby("ExpirationDate").size().reset_index(name="n_rows")
            .sort_values("ExpirationDate").reset_index(drop=True))


def build_chain_snapshot(symbol_df: pd.DataFrame, expiration: str) -> ChainSnapshot:
    """Pivots one expiration's call/put rows into a gamma_positioning.
    ChainSnapshot -- the exact shape fetch_chain_yfinance() produces, so
    every existing chain-dependent voter runs against this unmodified."""
    exp_df = symbol_df[symbol_df["ExpirationDate"] == expiration]
    if exp_df.empty:
        raise ValueError(f"No rows for expiration {expiration} in this symbol's data")

    data_date = exp_df["DataDate"].iloc[0]
    spot = float(exp_df["UnderlyingPrice"].iloc[0])

    calls = exp_df[exp_df["PutCall"] == "call"][["StrikePrice", "OpenInterest", "ImpliedVolatility", "Volume"]]
    puts = exp_df[exp_df["PutCall"] == "put"][["StrikePrice", "OpenInterest", "ImpliedVolatility", "Volume"]]
    merged = pd.merge(calls, puts, on="StrikePrice", how="outer", suffixes=("_call", "_put")).fillna(0)
    merged = merged.sort_values("StrikePrice")

    exp_dt = datetime.strptime(str(expiration), "%Y-%m-%d")
    date_dt = datetime.strptime(str(data_date), "%Y-%m-%d")
    # floor at 60 seconds (not 0) so a same-day (0DTE) expiration still
    # prices as "almost no time left" rather than a division-by-zero
    years = max((exp_dt - date_dt).total_seconds(), 60) / (365 * 24 * 3600)

    return ChainSnapshot(
        strike=merged["StrikePrice"].to_numpy(dtype=float),
        call_oi=merged["OpenInterest_call"].to_numpy(dtype=float),
        put_oi=merged["OpenInterest_put"].to_numpy(dtype=float),
        call_iv=merged["ImpliedVolatility_call"].to_numpy(dtype=float),
        put_iv=merged["ImpliedVolatility_put"].to_numpy(dtype=float),
        call_volume=merged["Volume_call"].to_numpy(dtype=float),
        put_volume=merged["Volume_put"].to_numpy(dtype=float),
        time_to_expiry_years=years,
        spot=spot,
    )


def nearest_expiration_chain_snapshot(symbol_df: pd.DataFrame, min_days_out: int = 0) -> ChainSnapshot:
    """Convenience wrapper: builds a ChainSnapshot for the nearest
    expiration at least `min_days_out` calendar days after the data date.
    min_days_out=0 (default) picks 0DTE if it's listed that day, 1 skips
    to the next expiration after that (the "1DTE" contract on a day
    without same-day expirations), etc."""
    data_date = symbol_df["DataDate"].iloc[0]
    date_dt = datetime.strptime(str(data_date), "%Y-%m-%d")
    exps = list_expirations(symbol_df)
    exps["days_out"] = exps["ExpirationDate"].apply(
        lambda e: (datetime.strptime(str(e), "%Y-%m-%d") - date_dt).days)
    candidates = exps[exps["days_out"] >= min_days_out].sort_values("days_out")
    if candidates.empty:
        raise ValueError(f"No expiration at least {min_days_out} days out from {data_date} -- "
                          f"available expirations: {sorted(exps['ExpirationDate'].tolist())}")
    return build_chain_snapshot(symbol_df, candidates.iloc[0]["ExpirationDate"])


def build_chain_lookup_from_dir(dir_path: str, symbol: str = "SPY",
                                 min_days_out: int = 0) -> Dict[date_cls, ChainSnapshot]:
    """Scans `dir_path` for `Greek_YYYYMMDD_OData*.csv` files (however
    many days happen to be sitting there -- this is meant to work whether
    you've extracted one day or a whole month), groups them by the date in
    the filename, and builds one nearest-expiration ChainSnapshot per date
    for `symbol`. Returns {date: ChainSnapshot} -- pass this straight to
    backtest.py's `simulate_ensemble_trades(chain_by_date=...)` so days
    with a real chain use it instead of sitting the chain-dependent voters
    out. Days that error (symbol not found, no valid expiration, etc) are
    skipped with a printed warning rather than aborting the whole scan --
    a backtest with some days having real chains and others not is still
    strictly better than none having them."""
    by_date: Dict[str, List[str]] = {}
    for path in glob.glob(os.path.join(dir_path, "Greek_*_OData*.csv")):
        m = FILENAME_DATE_RE.search(os.path.basename(path))
        if not m:
            continue
        by_date.setdefault(m.group(1), []).append(path)

    lookup: Dict[date_cls, ChainSnapshot] = {}
    for date_str, paths in sorted(by_date.items()):
        d = datetime.strptime(date_str, "%Y%m%d").date()
        try:
            symbol_df = load_symbol_from_greek_csvs(sorted(paths), symbol)
            lookup[d] = nearest_expiration_chain_snapshot(symbol_df, min_days_out=min_days_out)
        except ValueError as e:
            print(f"[warn] skipping {d} in {dir_path} ({e})")
    return lookup
