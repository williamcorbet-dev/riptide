"""
The specific discretionary pattern described in the project conversation
(not derived from a voter or the ensemble -- this is a distinct, personal
trading rhythm, encoded here as its own small module so it can be
backtested and reviewed on its own terms before any decision is made
about whether/how it feeds into composite_signal.py):

  1. Direction is read from price action + time zone during an ENTRY
     WINDOW, roughly 10:00-11:30 -- this lines up with where real
     reversals and trend-day launches clustered across 30 real days (see
     README's "Time-of-day timing" section).
  2. If that read is wrong and the trade is underwater heading into
     midday, there is USUALLY (not always) a countertrend bounce
     somewhere in a BOUNCE WINDOW, roughly 11:55-13:00, that can be
     averaged into to reduce or erase the loss.

This module has two halves:
  - `zigzag_legs()`: a swing/leg detector (a multi-bar move can absorb a
    small consolidation without being counted as "reversed" -- same
    definition used ad hoc while exploring this with real charts, now a
    real reusable function instead of a one-off script).
  - `simulate_playbook()`: an honest backtest of the MECHANICAL version of
    the rule above (assumes a possibly-unrealistic "perfect read" of the
    entry window's own eventual direction -- see its docstring) against
    real historical price bars, so there's a real baseline number before
    layering in actual discretionary trade results.

This is NOT wired into composite_signal.py / the live ensemble yet --
deliberately kept standalone so it can be validated against a real trade
log first (see `trades.csv` / `TradeLogEntry` below and README's "Daily
playbook review" section).
"""

import csv
import os
from dataclasses import dataclass, asdict
from typing import List, Optional

import numpy as np
import pandas as pd

TRADE_LOG_PATH = os.path.join(os.path.dirname(__file__), "trades.csv")
TRADE_LOG_FIELDS = [
    "date", "entry_time", "direction", "spy_entry_price", "setup_notes",
    "averaged_down", "avg_down_time", "avg_down_price",
    "exit_time", "exit_price", "pnl_dollars", "outcome_notes",
]


def zigzag_legs(times: List[pd.Timestamp], prices: np.ndarray, retrace_pct: float = 0.0010) -> List[dict]:
    """Swing/leg detector: a leg keeps extending as long as price makes a
    new extreme in its direction; a pullback smaller than `retrace_pct` of
    the running extreme is absorbed as consolidation-within-the-leg rather
    than ending it. A leg only closes out once price retraces at least
    `retrace_pct` from that running extreme -- so a multi-bar move with a
    pause in the middle still counts as ONE leg, matching how this was
    described while looking at real 5-min charts (see README's case
    studies for the manual version of this same exercise).

    Returns a list of dicts, each: start_time, end_time, start_px, end_px,
    move_pct (signed), direction ('up'/'down'), duration_min. The very
    last leg in progress at the end of `prices` is included even if it
    never got confirmed by an opposing retracement.
    """
    if len(prices) < 2:
        return []

    legs = []
    pivot_i, pivot_p = 0, prices[0]
    extreme_i, extreme_p = 0, prices[0]
    direction = None

    for i in range(1, len(prices)):
        p = prices[i]
        if direction is None:
            if p > extreme_p:
                extreme_i, extreme_p = i, p
            elif p < extreme_p:
                extreme_i, extreme_p = i, p
            if extreme_p >= pivot_p * (1 + retrace_pct):
                direction = "up"
            elif extreme_p <= pivot_p * (1 - retrace_pct):
                direction = "down"
        elif direction == "up":
            if p >= extreme_p:
                extreme_i, extreme_p = i, p
            elif p <= extreme_p * (1 - retrace_pct):
                legs.append((pivot_i, extreme_i, pivot_p, extreme_p, "up"))
                pivot_i, pivot_p = extreme_i, extreme_p
                direction, extreme_i, extreme_p = "down", i, p
        elif direction == "down":
            if p <= extreme_p:
                extreme_i, extreme_p = i, p
            elif p >= extreme_p * (1 + retrace_pct):
                legs.append((pivot_i, extreme_i, pivot_p, extreme_p, "down"))
                pivot_i, pivot_p = extreme_i, extreme_p
                direction, extreme_i, extreme_p = "up", i, p

    if direction is not None and extreme_i != pivot_i:
        legs.append((pivot_i, extreme_i, pivot_p, extreme_p, direction))

    out = []
    for pi, ei, pp, ep, d in legs:
        out.append({
            "start_time": times[pi], "end_time": times[ei],
            "start_px": pp, "end_px": ep,
            "move_pct": (ep - pp) / pp * 100,
            "direction": d,
            "duration_min": (times[ei] - times[pi]).total_seconds() / 60,
        })
    return out


def _price_at(day_bars: pd.DataFrame, hhmm: str) -> Optional[float]:
    ts = pd.Timestamp(f"{day_bars.index[0].date()} {hhmm}")
    sub = day_bars[day_bars.index <= ts]
    return float(sub["Close"].iloc[-1]) if len(sub) else None


def classify_entry_window(day_bars: pd.DataFrame, window: tuple = ("10:00", "11:30"),
                           min_move_pct: float = 0.10) -> Optional[dict]:
    """Net move across the entry window, standing in for 'what direction
    would a read of this window's price action have pointed you.' Returns
    None if the move is too small to call a real setup (min_move_pct) --
    matching "only 2-3 trades a day," not one every day regardless of
    whether anything happened."""
    p_start = _price_at(day_bars, window[0])
    p_end = _price_at(day_bars, window[1])
    if p_start is None or p_end is None:
        return None
    move_pct = (p_end - p_start) / p_start * 100
    if abs(move_pct) < min_move_pct:
        return None
    return {
        "direction": "CALL" if move_pct > 0 else "PUT",
        "entry_price": p_start,
        "window_end_price": p_end,
        "move_pct": move_pct,
    }


def evaluate_bounce_opportunity(day_bars: pd.DataFrame, direction: str, entry_price: float,
                                 as_of: pd.Timestamp, bounce_window: tuple = ("11:55", "13:00"),
                                 min_leg_pct: float = 0.10) -> dict:
    """Live-use check: as of `as_of` (today, mid-session), is there a real
    countertrend leg happening inside the bounce window that's worth
    averaging into? `direction`: 'CALL' or 'PUT', the trade already taken.
    Returns whether we're currently inside the window, whether the trade
    is underwater, and the best favorable price seen in the window so
    far (None if no qualifying leg yet)."""
    trade_sign = 1 if direction == "CALL" else -1
    current_price = float(day_bars[day_bars.index <= as_of]["Close"].iloc[-1])
    underwater = (current_price - entry_price) * trade_sign < 0

    win_start = pd.Timestamp(f"{day_bars.index[0].date()} {bounce_window[0]}")
    win_end = pd.Timestamp(f"{day_bars.index[0].date()} {bounce_window[1]}")
    in_window = win_start <= as_of <= win_end

    window_bars = day_bars[(day_bars.index >= win_start) & (day_bars.index <= as_of)]
    best_favorable_price = None
    if in_window and len(window_bars) > 1:
        times, prices = list(window_bars.index), window_bars["Close"].values
        for leg in zigzag_legs(times, prices, retrace_pct=0.0006):
            against_trade_direction = "down" if direction == "CALL" else "up"
            if leg["direction"] == against_trade_direction and abs(leg["move_pct"]) >= min_leg_pct:
                candidate = leg["end_px"]
                if best_favorable_price is None or (candidate - entry_price) * trade_sign < \
                        (best_favorable_price - entry_price) * trade_sign:
                    best_favorable_price = candidate

    return {
        "current_price": current_price,
        "underwater": underwater,
        "in_bounce_window": in_window,
        "favorable_bounce_price": best_favorable_price,
        "recommend_average_down": bool(underwater and in_window and best_favorable_price is not None),
    }


def simulate_playbook(minute_df: pd.DataFrame, entry_window: tuple = ("10:00", "11:30"),
                       bounce_window: tuple = ("11:55", "13:00"), min_move_pct: float = 0.10,
                       min_leg_pct: float = 0.10, bar_freq: str = "5min") -> pd.DataFrame:
    """Honest backtest of the MECHANICAL rule, one row per day that had a
    real entry-window setup. IMPORTANT approximation: direction is taken
    to be whatever the entry window's own net move turned out to be (see
    `classify_entry_window`) -- i.e. this assumes a "perfect read" of
    that window, which real discretionary trading will NOT always get
    right. This is deliberately NOT a claim about your real hit rate --
    it's a baseline for "if the mechanical time-window rule is followed
    with a correct read, how much does averaging down on the bounce
    actually help," which is a different, narrower question. Real
    accuracy of the read itself can only come from your own trade log
    (see `trades.csv`).

    For each qualifying day, compares two hypothetical holds to the
    close: `pnl_pct_no_avg_down` (entered once, held) vs
    `pnl_pct_with_avg_down` (added at the best favorable bounce price, if
    the trade was underwater at the bounce window and one appeared) --
    equal-weighted between the two entries."""
    all_days = sorted(set(minute_df.index.normalize()))
    rows = []
    for d in all_days:
        day_bars = minute_df[minute_df.index.normalize() == d].between_time("09:30", "16:00")
        if day_bars.empty:
            continue
        bars5 = day_bars.resample(bar_freq, origin="start").agg({"Close": "last"}).dropna()

        setup = classify_entry_window(bars5, entry_window, min_move_pct)
        if setup is None:
            rows.append({"date": d.date().isoformat(), "has_setup": False})
            continue

        direction = setup["direction"]
        trade_sign = 1 if direction == "CALL" else -1
        entry_price = setup["entry_price"]
        day_close = float(day_bars["Close"].iloc[-1])

        win_end = pd.Timestamp(f"{d.date()} {bounce_window[1]}")
        eval_result = evaluate_bounce_opportunity(
            bars5, direction, entry_price, as_of=win_end,
            bounce_window=bounce_window, min_leg_pct=min_leg_pct,
        )
        underwater_at_bounce_window = eval_result["underwater"]
        # Only a candidate to average into if the trade actually NEEDED
        # saving at that point -- a countertrend leg that happens to occur
        # while an already-winning trade is open isn't something you'd
        # average down into, so it must not enter the blended-entry P&L.
        bounce_price = eval_result["favorable_bounce_price"] if underwater_at_bounce_window else None

        pnl_no_avg = (day_close - entry_price) / entry_price * trade_sign * 100
        if bounce_price is not None:
            blended_entry = (entry_price + bounce_price) / 2
            pnl_with_avg = (day_close - blended_entry) / blended_entry * trade_sign * 100
        else:
            pnl_with_avg = pnl_no_avg  # nothing to average into -- same as not averaging

        rows.append({
            "date": d.date().isoformat(), "has_setup": True, "direction": direction,
            "entry_price": entry_price, "day_close": day_close,
            "underwater_at_bounce_window": underwater_at_bounce_window,
            "bounce_price": bounce_price,
            "pnl_pct_no_avg_down": pnl_no_avg,
            "pnl_pct_with_avg_down": pnl_with_avg,
            "avg_down_helped": bool(bounce_price is not None and pnl_with_avg > pnl_no_avg),
        })
    return pd.DataFrame(rows)


@dataclass
class TradeLogEntry:
    date: str
    entry_time: str
    direction: str                      # CALL / PUT
    spy_entry_price: float
    setup_notes: str = ""
    averaged_down: bool = False
    avg_down_time: str = ""
    avg_down_price: Optional[float] = None
    exit_time: str = ""
    exit_price: Optional[float] = None
    pnl_dollars: Optional[float] = None
    outcome_notes: str = ""


def append_trade(entry: TradeLogEntry, path: str = TRADE_LOG_PATH) -> None:
    file_exists = os.path.exists(path)
    with open(path, "a", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=TRADE_LOG_FIELDS)
        if not file_exists:
            writer.writeheader()
        writer.writerow(asdict(entry))


def load_trades(path: str = TRADE_LOG_PATH) -> pd.DataFrame:
    if not os.path.exists(path):
        return pd.DataFrame(columns=TRADE_LOG_FIELDS)
    return pd.read_csv(path)
