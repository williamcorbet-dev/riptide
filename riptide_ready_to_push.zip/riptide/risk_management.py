"""
Position sizing and exit rules layered on top of composite_signal output.
Everything upstream of this module (the voters, the scenario engine) only
decides DIRECTION and WHETHER to enter -- nothing about HOW MUCH to risk or
WHEN to get out once you're in. This module is that missing piece, flagged
as a gap in the original README.

Designed specifically around 1DTE option mechanics, not generic equity
risk management:
  - Stops are expressed as a percentage of premium, not underlying price,
    since options can reprice discontinuously and a fixed-dollar
    underlying stop doesn't translate cleanly to option P&L.
  - A hard time-based exit is included because theta decay accelerates
    sharply in a 1DTE contract's final hour -- "let it ride" is a much
    worse default here than on a multi-day swing trade.
  - Sizing scales down while the scenario engine is still in its
    'weighted_ensemble' fallback phase (i.e. hasn't accumulated 20+ real
    observations of this exact scenario yet) -- trust less until there's
    an actual track record, not just a plausible-looking design.
  - A daily loss circuit breaker stops new entries once cumulative
    session losses cross a threshold, a standard discretionary-trading
    guardrail against revenge-trading into a bad day.

None of this guarantees you won't lose money -- see README's "Important
limitations and risks". It only makes sure losses are bounded and sized on
purpose rather than by accident.
"""

from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class RiskConfig:
    account_size: float = 25000.0
    max_risk_per_trade_pct: float = 0.01           # 1% of account risked per trade, MAX
    confidence_floor_for_full_size: float = 0.85     # confidence needed to earn the full max_risk_per_trade_pct
    min_size_multiplier: float = 0.25                # floor once a trade clears the signal threshold at all
    unvalidated_track_record_discount: float = 0.5   # size multiplier while method == "weighted_ensemble"
    stop_loss_pct_of_premium: float = 0.50           # exit if option value drops 50% from entry
    profit_target_pct_of_premium: float = 1.00       # take (partial) profit at +100%
    trailing_stop_activate_pct: float = 0.75         # once up 75%, switch to a trailing stop...
    trailing_stop_giveback_pct: float = 0.35         # ...that gives back at most 35% of the peak gain
    hard_time_exit_minutes_before_close: int = 15    # force flat this close to the bell, regardless of P&L
    daily_loss_limit_pct: float = 0.03               # stop taking NEW entries once the day is down this much


@dataclass
class PositionSize:
    contracts: int
    dollar_risk: float
    dollar_risk_pct_of_account: float
    sizing_notes: List[str] = field(default_factory=list)


@dataclass
class ExitPlan:
    stop_loss_price: float
    profit_target_price: float
    trailing_stop_trigger_price: float
    trailing_stop_giveback_pct: float
    hard_exit_note: str


def size_position(final_signal, entry_premium: float, cfg: RiskConfig = None,
                   contract_multiplier: int = 100) -> PositionSize:
    """`final_signal`: a scenario_engine.FinalSignal (or anything exposing
    .signal, .confidence, and .method). Returns zero contracts for a
    "NONE" signal or non-positive premium -- this function assumes the
    caller already checked the signal is actionable, but is defensive
    about it anyway."""
    cfg = cfg or RiskConfig()
    notes: List[str] = []

    if getattr(final_signal, "signal", None) not in ("CALL", "PUT"):
        return PositionSize(contracts=0, dollar_risk=0.0, dollar_risk_pct_of_account=0.0,
                             sizing_notes=["no actionable signal -- nothing to size"])

    if entry_premium <= 0:
        return PositionSize(contracts=0, dollar_risk=0.0, dollar_risk_pct_of_account=0.0,
                             sizing_notes=["entry premium is zero or negative -- can't size"])

    size_fraction = cfg.min_size_multiplier + (1 - cfg.min_size_multiplier) * min(
        1.0, final_signal.confidence / cfg.confidence_floor_for_full_size
    )

    if getattr(final_signal, "method", None) == "weighted_ensemble":
        size_fraction *= cfg.unvalidated_track_record_discount
        notes.append("sized down: scenario engine hasn't accumulated enough history for "
                      "this exact setup yet (still on the fallback weighted vote, not the "
                      "empirical scenario lookup)")

    max_dollar_risk = cfg.account_size * cfg.max_risk_per_trade_pct * size_fraction
    cost_per_contract = entry_premium * contract_multiplier
    max_loss_per_contract = cost_per_contract * cfg.stop_loss_pct_of_premium

    contracts = max(0, int(max_dollar_risk // max_loss_per_contract)) if max_loss_per_contract > 0 else 0
    if contracts == 0 and max_dollar_risk > 0:
        notes.append("risk budget too small for even 1 contract at this premium/stop -- "
                      "either raise max_risk_per_trade_pct or account_size, or skip this trade")

    dollar_risk = contracts * max_loss_per_contract
    return PositionSize(
        contracts=contracts,
        dollar_risk=dollar_risk,
        dollar_risk_pct_of_account=(dollar_risk / cfg.account_size) if cfg.account_size else 0.0,
        sizing_notes=notes,
    )


def build_exit_plan(entry_premium: float, cfg: RiskConfig = None) -> ExitPlan:
    cfg = cfg or RiskConfig()
    return ExitPlan(
        stop_loss_price=entry_premium * (1 - cfg.stop_loss_pct_of_premium),
        profit_target_price=entry_premium * (1 + cfg.profit_target_pct_of_premium),
        trailing_stop_trigger_price=entry_premium * (1 + cfg.trailing_stop_activate_pct),
        trailing_stop_giveback_pct=cfg.trailing_stop_giveback_pct,
        hard_exit_note=(f"force flat within {cfg.hard_time_exit_minutes_before_close} minutes "
                         f"of close regardless of P&L -- theta decay accelerates sharply here"),
    )


class DailyRiskTracker:
    """Tracks realized P&L for the trading session and enforces the daily
    loss circuit breaker. Call record_trade_result() after each closed
    trade; check can_enter_new_trade() before sizing the next one."""

    def __init__(self, cfg: RiskConfig = None):
        self.cfg = cfg or RiskConfig()
        self.realized_pnl = 0.0
        self.trades: List[float] = []

    def record_trade_result(self, pnl_dollars: float) -> None:
        self.realized_pnl += pnl_dollars
        self.trades.append(pnl_dollars)

    def _loss_limit(self) -> float:
        return -abs(self.cfg.account_size * self.cfg.daily_loss_limit_pct)

    def can_enter_new_trade(self) -> bool:
        return self.realized_pnl > self._loss_limit()

    def status(self) -> dict:
        return {
            "realized_pnl": self.realized_pnl,
            "trades_today": len(self.trades),
            "daily_loss_limit": self._loss_limit(),
            "circuit_breaker_tripped": not self.can_enter_new_trade(),
        }
