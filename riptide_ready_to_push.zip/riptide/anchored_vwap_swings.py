"""
Python port of a second Pine Script indicator Will shared (2026-08-20),
"Anchored VWAP Origin Chronicle": two anchored VWAPs, one starting from
the most recent CONFIRMED swing-high pivot and one from the most recent
confirmed swing-low pivot, each accumulating cumulative volume-weighted
price forward from its origin bar. The script then classifies price as
above both curves, below both, or between them, and highlights when the
two curves converge (bunch up close together).

This is a decision-relevant subset of the original script, not a full
port like `adaptive_supertrend.py` -- the original is ~700 lines and the
large majority of that is pure TradingView chart furniture (labels,
lines, a status table, alert-message formatting, multiple visual-only
input toggles for halos/precision cores/endpoint markers) that has no
effect on what price level the AVWAPs sit at or how price relates to
them. Kept: confirmed-pivot detection (`ta.pivothigh`/`ta.pivotlow`
equivalent), local-window ATR-normalized prominence filter, minimum-bars-
between-same-type-anchors cooldown, the default "Latest qualified"
replacement policy (the other two policies -- "More prominent only" and
"New price extreme only" -- are visual/tuning options in the original,
not implemented here), the cumulative anchored-VWAP calculation itself,
and the above-both/below-both/between/converged classification. Dropped:
the manual (click-to-place) anchor, relative-volume gating (off by
default in the original), all label/line/table/alert code, and the
non-default replacement policies.

Faithfulness notes:
  - AVWAP = cumsum(hlc3 * volume) / cumsum(volume) from the anchor bar
    forward, matching the original's `vwapSource` default (hlc3) and its
    volume-weighting. The original's Kahan (compensated) summation is a
    floating-point precision technique for very long-running charts; a
    plain pandas cumsum is numerically equivalent for the bar counts this
    project replays (one trading session, a few hundred 1-min bars).
  - Pivot confirmation matches `ta.pivothigh(left, right)`: a high is
    confirmed only once `right` bars exist after it and it is the max
    over the full `left+right+1` window -- i.e. a real bar in the past,
    never the live/still-forming bar, and never assumed knowable before
    `right` bars have actually printed.
  - Prominence, cooldown, and "Latest qualified" replacement all use the
    pivot's own bar values, not values only visible in hindsight past the
    confirmation point.

Like `adaptive_supertrend.py`, this needed 5-min resampling before it was
usable on this project's 1-min SPY bars -- see VOTER_CONFIG below and the
2026-08-20 daily_reviews.md entry for the frequency check that motivated
it.
"""

from dataclasses import dataclass

import numpy as np
import pandas as pd

from candlestick_patterns import resample_ohlc
from indicator import atr as wilder_atr
from voters import Vote, neutral_vote


@dataclass
class AnchoredVwapSwingsConfig:
    atr_length: int = 14
    pivot_left: int = 8
    pivot_right: int = 5
    minimum_prominence_atr: float = 1.0
    minimum_bars_between_same_type: int = 15
    convergence_threshold_atr: float = 0.25


# Tuned as a voter for THIS project's timeframe (2026-08-20, daily_reviews.md),
# same "too much noise below ~3min" reasoning as support_resistance.py /
# candlestick_patterns.py / adaptive_supertrend.py -- raw 1-min pivot_left=8/
# pivot_right=5 windows are only 13 minutes wide and produce constant
# low-prominence pivot noise. Resampling to 5-min bars first (pivot window
# becomes 65 minutes) is the fix; the Pine script's own default prominence/
# cooldown values were left untouched on top of that, see daily_reviews.md
# for the resulting frequency check.
VOTER_RESAMPLE_RULE = "5min"
VOTER_CONFIG = AnchoredVwapSwingsConfig()
MIN_RESAMPLED_BARS = 20  # ~100 minutes of 5-min bars, same floor as adaptive_supertrend


def compute_anchored_swing_avwaps(df: pd.DataFrame, cfg: AnchoredVwapSwingsConfig = None) -> pd.DataFrame:
    """`df` needs Open/High/Low/Close/Volume. Returns a copy of `df` with:
    high_avwap/low_avwap (NaN until each anchor exists), high_anchor_bar/
    low_anchor_bar (int index of the active origin, NaN until one exists),
    high_anchor_prominence/low_anchor_prominence, high_pivot_confirmed/
    low_pivot_confirmed (True only on the bar a NEW anchor is accepted),
    pair_ready, above_both, below_both, pair_spread_atr, pair_converged."""
    cfg = cfg or AnchoredVwapSwingsConfig()
    n = len(df)
    high, low, close = df["High"].to_numpy(), df["Low"].to_numpy(), df["Close"].to_numpy()
    volume = df["Volume"].to_numpy() if "Volume" in df.columns else np.zeros(n)
    source = ((df["High"] + df["Low"] + df["Close"]) / 3.0).to_numpy()  # hlc3, matches vwapSource default

    atr_vals = wilder_atr(df, cfg.atr_length).to_numpy()
    weight = np.where(np.isfinite(volume) & (volume > 0), volume, 0.0)
    weighted_price = source * weight
    cum_weight = np.cumsum(weight)
    cum_weighted_price = np.cumsum(weighted_price)

    left, right = cfg.pivot_left, cfg.pivot_right
    window = left + right + 1

    high_anchor_bar = np.full(n, np.nan)
    low_anchor_bar = np.full(n, np.nan)
    high_anchor_prominence = np.full(n, np.nan)
    low_anchor_prominence = np.full(n, np.nan)
    high_pivot_confirmed = np.zeros(n, dtype=bool)
    low_pivot_confirmed = np.zeros(n, dtype=bool)

    active_high_bar = None
    active_high_prom = None
    active_low_bar = None
    active_low_prom = None

    for t in range(n):
        # A pivot centered at (t - right) is confirmed on bar t once both
        # its left and right windows exist -- i.e. t >= left + right.
        pivot_idx = t - right
        if t >= window - 1 and pivot_idx - left >= 0:
            win_lo, win_hi = pivot_idx - left, pivot_idx + right + 1  # slice bounds, inclusive of both sides
            window_high = high[win_lo:win_hi]
            window_low = low[win_lo:win_hi]
            pivot_high_val = high[pivot_idx]
            pivot_low_val = low[pivot_idx]
            pivot_atr = atr_vals[pivot_idx]

            is_high_pivot = pivot_high_val == window_high.max() and (window_high == pivot_high_val).sum() == 1
            is_low_pivot = pivot_low_val == window_low.min() and (window_low == pivot_low_val).sum() == 1

            if is_high_pivot and not np.isnan(pivot_atr) and pivot_atr > 0:
                prominence = (pivot_high_val - window_low.min()) / pivot_atr
                cooldown_ok = active_high_bar is None or (pivot_idx - active_high_bar) >= cfg.minimum_bars_between_same_type
                if prominence >= cfg.minimum_prominence_atr and cooldown_ok:
                    active_high_bar = pivot_idx
                    active_high_prom = prominence
                    high_pivot_confirmed[t] = True

            if is_low_pivot and not np.isnan(pivot_atr) and pivot_atr > 0:
                prominence = (window_high.max() - pivot_low_val) / pivot_atr
                cooldown_ok = active_low_bar is None or (pivot_idx - active_low_bar) >= cfg.minimum_bars_between_same_type
                if prominence >= cfg.minimum_prominence_atr and cooldown_ok:
                    active_low_bar = pivot_idx
                    active_low_prom = prominence
                    low_pivot_confirmed[t] = True

        high_anchor_bar[t] = active_high_bar if active_high_bar is not None else np.nan
        high_anchor_prominence[t] = active_high_prom if active_high_prom is not None else np.nan
        low_anchor_bar[t] = active_low_bar if active_low_bar is not None else np.nan
        low_anchor_prominence[t] = active_low_prom if active_low_prom is not None else np.nan

    def _avwap_from_anchor(anchor_bar_arr):
        out = np.full(n, np.nan)
        for t in range(n):
            ab = anchor_bar_arr[t]
            if np.isnan(ab):
                continue
            ab = int(ab)
            w = cum_weight[t] - (cum_weight[ab - 1] if ab > 0 else 0.0)
            wp = cum_weighted_price[t] - (cum_weighted_price[ab - 1] if ab > 0 else 0.0)
            out[t] = wp / w if w > 0 else np.nan
        return out

    high_avwap = _avwap_from_anchor(high_anchor_bar)
    low_avwap = _avwap_from_anchor(low_anchor_bar)

    pair_ready = ~np.isnan(high_avwap) & ~np.isnan(low_avwap)
    pair_top = np.where(pair_ready, np.maximum(high_avwap, low_avwap), np.nan)
    pair_bottom = np.where(pair_ready, np.minimum(high_avwap, low_avwap), np.nan)
    pair_spread_atr = np.where(pair_ready & (atr_vals > 0), np.abs(high_avwap - low_avwap) / np.where(atr_vals > 0, atr_vals, np.nan), np.nan)
    above_both = pair_ready & (close > pair_top)
    below_both = pair_ready & (close < pair_bottom)
    pair_converged = pair_ready & ~np.isnan(pair_spread_atr) & (pair_spread_atr <= cfg.convergence_threshold_atr)

    out = df.copy()
    out["high_avwap"] = high_avwap
    out["low_avwap"] = low_avwap
    out["high_anchor_bar"] = high_anchor_bar
    out["low_anchor_bar"] = low_anchor_bar
    out["high_anchor_prominence"] = high_anchor_prominence
    out["low_anchor_prominence"] = low_anchor_prominence
    out["high_pivot_confirmed"] = high_pivot_confirmed
    out["low_pivot_confirmed"] = low_pivot_confirmed
    out["pair_ready"] = pair_ready
    out["above_both"] = above_both
    out["below_both"] = below_both
    out["pair_spread_atr"] = pair_spread_atr
    out["pair_converged"] = pair_converged
    return out


def anchored_vwap_swings_vote(intraday_df: pd.DataFrame, cfg: AnchoredVwapSwingsConfig = None,
                               resample_rule: str = VOTER_RESAMPLE_RULE) -> Vote:
    """Trend-CONFIRMING, same family as adaptive_supertrend: says "price
    has broken above/below both swing-anchored VWAPs" or "price just
    crossed one of them," never "this move is exhausted." A fresh cross
    of either AVWAP is the strongest read (0.5); already sitting above/
    below both with nothing new this bar is a weaker continuation read
    (0.25); the two AVWAPs bunched together (converged) is treated as
    genuinely uninformative -- both reference lines agree with each
    other, not with any particular direction -- and gets a neutral vote
    rather than a guess."""
    if intraday_df is None or len(intraday_df) < 5:
        return neutral_vote("anchored_vwap_swings", "not enough intraday bars yet")

    resampled = resample_ohlc(intraday_df, resample_rule)
    if len(resampled) < MIN_RESAMPLED_BARS:
        return neutral_vote("anchored_vwap_swings", f"not enough {resample_rule} bars yet to trust either anchor")

    out = compute_anchored_swing_avwaps(resampled, cfg or VOTER_CONFIG)
    last = out.iloc[-1]
    prev = out.iloc[-2] if len(out) > 1 else None

    detail = {
        "high_avwap": None if pd.isna(last["high_avwap"]) else round(float(last["high_avwap"]), 4),
        "low_avwap": None if pd.isna(last["low_avwap"]) else round(float(last["low_avwap"]), 4),
        "pair_spread_atr": None if pd.isna(last["pair_spread_atr"]) else round(float(last["pair_spread_atr"]), 3),
        "resample_rule": resample_rule,
    }

    if not bool(last["pair_ready"]):
        return neutral_vote("anchored_vwap_swings", "waiting for both a confirmed swing-high and swing-low anchor")

    if bool(last["pair_converged"]):
        return Vote(name="anchored_vwap_swings", direction=0.0, confidence=0.0,
                    regime_tag="avwap_converged", detail=detail)

    was_ready = prev is not None and bool(prev["pair_ready"]) and not bool(prev["pair_converged"])
    fresh_cross_up = was_ready and bool(last["above_both"]) and not bool(prev["above_both"])
    fresh_cross_down = was_ready and bool(last["below_both"]) and not bool(prev["below_both"])

    if fresh_cross_up:
        return Vote(name="anchored_vwap_swings", direction=1.0, confidence=0.5,
                    regime_tag="broke_above_both", detail=detail)
    if fresh_cross_down:
        return Vote(name="anchored_vwap_swings", direction=-1.0, confidence=0.5,
                    regime_tag="broke_below_both", detail=detail)
    if bool(last["above_both"]):
        return Vote(name="anchored_vwap_swings", direction=1.0, confidence=0.25,
                    regime_tag="above_both", detail=detail)
    if bool(last["below_both"]):
        return Vote(name="anchored_vwap_swings", direction=-1.0, confidence=0.25,
                    regime_tag="below_both", detail=detail)
    return Vote(name="anchored_vwap_swings", direction=0.0, confidence=0.0,
                regime_tag="between_avwaps", detail=detail)
