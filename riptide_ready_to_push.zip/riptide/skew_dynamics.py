"""
25-delta put/call skew dynamics.

Equity index options are chronically skewed -- out-of-the-money puts trade
at higher implied vol than equidistant calls, because institutions
structurally buy downside protection. That skew LEVEL isn't itself a
useful signal (it's basically always true). What's actually informative is
the CHANGE: skew steepening (puts getting relatively more expensive) tends
to build ahead of, or alongside, downside moves; skew flattening reflects
complacency. This module tracks that change against the instrument's own
history, the same self-calibrating pattern as time_of_day_fingerprint.py.

Requires a live options chain spanning enough strikes to locate the
~25-delta put and ~25-delta call (see gamma_positioning.ChainSnapshot) --
same live-only data limitation as gamma_positioning.py/vanna_charm.py.

Persists daily skew readings to state/skew_history.json so that, like the
scenario engine, this genuinely gets more useful the longer it's run
against real data rather than requiring a paid historical chain archive
just to bootstrap. Today it will report "not enough history yet" -- that's
expected and honest, not a bug.
"""

import json
import os
from dataclasses import dataclass
from datetime import date
from typing import Optional

import numpy as np

from gamma_positioning import ChainSnapshot
from vanna_charm import bs_delta
from voters import Vote

DEFAULT_STATE_DIR = os.path.join(os.path.dirname(__file__), "state")
SKEW_HISTORY_PATH = os.path.join(DEFAULT_STATE_DIR, "skew_history.json")


def _nearest_delta_strike(strikes: np.ndarray, deltas: np.ndarray, target_delta: float) -> int:
    """Index of the strike whose delta is closest to target_delta."""
    return int(np.argmin(np.abs(deltas - target_delta)))


@dataclass
class SkewReading:
    date: str
    spot: float
    call_25d_strike: float
    call_25d_iv: float
    put_25d_strike: float
    put_25d_iv: float
    skew: float  # put IV - call IV, positive = normal smirk, larger = steeper


def compute_skew(chain: ChainSnapshot, r: float = 0.05, as_of: date = None) -> SkewReading:
    call_deltas = bs_delta(chain.spot, chain.strike, chain.time_to_expiry_years, r, chain.call_iv, "call")
    put_deltas = bs_delta(chain.spot, chain.strike, chain.time_to_expiry_years, r, chain.put_iv, "put")

    call_idx = _nearest_delta_strike(chain.strike, call_deltas, 0.25)
    put_idx = _nearest_delta_strike(chain.strike, put_deltas, -0.25)

    return SkewReading(
        date=(as_of or date.today()).isoformat(),
        spot=chain.spot,
        call_25d_strike=float(chain.strike[call_idx]),
        call_25d_iv=float(chain.call_iv[call_idx]),
        put_25d_strike=float(chain.strike[put_idx]),
        put_25d_iv=float(chain.put_iv[put_idx]),
        skew=float(chain.put_iv[put_idx] - chain.call_iv[call_idx]),
    )


class SkewHistoryStore:
    """Persistent (JSON-backed) log of daily skew readings, analogous to
    scenario_engine.ScenarioStore. One reading per calendar date -- calling
    record() again for the same date overwrites that date's entry rather
    than duplicating it."""

    def __init__(self, path: str = SKEW_HISTORY_PATH):
        self.path = path
        self.readings: dict = {}
        self._load()

    def _load(self):
        if os.path.exists(self.path):
            with open(self.path) as f:
                self.readings = json.load(f)

    def save(self):
        os.makedirs(DEFAULT_STATE_DIR, exist_ok=True)
        with open(self.path, "w") as f:
            json.dump(self.readings, f)

    def record(self, reading: SkewReading):
        self.readings[reading.date] = reading.skew
        self.save()

    def history(self, lookback_days: int = 60) -> list:
        dates_sorted = sorted(self.readings.keys())[-lookback_days:]
        return [self.readings[d] for d in dates_sorted]


def skew_vote(chain: ChainSnapshot, store: SkewHistoryStore = None, r: float = 0.05,
              min_history: int = 20, lookback_days: int = 60, as_of: date = None) -> Vote:
    """Steepening skew (today higher than its trailing history) -> bearish
    lean; flattening -> mild bullish/complacency lean. Confidence scales
    with |z-score| against trailing history, and is honestly zero until
    there's enough history to compute one -- this module gets more useful
    the longer it's run live, same philosophy as the scenario engine.

    `as_of`: the calendar date this reading should be recorded under
    (defaults to actual today if omitted). Matters for `backtest.py`
    walk-forward runs, which simulate many historical days in one process
    -- without passing the SIMULATED day here, every recorded reading
    would stamp under the same real wall-clock "today" and silently
    overwrite itself each iteration (same-date-overwrites is correct
    behavior for the live case this was designed for, but wrong for a
    walk-forward backtest, which needs one distinct entry per simulated
    day to ever accumulate real history)."""
    store = store or SkewHistoryStore()
    # Snapshot the trailing baseline BEFORE recording today's reading --
    # otherwise today's own value leaks into its own baseline (pulling the
    # mean toward itself and dampening the z-score), which is exactly the
    # self-referential trap time_of_day_fingerprint.py avoids by building
    # its fingerprint strictly from prior days before scoring today.
    hist = store.history(lookback_days)

    reading = compute_skew(chain, r, as_of=as_of)
    store.record(reading)  # persist today's reading for FUTURE days' baselines

    if len(hist) < min_history:
        return Vote(
            name="skew_dynamics", direction=0.0, confidence=0.0, live_only=True,
            detail={"reason": f"only {len(hist)} days of skew history recorded so far, "
                               f"need {min_history} -- this improves the longer it's run",
                    "today_skew": reading.skew},
        )

    hist_mean, hist_std = float(np.mean(hist)), float(np.std(hist))
    if hist_std < 1e-9:
        return Vote(name="skew_dynamics", direction=0.0, confidence=0.0, live_only=True,
                     detail={"reason": "no variation in skew history", "today_skew": reading.skew})

    z = (reading.skew - hist_mean) / hist_std
    direction = float(np.clip(-np.tanh(z / 2), -1, 1))  # steepening (z>0) -> bearish (negative direction)
    confidence = float(min(1.0, abs(z) / 2))

    return Vote(
        name="skew_dynamics",
        direction=direction,
        confidence=confidence,
        regime_tag="skew_steepening" if z > 1 else ("skew_flattening" if z < -1 else None),
        detail={"today_skew": reading.skew, "hist_mean": hist_mean, "hist_std": hist_std,
                "z_score": z, "n_days_history": len(hist)},
        live_only=True,
    )
