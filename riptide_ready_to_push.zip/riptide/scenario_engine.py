"""
Ensemble aggregation across all voters (see voters.py) -- the "council of
voters -> scenario fingerprint -> look for a trend in the responses"
architecture:

  1. Every voter's Vote is combined into a single "scenario fingerprint" --
     a compact snapshot of which regime every independent methodology
     currently thinks we're in (gamma positive/negative, Hurst trending/
     mean-reverting, HMM calm/stressed, candlestick reversal/none, VIX
     term structure calm/stress, FOMC calendar state, etc).
  2. If a similar fingerprint has been seen often enough before (tracked
     in a persistent local store), the empirically observed forward
     outcome for that exact scenario is used as the primary signal --
     this is the "look for a trend in the responses" part: rather than
     trusting a hand-tuned formula, let realized history tell you what
     actually tends to happen when this combination of conditions shows
     up.
  3. Where there isn't enough history for the exact scenario yet (which
     will be common early on -- the combinatorial space is large), it
     falls back to a confidence-weighted vote across all voters, using
     ADAPTIVE weights that themselves update over time based on which
     voters have actually been right (a Hedge-style multiplicative-
     weights online learning rule). The system's trust in each
     methodology should improve as real outcomes accumulate, rather than
     staying frozen at today's initial guess.

Both the scenario history and the voter weights persist to local JSON
files (see `state/`) so that repeated live runs accumulate evidence over
time instead of starting from scratch on every invocation. This is the
literal mechanism for "keep developing this until we have a real edge":
call `record_outcome()` once you know what actually happened, and the
system updates itself.
"""

import json
import math
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import List

from voters import Vote

DEFAULT_STATE_DIR = os.path.join(os.path.dirname(__file__), "state")
SCENARIO_STORE_PATH = os.path.join(DEFAULT_STATE_DIR, "scenario_history.json")
WEIGHTS_STORE_PATH = os.path.join(DEFAULT_STATE_DIR, "voter_weights.json")

SIGNAL_THRESHOLD = 0.35
MIN_SCENARIO_SAMPLES = 20    # min historical hits before trusting the empirical lookup over the fallback vote
LEARNING_RATE = 0.15         # Hedge-style multiplicative weight update rate

# Voters whose reading actually changes as the trading day unfolds (they
# take today's own intraday bars as input) -- as opposed to technical/
# hurst/hmm_regime/fomc_calendar/gamma_regime/vanna_charm/put_call_ratio/
# skew_dynamics/vix_term_structure, which are each computed once (from
# daily bars, a calendar date, or a single chain snapshot) and then don't
# change for the rest of that session no matter what price actually does.
INTRADAY_REACTIVE_VOTERS = frozenset({"intraday_technical", "candlesticks", "support_resistance", "time_of_day",
                                       "vwap_reversion", "mfi_divergence", "adaptive_supertrend"})

# Added 2026-08-18 (daily_reviews.md's 2026-08-18 entry, "make it dynamic"
# / Will's request): two related, evidence-driven fixes to the
# weighted_ensemble fallback (aggregate()'s no-exact-scenario-match path,
# which is the overwhelming majority of real signals -- see that entry for
# why). Both default to a no-op when unused, so nothing about the plain
# daily-only backtest path changes unless a caller opts in.
#
# 1) WEIGHT_DAMPEN_EXPONENT: adaptive trust weights are raised to this
#    power before use (0.5 = square root). At weight==1.0 (every existing
#    test's default, and any voter with no track record yet) this is an
#    exact no-op. Its purpose: a Hedge-style weight learned from a long
#    real history can end up MUCH larger than the others just from a
#    small, consistent statistical edge compounding over many samples
#    (see hmm_regime: right ~56% of the time across 3 years of real daily
#    bars compounded to a weight ~25x hurst's) -- mathematically
#    legitimate, but it means that one voter's opinion can single-
#    handedly outvote several other voters that all disagree with it in
#    the moment, which is exactly backwards for an ensemble whose whole
#    point is that no one methodology should get to unilaterally decide.
#    Compressing the range preserves *rank* (more-trusted still counts
#    for more) without letting the gap become total override power.
# 2) INTRADAY_BOOST_MAX: on top of that, INTRADAY_REACTIVE_VOTERS get an
#    extra multiplier that grows from 1x (market just opened, ~no
#    intraday evidence yet) up to (1 + this) by a full session's worth of
#    bars -- concretely: at 2026-08-18's actual ~11:20am low, three
#    intraday-reactive voters unanimously and confidently read the real
#    reversal-forming there while the frozen daily-bar voters (still
#    reading that morning's stale open-of-day picture) kept the ensemble
#    net bullish/neutral straight through it. The daily-bar context is
#    real information and still gets a vote -- it just shouldn't get to
#    keep outvoting live, unanimous, high-confidence intraday reads once
#    there's real intraday evidence to weigh against it.
WEIGHT_DAMPEN_EXPONENT = 0.5
INTRADAY_BOOST_MAX = 1.5


def _ensure_state_dir():
    os.makedirs(DEFAULT_STATE_DIR, exist_ok=True)


def scenario_fingerprint(votes: List[Vote]) -> str:
    """Compact, order-independent fingerprint built from each voter's
    regime_tag (falling back to a coarse direction bucket for voters that
    don't set one)."""
    parts = []
    for v in sorted(votes, key=lambda v: v.name):
        tag = v.regime_tag
        if tag is None:
            tag = "no_opinion" if v.confidence < 0.05 else ("bullish" if v.direction > 0 else "bearish")
        parts.append(f"{v.name}={tag}")
    return "|".join(parts)


@dataclass
class ScenarioRecord:
    fingerprint: str
    outcomes: List[float] = field(default_factory=list)  # realized forward returns observed for this fingerprint

    @property
    def n(self) -> int:
        return len(self.outcomes)

    @property
    def mean_outcome(self) -> float:
        return sum(self.outcomes) / len(self.outcomes) if self.outcomes else 0.0

    @property
    def win_rate(self) -> float:
        return sum(1 for o in self.outcomes if o > 0) / len(self.outcomes) if self.outcomes else 0.0


class ScenarioStore:
    """Persistent (JSON-backed) table of fingerprint -> observed outcomes."""

    def __init__(self, path: str = SCENARIO_STORE_PATH):
        self.path = path
        self.records: dict = {}
        self._load()

    def _load(self):
        if os.path.exists(self.path):
            with open(self.path) as f:
                raw = json.load(f)
            for fp, outcomes in raw.items():
                self.records[fp] = ScenarioRecord(fingerprint=fp, outcomes=outcomes)

    def save(self):
        _ensure_state_dir()
        raw = {fp: rec.outcomes for fp, rec in self.records.items()}
        with open(self.path, "w") as f:
            json.dump(raw, f)

    def get(self, fingerprint: str) -> ScenarioRecord:
        return self.records.get(fingerprint, ScenarioRecord(fingerprint=fingerprint))

    def record_outcome(self, fingerprint: str, realized_return: float):
        rec = self.records.setdefault(fingerprint, ScenarioRecord(fingerprint=fingerprint))
        rec.outcomes.append(realized_return)
        self.save()


class AdaptiveWeights:
    """Hedge-style multiplicative-weights tracker for per-voter trust."""

    def __init__(self, path: str = WEIGHTS_STORE_PATH, learning_rate: float = LEARNING_RATE):
        self.path = path
        self.learning_rate = learning_rate
        self.weights: dict = {}
        self._load()

    def _load(self):
        if os.path.exists(self.path):
            with open(self.path) as f:
                self.weights = json.load(f)

    def save(self):
        _ensure_state_dir()
        with open(self.path, "w") as f:
            json.dump(self.weights, f)

    def get(self, voter_name: str) -> float:
        return self.weights.get(voter_name, 1.0)

    def update(self, votes: List[Vote], realized_return: float):
        outcome_sign = 1.0 if realized_return > 0 else (-1.0 if realized_return < 0 else 0.0)
        for v in votes:
            if v.confidence < 1e-6:
                continue
            vote_sign = 1.0 if v.direction > 0 else (-1.0 if v.direction < 0 else 0.0)
            reward = outcome_sign * vote_sign * v.confidence
            w = self.get(v.name) * math.exp(self.learning_rate * reward)
            self.weights[v.name] = w
        if self.weights:
            avg = sum(self.weights.values()) / len(self.weights)
            if avg > 0:
                for k in self.weights:
                    self.weights[k] /= avg
        self.save()


@dataclass
class FinalSignal:
    direction: float
    signal: str             # "CALL" / "PUT" / "NONE"
    confidence: float
    method: str              # "empirical_scenario" or "weighted_ensemble"
    fingerprint: str
    votes: List[Vote]
    scenario_n: int = 0
    scenario_win_rate: float = 0.0
    dampener: float = 1.0
    grind_suppressed: bool = False  # True if a real CALL/PUT was overridden to NONE by the
                                     # low-volatility "grind" gate -- see composite_signal.py's
                                     # generate_signal() and find_reversals.py's is_grinding_now().
                                     # direction/confidence/votes below are left UNCHANGED (the
                                     # gate only touches the tradeable classification), so this
                                     # flag is what tells a reader "the ensemble did have an
                                     # opinion here, it just didn't clear the reliability bar."
    generated_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def breakdown(self) -> str:
        lines = [f"Signal: {self.signal}  (direction={self.direction:+.3f}, "
                 f"confidence={self.confidence:.3f}, method={self.method})"]
        if self.grind_suppressed:
            lines.append("  [suppressed: low-volatility grind in progress -- see "
                          "daily_reviews.md, 2026-08-21]")
        if self.method == "empirical_scenario":
            lines.append(f"  scenario seen {self.scenario_n}x before, win rate {self.scenario_win_rate:.1%}")
        for v in self.votes:
            lines.append(f"  {v.name:20s} dir={v.direction:+.2f}  conf={v.confidence:.2f}  "
                          f"regime={v.regime_tag}{'  [live-only]' if v.live_only else ''}")
        return "\n".join(lines)


def aggregate(votes: List[Vote], scenario_store: ScenarioStore = None,
              adaptive_weights: AdaptiveWeights = None,
              signal_threshold: float = SIGNAL_THRESHOLD,
              min_scenario_samples: int = MIN_SCENARIO_SAMPLES,
              session_progress: float = 0.0) -> FinalSignal:
    """`session_progress`: 0.0 (market just opened, no intraday evidence
    yet) to 1.0 (a full session's worth of today's bars visible) -- only
    affects the weighted_ensemble fallback below, and only
    INTRADAY_REACTIVE_VOTERS' weight within it. Defaults to 0.0 (no
    boost), so omitting it -- e.g. every daily-only backtest call --
    behaves exactly as before. See INTRADAY_BOOST_MAX's comment above."""
    scenario_store = scenario_store or ScenarioStore()
    adaptive_weights = adaptive_weights or AdaptiveWeights()

    fp = scenario_fingerprint(votes)
    record = scenario_store.get(fp)

    # Some voters (e.g. VIX term structure in backwardation) don't vote a
    # direction but want to suppress overall confidence in everyone else --
    # they signal this via detail["dampener"] in [0, 1].
    dampener = 1.0
    for v in votes:
        if "dampener" in v.detail:
            dampener = min(dampener, v.detail["dampener"])

    if record.n >= min_scenario_samples:
        # Direction is derived from WIN RATE, not raw mean-return magnitude:
        # mean_outcome's units depend entirely on what the caller passes to
        # record_outcome() (raw daily return ~0.005, option P&L% ~1.0+,
        # etc), so using it directly would silently mis-scale depending on
        # the caller. Win rate is unit-agnostic: at 50% it's dead neutral,
        # at 75%+ it saturates to full direction. mean_outcome is still
        # surfaced in the breakdown for context (typical magnitude), just
        # not used to set direction.
        direction = float(max(-1.0, min(1.0, (record.win_rate - 0.5) * 4)))
        confidence = float(min(1.0, abs(record.win_rate - 0.5) * 2)) * dampener
        method = "empirical_scenario"
    else:
        session_progress = max(0.0, min(1.0, session_progress))
        weighted_sum, weight_total = 0.0, 0.0
        for v in votes:
            trust = adaptive_weights.get(v.name) ** WEIGHT_DAMPEN_EXPONENT
            if v.name in INTRADAY_REACTIVE_VOTERS:
                trust *= (1.0 + INTRADAY_BOOST_MAX * session_progress)
            w = trust * v.confidence
            weighted_sum += w * v.direction
            weight_total += w
        direction = float(weighted_sum / weight_total) if weight_total > 1e-9 else 0.0
        confidence = float(min(1.0, abs(weighted_sum) / weight_total)) * dampener if weight_total > 1e-9 else 0.0
        method = "weighted_ensemble"

    if confidence > 0 and direction >= signal_threshold:
        signal = "CALL"
    elif confidence > 0 and direction <= -signal_threshold:
        signal = "PUT"
    else:
        signal = "NONE"

    return FinalSignal(
        direction=direction, signal=signal, confidence=confidence, method=method,
        fingerprint=fp, votes=votes, scenario_n=record.n, scenario_win_rate=record.win_rate,
        dampener=dampener,
    )


def record_outcome(final_signal: FinalSignal, realized_return: float,
                    scenario_store: ScenarioStore = None, adaptive_weights: AdaptiveWeights = None):
    """Call once the actual outcome is known (e.g. next-day close-to-close
    return, or the option's realized P&L) to teach the system from this
    instance. Both the scenario table and the adaptive voter weights
    update from every recorded outcome -- this is what lets the system
    improve rather than stay frozen at today's initial design."""
    scenario_store = scenario_store or ScenarioStore()
    adaptive_weights = adaptive_weights or AdaptiveWeights()
    scenario_store.record_outcome(final_signal.fingerprint, realized_return)
    adaptive_weights.update(final_signal.votes, realized_return)
