"""
Orchestrates every voter into one final CALL/PUT/NONE signal via the
scenario engine (scenario_engine.py). This is the top-level entry point
both live_signal.py and backtest.py use.

Not every voter needs every input -- pass what you have. Modules that need
a live options chain (gamma positioning, vanna/charm, put/call ratio, skew
dynamics) fall back to a neutral no-opinion vote if no chain snapshot is
supplied, e.g. when running a historical backtest that only has daily
OHLCV. Cross-asset lead-lag is fully backtestable (daily OHLCV only) and
is included whenever `leader_data` is supplied.

Integration rule for gamma regime vs. the technical score (per the agreed
methodology): gamma regime decides the MODE, the technical composite
decides the DIRECTION.
  - negative gamma (dealers short gamma, trend-amplifying): the gamma
    voter follows the technical score's direction directly.
  - positive gamma (dealers long gamma, mean-reverting/pinning): the gamma
    voter fades extension back toward max pain, blended with a damped
    technical score (0.7 fade / 0.3 technical).
"""

from dataclasses import dataclass, replace
from datetime import date
from typing import Optional

import numpy as np
import pandas as pd

from voters import Vote, neutral_vote
from indicator import compute_indicator, IndicatorConfig
from gamma_positioning import ChainSnapshot, compute_gamma_profile, GammaProfile
from vanna_charm import compute_vanna_charm, vanna_charm_vote, VannaCharmHistoryStore
from vol_regime import vix_term_structure_vote, put_call_ratio_vote, put_call_ratio_vote_from_ratio
from regime_hmm import hmm_vote
from hurst import hurst_vote
from calendar_overlay import calendar_vote
from candlestick_patterns import candlestick_vote
from time_of_day_fingerprint import build_fingerprint, fingerprint_vote
from cross_asset_leadlag import leadlag_vote
from skew_dynamics import SkewHistoryStore, skew_vote
from support_resistance import support_resistance_vote
from vwap_reversion import vwap_reversion_vote
from mfi_divergence import mfi_divergence_vote
from adaptive_supertrend import adaptive_supertrend_vote
from scenario_engine import aggregate, FinalSignal, ScenarioStore, AdaptiveWeights, SIGNAL_THRESHOLD
from find_reversals import is_grinding_now

# Placeholder base confidence for the gamma-regime voter until real history
# lets us normalize |total_gex| against its own rolling distribution (needs
# a running log of daily GEX snapshots, which only exists once this is run
# live regularly -- see README "Phase 2"). Using a fixed moderate value is
# more honest than a fake computed-looking number with no real basis.
GAMMA_BASE_CONFIDENCE = 0.55

FULL_SESSION_MINUTES = 390.0  # regular session, 9:30am-4:00pm ET -- see session_progress below


def technical_vote(daily_df: pd.DataFrame, cfg: IndicatorConfig = None) -> Vote:
    cfg = cfg or IndicatorConfig()
    ind = compute_indicator(daily_df, cfg)
    latest = ind.iloc[-1]
    score = float(latest["score"])
    rank = latest["atr_pct_rank"]
    tradeable = bool(cfg.atr_low_pct <= rank <= cfg.atr_high_pct) if not np.isnan(rank) else True
    confidence = min(1.0, abs(score) / max(cfg.signal_threshold, 1e-9)) if tradeable else 0.0
    return Vote(
        name="technical", direction=score, confidence=confidence,
        detail={"atr_pct_rank": None if np.isnan(rank) else float(rank), "tradeable_vol_regime": tradeable},
    )


def intraday_technical_vote(intraday_df: pd.DataFrame, cfg: IndicatorConfig = None) -> Vote:
    """Same trend/momentum/location math as `technical_vote` (EMA spread,
    MACD+RSI, price-vs-VWAP), but run on TODAY's own intraday bars instead
    of multi-week daily bars.

    Why this exists (2026-08-17 case): `technical_vote` runs on `daily_df`,
    so its EMA(9)/EMA(21)/EMA(50) are day-scale, not the intraday 21-EMA a
    discretionary trader actually watches -- and separately, that day-scale
    version got gated to zero confidence by the ATR volatility-regime
    filter for the whole session. Meanwhile Hurst and the HMM regime
    detector, both computed from daily_df too, kept the ensemble leaning
    CALL all morning while SPY spent 68% of the day below its own intraday
    21-EMA, because neither of them looks at intraday bars at all. This
    voter is the fix: it gives "what has price actually done TODAY,
    relative to its own EMAs" a real vote, using the identical scoring
    formula as the daily voter so it stays comparable/auditable, just fed a
    different timeframe.

    The volatility-regime gate is loosened (not removed on the daily
    voter -- only here) because it was tuned for a ~100-DAY lookback; on a
    1-minute series that same lookback and percentile band don't mean the
    same thing, and re-deriving the "right" intraday equivalent isn't
    obviously better than just not gating this particular voter -- the gate's
    original job (skip dead/chaotic regimes) is still done by the daily
    voter, which keeps its gate as-is.
    """
    cfg = cfg or IndicatorConfig()
    if len(intraday_df) < cfg.atr_period + 1:
        return neutral_vote("intraday_technical", "not enough intraday bars yet today")

    intraday_cfg = replace(cfg, atr_lookback=60, atr_low_pct=0.0, atr_high_pct=1.0)
    ind = compute_indicator(intraday_df, intraday_cfg)
    latest = ind.iloc[-1]
    score = float(latest["score"])
    rank = latest["atr_pct_rank"]
    tradeable = bool(intraday_cfg.atr_low_pct <= rank <= intraday_cfg.atr_high_pct) if not np.isnan(rank) else False
    confidence = min(1.0, abs(score) / max(cfg.signal_threshold, 1e-9)) if tradeable else 0.0
    return Vote(
        name="intraday_technical", direction=score, confidence=confidence,
        detail={"atr_pct_rank": None if np.isnan(rank) else float(rank),
                "note": "live EMA(9)/EMA(21)/EMA(50)+MACD+RSI+VWAP read on today's own bars"},
    )


def gamma_regime_vote(profile: GammaProfile, technical_direction: float, atr: float) -> Vote:
    if profile.regime == "negative":
        direction = technical_direction
    else:
        fade_direction = float(np.tanh((profile.max_pain_strike - profile.spot) / max(atr, 1e-9)))
        direction = 0.7 * fade_direction + 0.3 * technical_direction

    # Extra confidence when spot is meaningfully away from the zero-gamma
    # flip level (a regime read taken right at the flip point is much less
    # trustworthy than one taken well inside positive or negative territory).
    flip_confidence_boost = min(0.3, abs(profile.distance_to_flip_pct) * 10)

    return Vote(
        name="gamma_regime",
        direction=float(np.clip(direction, -1, 1)),
        confidence=min(1.0, GAMMA_BASE_CONFIDENCE + flip_confidence_boost),
        regime_tag=profile.regime,
        detail={
            "total_gex": profile.total_gex, "zero_gamma_flip": profile.zero_gamma_flip,
            "max_pain": profile.max_pain_strike, "spot": profile.spot,
            "distance_to_flip_pct": profile.distance_to_flip_pct,
        },
        live_only=True,
    )


@dataclass
class SignalInputs:
    daily_df: pd.DataFrame                              # required: daily OHLCV -- technical, HMM, Hurst
    intraday_df: Optional[pd.DataFrame] = None            # optional: <=3min bars for today -- candlesticks, time-of-day, support/resistance
    intraday_history: Optional[pd.DataFrame] = None       # optional: longer intraday history to build the time-of-day fingerprint
    chain: Optional[ChainSnapshot] = None                  # optional: live options chain -- gamma/vanna-charm/PCR/skew
    vix_df: Optional[pd.DataFrame] = None                  # optional: VIX/VIX3M history
    leader_data: Optional[dict] = None                     # optional: {ticker: pd.Series of Close} -- cross-asset lead-lag
    skew_store: Optional[SkewHistoryStore] = None          # optional: persistent skew history (defaults to state/skew_history.json)
    vanna_charm_store: Optional[VannaCharmHistoryStore] = None  # optional: persistent vanna/charm magnitude history
    put_call_ratio: Optional[float] = None                 # optional: pre-computed put/call ratio (e.g. Alpha Vantage),
                                                             # used only when `chain` isn't available -- see generate_signal
    today: Optional[date] = None
    hours_to_close: float = 3.0
    cfg: Optional[IndicatorConfig] = None


def generate_signal(inputs: SignalInputs, scenario_store: ScenarioStore = None,
                     adaptive_weights: AdaptiveWeights = None,
                     signal_threshold: float = SIGNAL_THRESHOLD) -> FinalSignal:
    """`signal_threshold` is exposed here (rather than hardcoded) so
    calibration tooling (see `daily_review.py`) can deliberately loosen it
    to surface more CALL/PUT alerts for review, without touching any
    voter's internal math. The live default (SIGNAL_THRESHOLD in
    scenario_engine.py, 0.35) is unchanged unless a caller explicitly
    passes a different value."""
    cfg = inputs.cfg or IndicatorConfig()
    ind = compute_indicator(inputs.daily_df, cfg)
    atr = float(ind["atr"].iloc[-1])

    votes = []

    tech_vote = technical_vote(inputs.daily_df, cfg)
    votes.append(tech_vote)
    votes.append(hurst_vote(inputs.daily_df["Close"]))
    votes.append(hmm_vote(inputs.daily_df["Close"]))
    votes.append(calendar_vote(inputs.today or date.today()))

    if inputs.leader_data:
        votes.append(leadlag_vote(inputs.leader_data, inputs.daily_df["Close"]))

    gamma_profile = None
    if inputs.chain is not None:
        gamma_profile = compute_gamma_profile(inputs.chain)
        votes.append(gamma_regime_vote(gamma_profile, tech_vote.direction, atr))
        votes.append(vanna_charm_vote(compute_vanna_charm(inputs.chain), inputs.hours_to_close,
                                       store=inputs.vanna_charm_store, as_of=inputs.today))
        votes.append(put_call_ratio_vote(inputs.chain))
        votes.append(skew_vote(inputs.chain, store=inputs.skew_store, as_of=inputs.today))
    else:
        votes.append(neutral_vote("gamma_regime", "no live options chain supplied"))
        if inputs.put_call_ratio is not None:
            votes.append(put_call_ratio_vote_from_ratio(inputs.put_call_ratio))

    if inputs.vix_df is not None:
        votes.append(vix_term_structure_vote(inputs.vix_df))

    if inputs.intraday_df is not None:
        votes.append(intraday_technical_vote(inputs.intraday_df, cfg))
        votes.append(candlestick_vote(inputs.intraday_df, gamma_profile=gamma_profile, atr=atr))

        prior_day_levels = None
        if inputs.daily_df is not None and len(inputs.daily_df) > 0:
            prior_row = inputs.daily_df.iloc[-1]
            prior_day_levels = {"high": float(prior_row["High"]), "low": float(prior_row["Low"]),
                                 "close": float(prior_row["Close"])}
        votes.append(support_resistance_vote(inputs.intraday_df, atr=atr, prior_day_levels=prior_day_levels))
        votes.append(vwap_reversion_vote(inputs.intraday_df))
        votes.append(mfi_divergence_vote(inputs.intraday_df))
        votes.append(adaptive_supertrend_vote(inputs.intraday_df))

    if inputs.intraday_df is not None and inputs.intraday_history is not None:
        fp_table = build_fingerprint(inputs.intraday_history)
        votes.append(fingerprint_vote(inputs.intraday_df, fp_table))

    # How much of today's regular session is actually visible right now,
    # 0.0 (open) -> 1.0 (a full ~6.5hr session of bars) -- lets aggregate()
    # give intraday-reactive voters more say as real intraday evidence
    # piles up instead of a fixed weight all day (see scenario_engine.py's
    # INTRADAY_BOOST_MAX). Derived from the bars' own timestamps, not bar
    # count, so it doesn't assume any particular bar spacing. Stays 0.0
    # (aggregate()'s no-op default) whenever there's no intraday_df at
    # all, e.g. every daily-only backtest call.
    session_progress = 0.0
    if inputs.intraday_df is not None and len(inputs.intraday_df) > 1:
        elapsed_minutes = (inputs.intraday_df.index[-1] - inputs.intraday_df.index[0]).total_seconds() / 60.0
        session_progress = max(0.0, min(1.0, elapsed_minutes / FULL_SESSION_MINUTES))

    result = aggregate(votes, scenario_store=scenario_store, adaptive_weights=adaptive_weights,
                        signal_threshold=signal_threshold, session_progress=session_progress)

    # Low-volatility "grind" gate (2026-08-21, daily_reviews.md): a 30-day
    # empirical check found the ensemble actually fires MORE often during a
    # real intraday grind (75% vs 49% fire rate at 20-min checkpoints) and
    # is LESS accurate when it does (46.2% vs 56.8% vs +30min) -- the
    # mechanism is that several voters normalize by ATR/realized range, so
    # a near-zero denominator during a genuine low-vol coil inflates their
    # confidence instead of reducing it. This only ever downgrades an
    # existing CALL/PUT to NONE -- it never invents a new call, never
    # changes direction/confidence/votes (record_outcome() and the
    # scenario/weight learning below are untouched), and is a no-op
    # whenever intraday_df isn't supplied (every daily-only backtest call,
    # so the validated 3-year backtest numbers are unaffected by this).
    if inputs.intraday_df is not None and result.signal in ("CALL", "PUT"):
        grinding = is_grinding_now(inputs.intraday_df, inputs.intraday_df.index[-1])
        if grinding:
            result = replace(result, signal="NONE", grind_suppressed=True)

    return result
