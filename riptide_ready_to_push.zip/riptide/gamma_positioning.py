"""
Dealer gamma positioning: GEX, zero-gamma flip level, and max pain.

Why this matters for 1DTE: options market makers hedge their book to stay
delta-neutral. When dealers are net LONG gamma (positive GEX), they buy
dips and sell rallies to rehedge -- this dampens moves and pins price near
high-open-interest strikes. When dealers are net SHORT gamma (negative
GEX), they do the opposite -- sell into weakness and buy into strength --
which amplifies trends. Since 0DTE/1DTE volume now dominates SPX/SPY
options flow, this is one of the more mechanistic explanations available
for why some days chop sideways and others trend hard.

IMPORTANT DATA LIMITATION: this module needs a live options chain (open
interest + implied vol per strike). Free sources like yfinance only expose
the CURRENT chain, not historical snapshots -- so this module powers a
live "what's the signal right now" reading, but cannot be honestly
backtested over history without a paid options database (Polygon.io,
CBOE DataShop, ORATS, etc). See README.md.

Formula (per strike, per option):
    GEX_contribution = gamma * open_interest * contract_size * spot^2 * 0.01
    calls contribute positively, puts negatively (standard dealer-short-
    puts-long-calls convention used by SpotGamma/Perfiliev and similar
    write-ups)
"""

from dataclasses import dataclass, field

import numpy as np
import pandas as pd
from scipy.stats import norm

CONTRACT_SIZE = 100


def _d1_d2(S, K, T, r, sigma):
    T = np.maximum(T, 1e-6)
    sigma = np.maximum(sigma, 1e-4)
    d1 = (np.log(S / K) + (r + 0.5 * sigma ** 2) * T) / (sigma * np.sqrt(T))
    d2 = d1 - sigma * np.sqrt(T)
    return d1, d2


def bs_gamma(S, K, T, r, sigma):
    """Black-Scholes gamma (same for calls and puts)."""
    d1, _ = _d1_d2(S, K, T, r, sigma)
    T = np.maximum(T, 1e-6)
    sigma = np.maximum(sigma, 1e-4)
    return norm.pdf(d1) / (S * sigma * np.sqrt(T))


@dataclass
class ChainSnapshot:
    """Normalized options-chain snapshot for one or more expirations.

    Build this from yfinance's `Ticker(ticker).option_chain(exp)` calls
    dfs (see `fetch_chain_yfinance`), or from any other data source that
    can populate these columns.
    """
    strike: np.ndarray
    call_oi: np.ndarray
    put_oi: np.ndarray
    call_iv: np.ndarray
    put_iv: np.ndarray
    call_volume: np.ndarray
    put_volume: np.ndarray
    time_to_expiry_years: float  # same for all rows in a single-expiration snapshot
    spot: float


def fetch_chain_yfinance(ticker: str = "SPY", expiration: str = None) -> ChainSnapshot:
    """Pull the nearest (or specified) expiration's option chain via
    yfinance. Requires internet access and `pip install yfinance`."""
    import yfinance as yf

    tk = yf.Ticker(ticker)
    if expiration is None:
        expiration = tk.options[0]  # nearest expiration -- ideal for 0DTE/1DTE reads

    chain = tk.option_chain(expiration)
    calls, puts = chain.calls, chain.puts

    spot = tk.fast_info.get("lastPrice") or tk.history(period="1d")["Close"].iloc[-1]

    merged = pd.merge(
        calls[["strike", "openInterest", "impliedVolatility", "volume"]],
        puts[["strike", "openInterest", "impliedVolatility", "volume"]],
        on="strike", how="outer", suffixes=("_call", "_put"),
    ).fillna(0).sort_values("strike")

    from datetime import datetime
    exp_dt = datetime.strptime(expiration, "%Y-%m-%d")
    years = max((exp_dt - datetime.now()).total_seconds(), 60) / (365 * 24 * 3600)

    return ChainSnapshot(
        strike=merged["strike"].to_numpy(dtype=float),
        call_oi=merged["openInterest_call"].to_numpy(dtype=float),
        put_oi=merged["openInterest_put"].to_numpy(dtype=float),
        call_iv=merged["impliedVolatility_call"].to_numpy(dtype=float),
        put_iv=merged["impliedVolatility_put"].to_numpy(dtype=float),
        call_volume=merged["volume_call"].to_numpy(dtype=float),
        put_volume=merged["volume_put"].to_numpy(dtype=float),
        time_to_expiry_years=years,
        spot=float(spot),
    )


@dataclass
class GammaProfile:
    total_gex: float               # $ gamma exposure per 1% move, calls-positive/puts-negative convention
    zero_gamma_flip: float         # spot level where net GEX crosses zero
    max_pain_strike: float
    spot: float
    regime: str                    # "positive" (mean-reverting/pinning) or "negative" (trend-amplifying)
    distance_to_flip_pct: float    # (spot - flip) / spot, signed
    strike_gex: pd.DataFrame = field(repr=False)  # per-strike GEX table for inspection/plotting


def _gex_at_spot(chain: ChainSnapshot, spot_level: float, r: float = 0.05) -> np.ndarray:
    call_g = bs_gamma(spot_level, chain.strike, chain.time_to_expiry_years, r, chain.call_iv)
    put_g = bs_gamma(spot_level, chain.strike, chain.time_to_expiry_years, r, chain.put_iv)
    call_gex = call_g * chain.call_oi * CONTRACT_SIZE * spot_level ** 2 * 0.01
    put_gex = -put_g * chain.put_oi * CONTRACT_SIZE * spot_level ** 2 * 0.01
    return call_gex + put_gex


def compute_gamma_profile(chain: ChainSnapshot, r: float = 0.05,
                           flip_search_pct: float = 0.10, flip_steps: int = 121) -> GammaProfile:
    """Computes total GEX at current spot, the zero-gamma flip level (by
    scanning a grid of spot levels and finding the sign change), and max
    pain (the strike that minimizes total option holder payoff, i.e.
    maximizes option writer/dealer payoff)."""

    per_strike_gex = _gex_at_spot(chain, chain.spot, r)
    total_gex = float(np.nansum(per_strike_gex))

    strike_gex = pd.DataFrame({"strike": chain.strike, "gex": per_strike_gex}).sort_values("strike")

    # Scan spot levels to find where total net GEX crosses zero
    grid = np.linspace(chain.spot * (1 - flip_search_pct), chain.spot * (1 + flip_search_pct), flip_steps)
    net_gex_grid = np.array([np.nansum(_gex_at_spot(chain, s, r)) for s in grid])
    sign_changes = np.where(np.diff(np.sign(net_gex_grid)) != 0)[0]
    if len(sign_changes):
        i = sign_changes[np.argmin(np.abs(grid[sign_changes] - chain.spot))]
        # linear interpolation between grid[i] and grid[i+1]
        x0, x1 = grid[i], grid[i + 1]
        y0, y1 = net_gex_grid[i], net_gex_grid[i + 1]
        flip = x0 - y0 * (x1 - x0) / (y1 - y0) if (y1 - y0) != 0 else x0
    else:
        # no sign change found in the search window -- regime is uniformly
        # one sign nearby; fall back to spot as a neutral placeholder
        flip = float(chain.spot)

    max_pain = _max_pain_strike(chain)

    regime = "positive" if total_gex >= 0 else "negative"
    distance_to_flip_pct = (chain.spot - flip) / chain.spot

    return GammaProfile(
        total_gex=total_gex,
        zero_gamma_flip=float(flip),
        max_pain_strike=max_pain,
        spot=chain.spot,
        regime=regime,
        distance_to_flip_pct=float(distance_to_flip_pct),
        strike_gex=strike_gex,
    )


def _max_pain_strike(chain: ChainSnapshot) -> float:
    """Strike at which total option-holder payoff (across all listed
    strikes) is minimized -- the classic 'max pain' level."""
    strikes = chain.strike
    payoff_at_settle = np.zeros_like(strikes, dtype=float)

    for i, settle in enumerate(strikes):
        call_intrinsic = np.maximum(settle - strikes, 0) * chain.call_oi
        put_intrinsic = np.maximum(strikes - settle, 0) * chain.put_oi
        payoff_at_settle[i] = np.nansum(call_intrinsic) + np.nansum(put_intrinsic)

    return float(strikes[np.argmin(payoff_at_settle)])


def pin_score(profile: GammaProfile, atr: float, hours_to_close: float) -> float:
    """A 0-100 heuristic score for how likely price is to gravitate toward
    max pain / the zero-gamma flip rather than trend away from it. Higher
    when: regime is positive gamma, spot is close (in ATR terms) to max
    pain, and there's little time left in the session (0DTE-style pin risk
    intensifies late in the day since gamma ~ 1/sqrt(T))."""
    if profile.regime != "positive":
        return 0.0

    atr = max(atr, 1e-6)
    distance_in_atr = abs(profile.spot - profile.max_pain_strike) / atr
    proximity_score = max(0.0, 1 - distance_in_atr / 3)  # 0 at 3+ ATR away, 1 at spot==max pain

    time_score = max(0.0, 1 - hours_to_close / 6.5)  # ramps up through the trading day

    return float(100 * (0.6 * proximity_score + 0.4 * time_score))
