"""Filter one day's raw Greek_YYYYMMDD_OData{1,2}.csv down to SPY-only rows
with just the columns historical_chain.py needs. Waits for the staged file
to exist and its size to stop changing before reading, since device-bridge
staging can report dispatched=true slightly before the file is fully
written."""
import os
import sys
import time
import pandas as pd

USE_COLUMNS = ["Symbol", "ExpirationDate", "PutCall", "StrikePrice",
               "Volume", "OpenInterest", "UnderlyingPrice", "ImpliedVolatility", "DataDate"]

src, dst = sys.argv[1], sys.argv[2]

last_size = -1
for _ in range(30):
    if os.path.exists(src):
        size = os.path.getsize(src)
        if size == last_size and size > 0:
            break
        last_size = size
    time.sleep(1)
else:
    print(f"WARNING: {src} never stabilized, proceeding anyway")

df = pd.read_csv(src, usecols=USE_COLUMNS)
match = df[df["Symbol"] == "SPY"]
match.to_csv(dst, index=False)
print(f"{src} -> {dst}: {len(match)} SPY rows (of {len(df)} total)")
