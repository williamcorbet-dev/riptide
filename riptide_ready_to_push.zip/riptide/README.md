# SPY 1DTE Call/Put Indicator -- Ensemble Edition

A composite technical + options-positioning + statistical ensemble that
outputs `CALL`, `PUT`, or `NONE` for 1-day-to-expiration (1DTE) SPY option
entries. Instead of one hand-tuned formula, this runs many independent
"voters" -- each a distinct methodology -- and combines them through a
scenario-fingerprinting engine that's designed to get smarter as real
outcomes accumulate.

**This is a research/engineering tool, not investment advice.** Read
"Important limitations and risks" at the bottom before using it with real
money. 0/1DTE options can lose their entire value in hours.

## Honest framing, up front

I can't tell you this system has a real edge -- that's an empirical
question nobody can answer without real out-of-sample data and disciplined
walk-forward testing, and I'd be doing you a disservice pretending
otherwise. What I *can* do is build the most rigorous hypothesis-generation
and self-correction machine I know how to, so that when your data
subscriptions come online, you're testing something real instead of a
story that only looks good in hindsight. The scenario engine is built to
say "I don't have enough history on this exact setup yet" rather than
fake confidence -- lean on that signal.

## Architecture: a council of voters, not a formula

Every methodology below produces a **Vote**: a direction (-1..+1), a
confidence (0..1), and a regime label (see `voters.py`). No single voter
decides the trade. All votes get combined by `scenario_engine.py`:

1. **Scenario fingerprint.** The current regime label from every voter
   (gamma positive/negative, Hurst trending/reverting, HMM calm/stressed,
   candlestick reversal/none, VIX term structure calm/stress, FOMC
   calendar state, etc.) is combined into one fingerprint string --
   effectively "what combination of conditions is true right now."
2. **Empirical lookup, when there's enough history.** If a fingerprint has
   been seen `MIN_SCENARIO_SAMPLES` (default 20) times before, the
   system uses the *actual observed win rate* for that exact scenario
   instead of a formula -- this is the "look for a trend in the
   responses" part.
3. **Adaptive weighted vote as fallback.** Early on, most fingerprints
   won't have enough history (the combinatorial space is large), so it
   falls back to a confidence-weighted vote across all voters. The
   per-voter weights are not fixed -- they update via a Hedge-style
   multiplicative-weights rule every time you call `record_outcome()`,
   so voters that are actually right more often earn more influence over
   time, and voters that are noise get downweighted.
4. **Persistent learning.** Both the scenario table and the voter weights
   are saved to `state/scenario_history.json` and `state/voter_weights.json`.
   Every live run or backtest that calls `record_outcome()` teaches the
   system something that the next run inherits. Delete the `state/`
   folder to reset to a blank slate.

## The voters

| Voter | File | What it measures | Backtestable for free? |
|---|---|---|---|
| Technical composite | `indicator.py` | Trend (EMA), momentum (MACD/RSI), VWAP location, volume confirmation, ATR volatility gate | Yes (daily history) |
| Gamma regime | `gamma_positioning.py` | Dealer GEX, zero-gamma flip level, max pain -- decides mean-reversion vs trend-following MODE; technical score supplies direction | **No** -- needs live chain |
| Vanna/charm | `vanna_charm.py` | Second-order dealer hedging flows from IV changes and time decay, strongest near expiration | **No** -- needs live chain |
| Put/call ratio | `vol_regime.py` | Contrarian sentiment from live chain volume | **No** -- needs live chain |
| VIX term structure | `vol_regime.py` | VIX vs VIX3M contango/backwardation -- dampens ensemble confidence in backwardation rather than voting a direction | Yes (`^VIX`/`^VIX3M` history) |
| HMM regime | `regime_hmm.py` | 2-state Gaussian Hidden Markov Model (from-scratch Baum-Welch/EM, no `hmmlearn` dependency) -- statistical calm/stressed read | Yes (daily history) |
| Hurst exponent | `hurst.py` | Rescaled-range fractal analysis -- trending/mean-reverting/random-walk, independent of the HMM's statistical method | Yes (daily history) |
| FOMC calendar | `calendar_overlay.py` | Pre-FOMC drift anomaly (Lucca & Moench, NY Fed), modest nudge only | Yes (public meeting dates) |
| Multi-timeframe candlesticks | `candlestick_patterns.py` | Hand-rolled pattern detection (no TA-Lib) across 3m-1D, timeframe-weighted confluence, bonus when a pattern coincides with a gamma-significant level | Only over yfinance's ~60-day intraday window, or a `webull_data.py` CSV export |
| Time-of-day fingerprint | `time_of_day_fingerprint.py` | Self-calibrating baseline of typical intraday behavior per time-of-day bucket; scores today as a z-score anomaly against its own history | Only over yfinance's ~60-day intraday window, or a `webull_data.py` CSV export |
| Cross-asset lead-lag | `cross_asset_leadlag.py` | Empirically measures, per candidate leader (QQQ, AAPL, MSFT, NVDA, TLT, UUP by default), how correlated that leader's return has actually been with SPY's *next* return -- only leaders that clear a real historical correlation bar get a vote, weighted by how strong that correlation has been | Yes (daily history) |
| 25-delta skew dynamics | `skew_dynamics.py` | Tracks whether the live 25-delta put/call IV skew is steepening (bearish) or flattening (bullish) against its own trailing history, not the absolute skew level (which is chronically positive and not informative on its own) | **No** -- needs live chain, and needs its own accumulated history (`state/skew_history.json`) before it can vote at all |
| Dynamic support/resistance | `support_resistance.py` | Recomputes today's swing-point support/resistance levels fresh from live intraday price action on every call (no hardcoded levels), seeded with prior-day High/Low/Close for lag-free reference points, and votes bounce (rejected) vs. breakout (continuing) when price revisits a level | Yes -- intraday OHLCV only (a `webull_data.py` CSV export or yfinance's ~60-day window), no live chain needed |

When gamma regime says **negative** (dealers short gamma -> trend-
amplifying), it votes the technical score's direction directly. When it
says **positive** (dealers long gamma -> mean-reverting/pinning), it fades
extension back toward max pain, blended 70/30 with the technical score.
Candlestick patterns get a confidence bonus when they print within 1.5 ATR
of the max-pain strike or zero-gamma flip level -- the idea that a
reversal pattern at a mechanistically significant level means more than
the same pattern in open space.

## Position sizing and exit rules (`risk_management.py`)

Every voter above answers "which direction, how confident" -- none of them
answer "how many contracts" or "when do I get out." `risk_management.py`
is that separate layer, applied *after* `composite_signal.generate_signal()`
returns a signal, not folded into the vote itself:

- **Sizing** (`size_position()`): risk at most `max_risk_per_trade_pct` of
  account equity per trade (1% by default), scaled down for lower-
  confidence signals (down to a `min_size_multiplier` floor), and scaled
  down again by `unvalidated_track_record_discount` while the scenario
  engine is still in `weighted_ensemble` fallback mode rather than the
  empirical-lookup mode -- i.e. trust a setup less until it has an actual
  track record, not just a plausible design.
- **Exit plan** (`build_exit_plan()`): stop-loss and profit-target
  expressed as a **percentage of premium** (not underlying price, since
  1DTE options can reprice discontinuously), a trailing stop that
  activates once you're up 75% and gives back at most 35% of the peak
  gain, and a hard time-based exit in the final 15 minutes before close --
  1DTE theta decay accelerates sharply in the last hour, so "let it ride"
  is a much worse default than on a multi-day position.
- **Daily circuit breaker** (`DailyRiskTracker`): stops sizing *new*
  entries once realized losses for the session cross `daily_loss_limit_pct`
  (3% by default) -- a standard guardrail against revenge-trading into a
  bad day. Intended for live use across multiple signals in the same
  session; wire `record_trade_result()` in after each closed trade.

`live_signal.py` calls this automatically and prints the sizing/exit plan
alongside the signal breakdown. `backtest.py --ensemble --account-size N`
also sizes each historical trade this way and reports risk-sized dollar
P&L -- but note it can only size the *entry*, since the daily-bar backtest
has no intraday path to check whether the stop-loss/trailing-stop would
have triggered mid-trade.

## Real intraday data via Webull CSV export (`webull_data.py`)

The candlestick and time-of-day voters need real intraday history to be
worth anything, and free sources like `yfinance` only retain ~60 days of
it. `webull_data.py` reads a CSV you export manually from Webull's own
app (`load_webull_intraday_csv()`, `derive_daily_from_intraday()`,
`split_latest_day()`) -- deliberately a **file export, not a live API
integration**: building a live Webull API adapter would mean handling a
real account API key/secret, and that's not something this project (or
Claude, if you're reading this from that conversation) will do even when
offered directly -- credentials pasted into a chat or read from a file are
still credentials being handled. A manual CSV export sidesteps that
entirely while still getting real data in.

`data/SPY_Webull_1min_20260706_to_20260814.csv` is a real example export
(1-minute SPY bars, RTH only, 30 trading days) checked into this project --
see `data/README.md`. Pass it to `live_signal.py` via
`--webull-intraday-csv` to see it in action. 30 days of intraday history
is enough for the candlestick/time-of-day voters (self-calibrated against
their own recent history) but not remotely enough daily history for
Hurst/HMM -- see "What I could and couldn't verify" below for what that
first real-data run actually looked like.

## Inspecting a specific day: `intraday_replay.py`

For digging into "what was the system actually saying at 10am vs. 2pm on
this particular day, and does that line up with what price did" --
`intraday_replay.py` re-runs `generate_signal()` at checkpoints across one
real trading day from a Webull intraday export, honestly point-in-time at
each checkpoint (only bars up to that moment are visible -- no
look-ahead), and writes out what you need to actually compare:

```bash
python intraday_replay.py --webull-csv data/SPY_Webull_1min_20260706_to_20260814.csv \
    --date 2026-08-14 --interval 30
```

This writes `<date>_replay.csv` (one row per checkpoint: price, signal,
direction, confidence, method, and the price 30 minutes later plus the
day's eventual close, for hindsight comparison -- those forward-looking
columns are never fed back into the signal itself), `<date>_replay_
votes.csv` (one row per checkpoint *per voter*, for seeing exactly which
voters drove each reading), and a PNG chart of that day's price with
CALL/PUT/NONE markers sized by confidence.

Worth knowing when reading the output: `technical`, `hurst`, `hmm_regime`,
`fomc_calendar`, and `gamma_regime` are all driven by *daily* data (or a
live chain), so they read identically at every checkpoint within the same
day -- only `candlesticks`, `time_of_day`, and `support_resistance`
actually update bar-to-bar, since those are the three voters built on real
intraday data. That's not a bug, it's just what "daily vs. intraday" means
for this ensemble -- worth knowing before concluding a voter "isn't doing
anything" on a given day.
It uses fresh, throwaway state per run (same as the test suite) so it
never touches or pollutes `state/`, the persistent store `live_signal.py`
and `backtest.py` actually learn from -- run it as many times as you like.

### Case study: 2026-08-14 -- why didn't a signal fire at the double top / support bounce?

Walking `data/SPY_Webull_1min_20260706_to_20260814.csv` through
`intraday_replay.py` at 15-minute intervals surfaced a real dilution
problem worth documenting rather than hiding. At 10:15 that day price
rejected a ~778.6 double-top level (the prior day's close/high clustered
with a same-day swing high); at 13:45 it was chopping around a ~775.8-775.9
support zone built from the prior day's low plus repeated same-day
touches. `support_resistance` correctly caught both:

| Time | `support_resistance` | `candlestick` | `technical` (daily, frozen all day) | Final ensemble |
|---|---|---|---|---|
| 10:15 | `bounce_resistance`, dir -0.775, conf 0.725 | `reversal`, dir -0.792, conf 0.50 | dir +0.617, conf **1.00** | dir -0.151, **NONE** |
| 13:45 | `bounce_resistance`, dir -0.900, conf 0.850 | `reversal`, dir -0.237, conf 0.40 | dir +0.617, conf **1.00** | dir -0.142, **NONE** |

Three independent intraday reads (support/resistance, candlesticks, and a
weak time-of-day lean) all agreed bearish at both moments -- and the
signal still came out `NONE`. The reason is arithmetic, not a bug in the
new voter: `weighted_ensemble` (the fallback used whenever a scenario
fingerprint hasn't been seen `MIN_SCENARIO_SAMPLES` times yet, which is
every fingerprint until real outcomes accumulate) weights every voter by
`adaptive_weight x confidence`, and on a fresh `state/` every adaptive
weight starts at 1.0. `technical` is a *daily* read that stays fixed all
session, and on this day it sat at confidence 1.00 -- alone worth as much
weight as the other three intraday voters' confidences summed. It doesn't
just get outvoted, it structurally can't be outvoted by intraday action
alone until either (a) intraday conviction is even more overwhelming, or
(b) `AdaptiveWeights` has actually learned (from recorded real outcomes)
that `technical` deserves less trust than a strong live
`support_resistance` read intraday. That learning is exactly what
"running it a while on live data" (via `record_outcome()`, see below)
is for -- it's the designed fix, not a gap to patch by hand-tuning a
starting weight.

## Calibration workflow: alert wide, review, tighten (`daily_review.py`)

Since `AdaptiveWeights` only learns from alerts that actually fired, an
early calibration period benefits from firing MORE often than the live
default -- otherwise there's little to learn from. `generate_signal()`,
`live_signal.py`, and `intraday_replay.py` all now accept
`--signal-threshold` (default `scenario_engine.SIGNAL_THRESHOLD`, 0.35) so
you can deliberately widen the net:

```bash
# live use, alerting more often during calibration:
python live_signal.py --ticker SPY --signal-threshold 0.20

# or replay a past day at a widened threshold to see what WOULD have fired:
python intraday_replay.py --webull-csv data/SPY_..._1min....csv --date 2026-08-14 --signal-threshold 0.20
```

Widening the threshold doesn't touch any voter's internal math -- it only
changes how large the final blended direction needs to be to become a
CALL/PUT instead of NONE, so it's purely "alert on more borderline
readings," not "make the readings themselves less careful."

At the end of a day (or a backfilled real day), `daily_review.py` grades
every alert that fired at your chosen threshold against what price
actually did -- by day close (`correct_by_close`) and, separately, over
just the next 30 minutes (`correct_by_30m`, since those two horizons can
disagree) -- and breaks the wrong ones down by which voters were driving
them:

```bash
python daily_review.py --webull-csv data/SPY_Webull_1min_20260706_to_20260814.csv \
    --date 2026-08-14 --interval 15 --signal-threshold 0.15
```

This prints a win rate, lists every wrong alert, and a per-voter
reliability table with two columns worth reading closely:
`agreed_and_wrong` (this voter agreed with a fired signal that turned out
wrong -- high counts here are candidates to trust less) and
`disagreed_but_signal_wrong` (this voter disagreed and would have been
right -- high counts here mean it's being outvoted when it shouldn't be,
the same dilution pattern from the Aug 14 case study above). Running this
against the real Aug 14 data at `--signal-threshold 0.15` surfaced exactly
that: `time_of_day` disagreed with 6 fired signals and was right on 5 of
them -- direct, concrete evidence for where the ensemble's weighting is
currently miscalibrated, rather than a guess.

Nothing here is automatic. `daily_review.py` only reports; deciding to
tighten `--signal-threshold` back down, or to eventually adjust how much
weight a chronically-outvoted-but-often-right voter gets, is still a
judgment call to make after looking at enough days -- ideally alongside
real recorded outcomes via `record_outcome()`, not a single day's replay.
It writes `<prefix>_review.csv` (the graded replay), `<prefix>_review_
votes.csv`, `<prefix>_review_breakdown.csv` (per-alert-per-voter detail),
and `<prefix>_review_reliability.csv` (the summary table) -- and, like
`intraday_replay.py`, uses fresh throwaway state so running it never
touches `state/`.

## Setup

```bash
pip install -r requirements.txt
```

No exotic dependencies: everything (including the HMM and every
candlestick pattern) is hand-implemented on top of pandas/numpy/scipy, so
there's nothing finicky like TA-Lib or hmmlearn to fight with. `yfinance`
needs outbound internet access.

## Quick start

```bash
# Full live ensemble signal (includes the live-only voters), sized and
# given an exit plan via risk_management.py
python live_signal.py --ticker SPY --account-size 25000

# Same, but with real intraday data feeding the candlestick and time-of-day
# voters instead of them sitting out (see webull_data.py and data/README.md)
python live_signal.py --ticker SPY --account-size 25000 \
    --webull-intraday-csv data/SPY_Webull_1min_20260706_to_20260814.csv

# Backtest -- technical score only (original v1 behavior)
python backtest.py --source yfinance --ticker SPY --period 3y --plot

# Backtest -- full backtestable ensemble (technical + Hurst + HMM + FOMC
# + VIX term structure + cross-asset lead-lag)
python backtest.py --source yfinance --ticker SPY --period 3y --ensemble --refit-every 5

# Same, but also size each trade via risk_management.py and report $ P&L
python backtest.py --source yfinance --ticker SPY --period 3y --ensemble --account-size 25000

# Run the test suite (stdlib unittest, no install needed -- pytest-compatible too)
for f in tests/test_*.py; do python3 "$f"; done
```

`--refit-every N` (ensemble backtest only): the HMM and Hurst estimators
are refit from scratch on every evaluated day, which isn't cheap. Default
evaluates every 5th trading day to keep multi-year backtests fast; set to
1 for an exhaustive day-by-day backtest once you're not iterating on the
code anymore.

`--no-leadlag` (ensemble backtest only): skip fetching the six default
leader tickers' history if you want a faster/lighter run or don't have
data access for them.

## What's live-only vs. backtestable, and why

`gamma_positioning.py`, `vanna_charm.py`, the put/call-ratio part of
`vol_regime.py`, and `skew_dynamics.py` all need a **live options chain**
(strikes, open interest, implied vol). Free sources like `yfinance` only
expose the *current* chain, not historical snapshots -- there's no way to
reconstruct "what did SPY's options chain look like on March 4, 2023"
without a paid historical options database (Polygon.io, CBOE DataShop,
ORATS, and similar are the usual choices). So:

- `live_signal.py` can use every voter, right now, for today's read.
- `backtest.py --ensemble` uses only the voters that don't need a live
  chain: technical, Hurst, HMM, FOMC calendar, VIX term structure, and
  cross-asset lead-lag (all daily-OHLCV-only, so all fully backtestable
  for free over multi-year history).
- The multi-timeframe candlestick and time-of-day fingerprint voters sit
  in between: they're backtestable, but only over whatever intraday
  history your data source retains (roughly 60 days for free `yfinance`
  intraday bars), not multi-year history the way daily bars allow.
- `skew_dynamics.py` has an extra wrinkle even once you have a live chain:
  it needs its *own* accumulated daily history (`state/skew_history.json`)
  before it can say anything, since skew steepening/flattening is scored
  against the instrument's own trailing skew, not an absolute level. It
  will honestly report "not enough history yet" until then -- that's
  expected, not a bug.

**Update: a paid historical-chain data source is now wired in** -- see
`historical_chain.py` below. It doesn't erase the distinction above (a
day still needs an actual purchased snapshot to unlock these voters, and
each snapshot is one end-of-day read, not intraday), but it means
`simulate_ensemble_trades()` in `backtest.py` and `intraday_replay.py`
can now include the gamma/vanna-charm/PCR/skew voters for real, on any
day you have a chain file for, instead of that being purely a future
Phase-2 item.

## Historical options chains: `historical_chain.py`

The gap described just above -- no free source of historical options
chains -- is now partially closed. `historical_chain.py` reads a paid
vendor's end-of-day export (one CSV pair per trading day,
`Greek_YYYYMMDD_OData1.csv` / `Greek_YYYYMMDD_OData2.csv`, each covering
roughly half that day's ~5,600-ticker optionable universe with real
Greeks already computed -- IV, Delta, Gamma, Vega, Rho, Theta per
contract) and turns it into the exact same `ChainSnapshot` shape
`fetch_chain_yfinance()` produces. Every chain-dependent voter runs
against it unmodified.

```python
from historical_chain import load_symbol_from_greek_csvs, nearest_expiration_chain_snapshot

spy_day = load_symbol_from_greek_csvs(
    ["Greek_20260814_OData1.csv", "Greek_20260814_OData2.csv"], "SPY")
chain = nearest_expiration_chain_snapshot(spy_day, min_days_out=0)  # the 0DTE/1DTE contract
```

Or, for a whole folder of days at once (`build_chain_lookup_from_dir()`
groups by the date in the filename and skips -- with a printed warning,
not a crash -- any day it can't build a snapshot for):

```bash
python backtest.py --ensemble --chain-dir path/to/greek_csvs --account-size 25000
python intraday_replay.py --webull-csv data/SPY_..._1min....csv --date 2026-08-14 --chain-dir path/to/greek_csvs
python daily_review.py --webull-csv data/SPY_..._1min....csv --date 2026-08-14 --chain-dir path/to/greek_csvs
```

Two honest limits worth knowing: each snapshot is a single end-of-day
read, so in `intraday_replay.py`/`daily_review.py` the same chain is
reused at every checkpoint across the day (there's no intraday chain
movement in this data) -- gamma/vanna-charm/PCR/skew answer "what did the
chain look like as of end of day," not "what did it look like at 10:15am
specifically." And which OData file a given symbol lands in isn't
alphabetical or otherwise predictable (confirmed against a real sample
day), so `load_symbol_from_greek_csvs()` always checks every file handed
to it rather than assuming a split.

Validated against a real day already on hand (2022-03-01, a sample from
the same vendor): SPY had 9,576 option rows that day; the resulting
chain snapshot fed into `compute_gamma_profile()` and
`compute_vanna_charm()` produced a real GEX reading (-$760.9M, negative/
trend-amplifying regime), a real zero-gamma flip level, and real vanna/
charm output -- all computed from purchased data, not synthetic, for the
first time in this project.

### Case study: a real bug this data exposed (`vanna_charm`'s confidence formula)

Plugging real 2026-08-14 chain data into the full ensemble (via
`intraday_replay.py --chain-dir`) surfaced a genuine bug in
`vanna_charm_vote()`, not just new coverage. Before this data existed,
`vanna_charm` had never been run with realistically-scaled exposure
numbers -- its "confidence" fallback for when no rolling history is
available was `abs(combined) / max(abs(combined), 1.0)`, commented as "a
crude fallback, weak signal." Algebraically that ratio is `min(abs(
combined), 1.0)` -- and since real OI-weighted vanna+charm exposure is
always in the hundreds of thousands to hundreds of millions of dollars
(confirmed: **$106,654,807** combined on 2026-08-14, spot $776.34), it was
mathematically impossible for that ratio to land anywhere except exactly
`1.0`. The "weak fallback" was silently maxing out confidence on every
real call it had ever made, live runs included -- just never caught,
because nothing had exercised it with real-magnitude numbers before.

The effect on that day's signal was concrete: with the bug, `vanna_charm`
voted a saturated `direction=+1.000` at confidence 0.75-0.99 at both
10:15 and 13:45, strong enough to flip the ensemble's net reading from
bearish to roughly neutral/slightly bullish at those checkpoints
(direction moved from -0.151 to +0.064 at 10:15, for example) --
overriding three other voters that all agreed bearish, on the strength of
a confidence number that couldn't have been anything other than 1.0
regardless of what the actual exposure was.

Fixed properly rather than patched around: `vanna_charm_vote()` now
requires a real trailing-history baseline to judge "is today's exposure
unusually large" against -- `VannaCharmHistoryStore`, the same
self-calibrating pattern `skew_dynamics.py` already uses. Wired into
`live_signal.py`, `backtest.py` (a real, persistent store so a long
`--chain-dir` backtest earns genuine confidence once it's walked past
~20 days with a chain), and `intraday_replay.py`/`daily_review.py` (a
fresh per-run store, matching how those tools already avoid touching
real state). With no history yet -- true for this project today, since
2026-08-14 is the only real chain day on hand -- `vanna_charm` now
honestly reports 0 confidence instead of guessing, and the 10:15/13:45
ensemble reads landed back at -0.166 and -0.114 respectively: close to
(not identical to -- `gamma_regime` is now real too, and gives
`candlesticks` a small confidence bonus for printing near a real
gamma-significant level) the pre-chain-data reads, rather than the
bug's false-bullish -0.166→+0.064 flip.

The lesson worth stating plainly: this bug could only be found by
running real data through the system. It's exactly why "let it run a
while on real data" (this README's refrain since the first case study)
matters even for code that already has passing unit tests -- the tests
used synthetic exposure magnitudes that happened not to be enormous
enough to reveal that the fallback ratio was structurally broken.

### A second bug this surfaced: `intraday_replay.py` silently writing to real `state/`

Wiring `--chain-dir` into `intraday_replay.py`/`daily_review.py` gave
`vanna_charm` a throwaway `VannaCharmHistoryStore` so repeated replays
never pollute real state (same principle these tools already applied to
the scenario store and adaptive weights) -- but `skew_dynamics` was
missed. `skew_vote()` defaults to a REAL persistent
`state/skew_history.json` whenever no store is explicitly passed, so any
chain-driven replay was silently writing real entries into it, directly
contradicting these tools' documented "never touches `state/`, run it as
many times as you like" guarantee. Fixed the same way: a throwaway
`SkewHistoryStore` per replay run.

While fixing it, a related, independent issue turned up: `skew_vote()`
had no way to record a reading under a SIMULATED day at all -- it always
stamped `date.today()` (the real wall-clock date), regardless of which
historical day `backtest.py` was actually walking through. For a
multi-day `--chain-dir` backtest, that would mean every day's skew
reading overwrites the same "today" entry instead of accumulating one
entry per simulated day -- `skew_dynamics` would never be able to reach
its own `min_history` threshold no matter how many chain-days were fed
in. Fixed by threading an `as_of` parameter through `skew_vote()` (mirroring
how `vanna_charm_vote()` already takes one) down to `compute_skew()`,
which already supported it but was never being passed it. `backtest.py`
now passes the walk's simulated day explicitly.

Both fixes are covered by regression tests, including one that runs a
chain-driven replay and asserts the real `state/` directory's contents
are byte-for-byte unchanged afterward -- the kind of test that would have
caught this the first time.

### Scaling up: 46 real chain days, and warming up real history (`warm_up_history.py`)

2026-08-14 was one day. The vendor export purchase also covers full
months, so two of them -- July 2025 and July 2026 (23 trading days each,
46 total) -- were extracted and staged. Each raw day is a ~140-150MB CSV
pair (~5,600 tickers), so a small utility, `filter_spy_day.py`, strips
each pair down to just the SPY rows (`Symbol`/`ExpirationDate`/`PutCall`/
`StrikePrice`/`Volume`/`OpenInterest`/`UnderlyingPrice`/
`ImpliedVolatility`/`DataDate` -- exactly `historical_chain.py`'s
`USE_COLUMNS`) immediately after staging, then deletes the raw pair
before moving to the next day. 46 days of raw vendor exports (~13GB) came
down to **28MB** of filtered `Greek_YYYYMMDD_OData*.csv` files in
`data/chains_bulk/`, in the exact same filename format
`build_chain_lookup_from_dir()` already expects -- no changes needed to
`historical_chain.py` itself. (As before: for every one of these 46 days,
SPY landed 100% in `OData2` and 0% in `OData1` -- consistent so far, but
still not something the loader assumes, since one real sample day isn't
enough days to call it a rule.)

`vanna_charm_vote()` and `skew_vote()` only need a chain snapshot plus a
calendar date to record a reading -- no price/OHLCV series at all -- so
`warm_up_history.py` walks all 46 days in chronological order, builds
each day's real chain via `build_chain_lookup_from_dir(..., min_days_out=1)`,
and calls both voting functions against the REAL persistent stores
(`state/vanna_charm_history.json`, `state/skew_history.json`, not
throwaway ones -- the opposite of `intraday_replay.py`'s isolation, and
deliberately so: the whole point here is to backfill real state). Both
stores started empty; both ended with 46 real entries, and (as expected)
both voters' confidence went from a flat 0.00 to genuinely non-zero
starting at the 21st day (`min_history=20`). (Re-running the 2026-08-14
case study below, using the real stores rather than throwaway ones,
folds that day in as a 47th real entry too, as a natural side effect of
`vanna_charm_vote()`/`skew_vote()` always recording when given a real
store -- a small bonus, since it's the most recent real day on hand and
narrows the calendar gap described just below.)

```
2025-07-29  vanna+charm=  +343,706,993  (vc conf=0.26)   skew=+0.0342  (skew conf=0.02)
2025-07-30  vanna+charm=  +678,854,839  (vc conf=0.52)   skew=-0.2145  (skew conf=1.00)
2025-07-31  vanna+charm=+1,259,528,267  (vc conf=0.93)   skew=+0.0320  (skew conf=0.05)
2026-07-01  vanna+charm=  +801,930,774  (vc conf=0.55)   skew=+0.0585  (skew conf=0.25)
  ...
2026-07-31  vanna+charm=  +132,302,684  (vc conf=0.09)   skew=+0.0347  (skew conf=0.01)
```

**Honest limit:** this is 46 real days, but not 46 *contiguous* calendar
days -- it's two disjoint one-month windows a year apart (2025-07-01..31,
then a gap, then 2026-07-01..31), not a proper trailing window of recent
history. `skew_dynamics`'s z-score is unitless (IV difference) so the gap
matters less there, but `vanna_charm`'s trailing average is raw dollar
notional, which scales with index level and open interest -- SPY was
~$620-637 in July 2025 and ~$730-755 in July 2026, so the "recent
average" this backfill produces is a blend across a year of index growth,
not a true snapshot of current-regime typical exposure. This is still
strictly better than 0 days of history (honest 0-confidence forever), but
it's a bridge, not the real thing -- the gap closes on its own as more
recent days accumulate from live running, or if more recent months get
purchased and backfilled the same way.

**Re-running the 2026-08-14 case study with real history:** with the
stores now warmed up, `vanna_charm` and `skew_dynamics` both cast real
(non-zero-confidence) votes on the original case-study day for the first
time, in place of the earlier 0.00-confidence placeholders:

```
=== 10:15 ===  FINAL: signal=NONE  direction=-0.105  (was -0.166 with 0 history)
    vanna_charm  dir=+1.000  conf=0.057   (was conf=0.000)
    skew_dynamics dir=+0.295  conf=0.304  (was conf=0.000)
=== 13:45 ===  FINAL: signal=NONE  direction=-0.059  (was -0.114 with 0 history)
    vanna_charm  dir=+1.000  conf=0.077
    skew_dynamics dir=+0.291  conf=0.300
```

Worth stating plainly since it cuts against what you might expect: giving
these two voters real confidence made the dilution problem from the
double-top/support-bounce case study (see above) very slightly *worse*,
not better. Both newly-confident voters happen to lean the same direction
as the already-dominant `technical` vote (bullish) on this particular
day, adding to the pile being outvoted against `candlesticks`/
`support_resistance`/`time_of_day`'s agreeing bearish reads, rather than
correcting it. This is exactly the kind of thing the "let it learn on its
own" decision (see above) is supposed to surface honestly rather than
hide -- `AdaptiveWeights` needs realized outcomes to downweight
`technical` if it's genuinely miscalibrated here, and that requires
running forward on real data and grading it (`daily_review.py`), not
guessing from one day's before/after diff.

## How the option-payoff approximation works

Same as before: on each signal day, `backtest.py` buys the ATM option
(nearest $1 strike) using Black-Scholes with an assumed annualized IV
(`--assumed-iv`, default 16%, scaled up 15% via `iv_markup`), holds to the
next trading day's close, and marks it to **intrinsic value only** (i.e.
assumes hold-to-expiration). No bid/ask spread, commissions, or early
exit. Good enough to sanity-check directional edge, not a precise
historical options backtest -- see the table above for what would fix
that.

## What I could and couldn't verify

The sandbox this was built in has no outbound internet, so the bulk of
module-level validation used **synthetic data** designed to exercise the
actual mechanics, backed by an automated test suite (`tests/`, stdlib
`unittest`, no install required -- 155 tests across 16 files, run with
`for f in tests/test_*.py; do python3 "$f"; done`). Two real-data runs
happened later via files provided outside the sandbox: a technical/
ensemble backtest against 5 years of real QQQ daily bars (Nasdaq.com CSV
export, `backtest.py`'s `--source csv` path -- see `load_data()`'s
Nasdaq-format handling), and a full `generate_signal()` run against 30
days of real SPY 1-minute bars (`data/SPY_Webull_1min_20260706_to_
20260814.csv`, see the `webull_data.py` section above). Neither is a
claim of edge -- see below -- but both are the first time real market data
flowed through this system rather than synthetic data alone.

- The Hurst estimator was checked against synthetic persistent, anti-
  persistent (AR(1), various phi), and pure-noise series. Testing actually
  surfaced a real small-sample bias in the raw R/S estimator (white noise
  didn't reliably center on H=0.5, and anti-persistent series weren't
  reliably classified as mean-reverting) -- this was already flagged as a
  known theoretical weakness, but the test suite made it concrete. Fixed
  with an empirical Monte-Carlo bias correction (`hurst_exponent_debiased`
  in `hurst.py`), verified to center white noise near 0.5 and reliably
  classify anti-persistent series across multiple random seeds.
- The HMM was checked against synthetic calm-stressed-calm regime-
  switching returns and correctly identified the regime with >99%
  confidence in each segment.
- The gamma/vanna/charm/max-pain math was run against a synthetic options
  chain and produces internally consistent output (GEX sign flips at a
  sensible flip level, max pain lands at a plausible strike).
- The cross-asset lead-lag detector was checked against a synthetic leader/
  target pair with a genuine lead-lag relationship built in by
  construction (`target[t] = alpha * leader[t-1] + noise`), confirming it
  actually recovers the relationship rather than just avoiding crashes.
- The skew-dynamics z-score was checked against synthetic multi-day skew
  histories with controlled steepening/flattening, including a subtle bug
  the test suite caught: the original version recorded today's reading
  into its own trailing baseline *before* computing the z-score, which
  self-referentially dampened the signal. Fixed to snapshot the baseline
  before recording today's reading (same discipline `time_of_day_
  fingerprint.py` already used).
- The full `composite_signal.py` -> `scenario_engine.py` pipeline was run
  end-to-end with all thirteen voters wired together and produces a
  coherent, fully-explained signal breakdown, including position sizing
  and an exit plan via `risk_management.py`.
- Two other real bugs were caught this way and fixed: the technical RSI
  calculation produced `NaN` forever on a strictly monotonic (all-up or
  all-down) price series (`indicator.py`), and the first version of the
  empirical-scenario direction calculation used raw mean-return magnitude,
  which silently produced near-zero signals even at a 72% win rate because
  of a units mismatch -- fixed to use win rate directly (`scenario_engine.py`).
- The first real-money-data run of anything in this project: a QQQ
  ensemble backtest against 5 years of real Nasdaq.com daily data. 51
  ensemble trades, 41.2% win rate. **That's a bad number, and it's QQQ,
  not SPY** -- this run wasn't a search for edge, it was confirmation the
  machinery is real. It also ran cleanly with no crashes, which for a
  first real-data pass across a dozen interacting modules was not a given.
- The first real-data run of the FULL 13-voter `generate_signal()` (not
  just the backtestable subset): 30 days of real SPY 1-minute bars, no
  live chain. Technical, candlestick, and time-of-day voters all produced
  real, coherent reads off real data for the first time. Hurst and the
  HMM regime detector both correctly and honestly reported "not enough
  history" rather than fabricate a read off only 30 derived daily bars --
  exactly the behavior they're designed to have, and a real (if small)
  confirmation that the "say I don't know" design actually holds up
  outside of synthetic tests.
- `support_resistance.py` was added and validated the same way: unit
  tests against synthetic bounce/rejection price paths, then a real-data
  check via `intraday_replay.py` against 2026-08-14 (see the case study
  above). It correctly identified both a real double-top rejection and a
  real support-zone chop using only levels it computed itself from that
  day's price action -- but that case study also surfaced a real
  dilution problem in the ensemble math (the frozen daily `technical`
  vote outweighing strong, agreeing intraday votes), documented there
  rather than quietly patched.
- `historical_chain.py` was added and validated against a real vendor
  export (2022-03-01, a same-format sample day already on hand): loaded
  SPY's 9,576 real option rows for that day, correctly picked the 1DTE
  expiration, and fed the resulting chain into `compute_gamma_profile()`
  and `compute_vanna_charm()` -- both produced real, non-placeholder
  output for the first time in this project (see "Historical options
  chains" above for the actual numbers). `put_call_ratio` correctly
  stayed neutral on that same day (real ratio landed inside the
  non-extreme band the voter is designed to ignore) -- confirmed against
  the raw volume totals rather than assumed, since a silent 0-confidence
  result could just as easily have been a bug.
- The 2026-08-14 real chain data (the actual day, not the 2022 sample)
  went further and caught a real bug rather than just adding coverage:
  `vanna_charm_vote()`'s no-history confidence fallback was mathematically
  guaranteed to always equal 1.0 for any realistically-scaled exposure,
  confirmed with the exact real number ($106,654,807 combined exposure on
  that day) -- see the case study above for the fix and the before/after
  ensemble reads.
- 46 real chain days (July 2025 + July 2026, filtered down from ~13GB of
  raw vendor exports to 28MB of SPY-only rows via `filter_spy_day.py`)
  were used to warm up the REAL `vanna_charm`/`skew_dynamics` persistent
  stores via `warm_up_history.py` -- both went from 0 to 46 real entries,
  crossing `min_history=20` for the first time in this project. Re-running
  the 2026-08-14 case study with that real (not throwaway, not synthetic)
  history showed both voters casting genuinely confident votes for the
  first time -- and, honestly reported rather than glossed over, slightly
  *worsening* the dilution problem on that particular day rather than
  fixing it, since both happened to agree with the already-dominant
  `technical` vote. See "Scaling up" above for the numbers and the
  contiguity caveat (two disjoint one-month windows, not a true trailing
  60-day window).

I did **not** validate that this ensemble has real predictive edge on
actual SPY history -- the QQQ backtest above is evidence *against* naive
overconfidence, not evidence of an edge, and it's the wrong ticker besides.
Real validation can only happen with a long real SPY daily history and
sustained live use feeding `record_outcome()`. The scenario engine's
persistent learning is specifically designed so that this validation
happens automatically as you use it, rather than needing a separate
one-off study.

## Time-of-day timing, and the discretionary playbook (`playbook.py`)

Separate from the voter ensemble above, real 5-min SPY charts (30 days,
7/6-8/14) were used to test a specific discretionary pattern: direction
is read from price action during a morning window, and if that read is
wrong, there's usually (not always) a countertrend bounce worth averaging
into around midday.

**Timing, confirmed against real data.** A swing/leg detector
(`zigzag_legs()` -- a multi-bar move absorbs a small consolidation
without counting as "reversed," same definition worked out by eye against
real charts before being coded) was run across all 30 days, filtered to
legs of at least 0.35% (roughly the size of a move that actually matters
for a 0DTE contract, versus the ~70% of legs below that which are noise).
Sorting days by what their real legs did: 9 trend-up days, 3 trend-down,
13 reversal days (two-plus opposing big legs), and 5 pure-chop days with
no qualifying move at all. Trend days overwhelmingly launch right at the
open (6 of 12 in the first 30 minutes); reversals cluster hard from
10:00-11:30 (11 of 20 reversal moments). Both findings held up across
day-shapes that looked completely different from each other by eye
(steady grind, quiet chop, sharp-spike-then-fade all bottomed or turned
in the same 11:20-11:45 window before a shared 12:30-14:30 lull) -- a
whole-day KMeans shape-clustering pass was tried too, but a real
misclassification (a day that peaks at 10:30 and declines into midday
got grouped with "trends down all day" because of what its afternoon did
later) showed the swing-leg method is the one to trust, since it judges
each move on its own terms instead of the whole day's shape.

**The average-down bounce, backtested.** `simulate_playbook()` takes each
day's entry window (10:00-11:30 net move stands in for "what a read of
this window would have pointed you toward" -- an optimistic "perfect
read" assumption, explicitly not a claim about real accuracy of the read
itself), and checks whether the trade would be underwater heading into a
bounce window (11:55-13:00), whether a real countertrend leg (>=0.10%)
showed up to average into, and whether doing so actually improved the
outcome held to the close. Across the 30 real days: 22 had a real
entry-window setup; of those, 4 were underwater at the bounce window; all
4 of those had a real bounce available; averaging into it improved the
outcome in all 4 (mean P&L on those days: -0.20% held alone vs -0.13%
averaged down -- softened the loss in every case here, matching "turn it
green or at least a lot less of a loss," though this is a small sample,
n=4, not a large-sample confirmation).

**Honest limits:** this is NOT wired into `composite_signal.py` or the
live ensemble -- it's a standalone, separately-backtested module on
purpose, so it can be validated against real discretionary results before
any decision is made about integrating it. The "perfect read" assumption
in the backtest is real: it tests "does averaging down help GIVEN a
correct read," not "how often is the read itself correct" -- that second
question needs a real trade log, not a mechanical proxy.

**Daily playbook review.** `trades.csv` (schema: date, entry_time,
direction, spy_entry_price, setup_notes, averaged_down, avg_down_time,
avg_down_price, exit_time, exit_price, pnl_dollars, outcome_notes) is
where real trades get logged -- `playbook.append_trade()` /
`playbook.load_trades()` read/write it. The intended workflow: log real
trades (or report them at end of day to have them logged), then compare
against that day's actual price action and this module's read of it --
where the read agreed with what you took, where it didn't, whether the
bounce showed up when expected, and whether averaging down would have
helped or hurt. This is deliberately the same "alert wide, review,
tighten" discipline as `daily_review.py` above, just applied to a
personal discretionary pattern instead of the voter ensemble.

## Suggested next steps once you have data subscriptions

- Historical options-chain data is now wired in (`historical_chain.py`,
  see above) -- the remaining work is just accumulating more days of it.
  Each `--chain-dir` day is one end-of-day snapshot (no intraday chain
  movement), so the natural next step is building up a folder covering
  more trading days over time, the same way `data/`'s Webull export
  covers a rolling window of intraday price history.
- Feed `record_outcome()` after every live signal (paper trade first) so
  `state/scenario_history.json` starts accumulating real evidence and the
  empirical-lookup path actually engages instead of always falling back
  to the weighted vote. Same for `skew_dynamics.py`'s own history store --
  it needs real accumulated days before it can vote at all.
- A real, long (multi-year) SPY daily CSV would immediately unlock
  meaningful Hurst/HMM reads and a true `backtest.py --ensemble` run on
  the actual target ticker -- `backtest.py`'s CSV loader already handles
  Nasdaq.com's free export format natively (see `load_data()`), it just
  needs the file. The QQQ run in this README used that same path.
  `webull_data.py` covers the intraday side already (see above);
  connecting a live Webull API adapter for chain data specifically would
  still need real account credentials handled somewhere -- if that's
  pursued, it should run as a script under the user's own control with an
  environment-variable key, not through a chat session.
- Options sweep/block-trade divergence is one more Phase-2 idea not yet
  built (needs trade-level tape, not just chain snapshots).
- `risk_management.py`'s `DailyRiskTracker` circuit breaker is built but
  not yet wired into a persistent live-trading loop across multiple
  signals in one session -- `live_signal.py` currently sizes each signal
  independently rather than tracking cumulative same-day P&L.

## Important limitations and risks

- **Not financial advice.** This is a technical/engineering tool for you
  to evaluate, tune, and use (or not) at your own discretion and risk.
- **1DTE and 0DTE options are high-risk, fast-moving instruments.** Theta
  decay accelerates sharply in the final day, and gamma can move an
  option's value dramatically on small underlying moves. Losing 100% of
  the premium on a trade is common, not exceptional.
- **The pre-FOMC drift specifically has mixed recent evidence** -- some
  research finds it's weakened since the mid-2010s as it became widely
  known. It's implemented as a light nudge for exactly this reason.
- **Backtested/simulated performance does not predict future results,**
  especially for the live-only voters, which have not been backtested at
  all (only smoke-tested with synthetic data).
- **`risk_management.py` bounds and sizes risk on purpose -- it does not
  guarantee profitability.** A well-sized losing strategy is still a
  losing strategy; sizing only controls how much and how fast you can
  lose, not whether the underlying signal is right.
- Paper trade or use very small size while real evidence accumulates in
  `state/` before committing meaningful capital.
