import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))

import numpy as np
import pandas as pd

from indicator import money_flow_index
from mfi_divergence import mfi_divergence_vote


def _bars(closes, volumes, start="2026-08-19 09:30"):
    n = len(closes)
    closes = np.asarray(closes, dtype=float)
    open_ = np.roll(closes, 1); open_[0] = closes[0]
    high = np.maximum(open_, closes) + 0.02
    low = np.minimum(open_, closes) - 0.02
    idx = pd.date_range(start, periods=n, freq="1min")
    return pd.DataFrame({"Open": open_, "High": high, "Low": low, "Close": closes,
                          "Volume": np.asarray(volumes, dtype=float)}, index=idx)


class TestMoneyFlowIndex(unittest.TestCase):
    def test_all_rising_price_and_volume_pushes_mfi_high(self):
        n = 40
        closes = 100 + np.arange(n) * 0.1
        volumes = np.full(n, 10000.0)
        bars = _bars(closes, volumes)
        mfi = money_flow_index(bars, period=14)
        self.assertGreater(mfi.iloc[-1], 90)

    def test_all_falling_price_pushes_mfi_low(self):
        n = 40
        closes = 100 - np.arange(n) * 0.1
        volumes = np.full(n, 10000.0)
        bars = _bars(closes, volumes)
        mfi = money_flow_index(bars, period=14)
        self.assertLess(mfi.iloc[-1], 10)

    def test_bounded_zero_to_hundred(self):
        rng = np.random.default_rng(3)
        n = 60
        closes = 100 + np.cumsum(rng.normal(0, 0.2, n))
        volumes = np.abs(rng.normal(10000, 3000, n)) + 100
        bars = _bars(closes, volumes)
        mfi = money_flow_index(bars, period=14).dropna()
        self.assertTrue((mfi >= 0).all())
        self.assertTrue((mfi <= 100).all())


class TestMfiDivergenceVote(unittest.TestCase):
    def test_not_enough_bars_sits_out(self):
        bars = _bars([100, 100.1, 100.2], [1000, 1000, 1000])
        vote = mfi_divergence_vote(bars)
        self.assertEqual(vote.confidence, 0.0)

    def test_price_up_on_fading_volume_reads_bearish_divergence(self):
        n = 40
        # price grinds up throughout, but volume collapses over the back half
        closes = 100 + np.arange(n) * 0.08
        volumes = np.concatenate([np.full(20, 20000.0), np.full(20, 500.0)])
        bars = _bars(closes, volumes)
        vote = mfi_divergence_vote(bars, lookback_bars=20)
        # either genuinely reads the divergence, or -- acceptable given synthetic
        # data -- stays honestly neutral, but it must never read confidently BULLISH
        # into a move whose volume support is visibly drying up
        self.assertLessEqual(vote.direction, 0.05)

    def test_price_down_on_rising_volume_reads_bullish_divergence(self):
        n = 40
        closes = 100 - np.arange(n) * 0.08
        volumes = np.concatenate([np.full(20, 500.0), np.full(20, 20000.0)])
        bars = _bars(closes, volumes)
        vote = mfi_divergence_vote(bars, lookback_bars=20)
        self.assertGreaterEqual(vote.direction, -0.05)

    def test_confidence_and_direction_always_in_bounds(self):
        rng = np.random.default_rng(7)
        for seed in range(10):
            n = 50
            closes = 100 + np.cumsum(rng.normal(0, 0.15, n))
            volumes = np.abs(rng.normal(8000, 4000, n)) + 50
            bars = _bars(closes, volumes)
            vote = mfi_divergence_vote(bars)
            self.assertGreaterEqual(vote.confidence, 0.0)
            self.assertLessEqual(vote.confidence, 1.0)
            self.assertGreaterEqual(vote.direction, -1.0)
            self.assertLessEqual(vote.direction, 1.0)

    def test_extreme_overbought_fades_bearish_when_no_divergence_triggered(self):
        # flat-ish recent window (no divergence signal) but a long enough
        # prior uptrend that MFI itself is pinned near 100
        n = 40
        closes = np.concatenate([100 + np.arange(20) * 0.15, np.full(20, 103.0)])
        volumes = np.full(n, 10000.0)
        bars = _bars(closes, volumes)
        vote = mfi_divergence_vote(bars, lookback_bars=5)
        if vote.regime_tag == "overbought":
            self.assertLess(vote.direction, 0)


if __name__ == "__main__":
    unittest.main()
