import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))

from helpers import make_intraday_ohlcv, make_market_hours_intraday_history
from candlestick_patterns import detect_patterns, multi_timeframe_confluence, candlestick_vote, PATTERN_COLUMNS
from time_of_day_fingerprint import build_fingerprint, score_today, fingerprint_vote


class TestCandlestickPatterns(unittest.TestCase):
    def test_detect_patterns_returns_signed_columns(self):
        df = make_intraday_ohlcv()
        patterns = detect_patterns(df)
        for col in PATTERN_COLUMNS:
            self.assertIn(col, patterns.columns)
            self.assertTrue(set(patterns[col].unique()).issubset({-1, 0, 1}))

    def test_multi_timeframe_confluence_covers_configured_timeframes(self):
        df = make_intraday_ohlcv(n_days=30)
        readings = multi_timeframe_confluence(df)
        labels = {r.timeframe for r in readings}
        self.assertTrue({"3m", "5m", "15m", "30m"}.issubset(labels))

    def test_candlestick_vote_bounded(self):
        df = make_intraday_ohlcv(n_days=30)
        vote = candlestick_vote(df)
        self.assertGreaterEqual(vote.direction, -1.0)
        self.assertLessEqual(vote.direction, 1.0)
        self.assertGreaterEqual(vote.confidence, 0.0)
        self.assertLessEqual(vote.confidence, 1.0)

    def test_candlestick_vote_gamma_structure_bonus_increases_confidence(self):
        from gamma_positioning import compute_gamma_profile
        from helpers import make_chain_snapshot

        df = make_intraday_ohlcv(n_days=30, start_price=550.0)
        chain = make_chain_snapshot(spot=550.0)
        profile = compute_gamma_profile(chain)

        vote_without = candlestick_vote(df)
        vote_with = candlestick_vote(df, gamma_profile=profile, atr=1.0)
        # Confidence with the structure bonus should never be lower than without it.
        self.assertGreaterEqual(vote_with.confidence, vote_without.confidence - 1e-9)

    def test_insufficient_data_returns_neutral_vote(self):
        import pandas as pd
        tiny = pd.DataFrame({
            "Open": [1, 2], "High": [1, 2], "Low": [1, 2], "Close": [1, 2], "Volume": [1, 1],
        }, index=pd.date_range("2026-01-01 09:30", periods=2, freq="3min"))
        vote = candlestick_vote(tiny)
        self.assertEqual(vote.confidence, 0.0)


class TestTimeOfDayFingerprint(unittest.TestCase):
    def test_build_fingerprint_has_bucket_stats(self):
        history = make_market_hours_intraday_history(n_days=60)
        fp = build_fingerprint(history, bucket_minutes=5)
        self.assertIn("hist_mean", fp.columns)
        self.assertIn("hist_std", fp.columns)
        self.assertIn("n_obs", fp.columns)
        self.assertGreater(len(fp), 0)

    def test_score_today_returns_finite_zscore_with_enough_history(self):
        history = make_market_hours_intraday_history(n_days=60)
        today = make_market_hours_intraday_history(n_days=1, seed=999).iloc[:40]
        fp = build_fingerprint(history, bucket_minutes=5)
        reading = score_today(today, fp)
        self.assertGreaterEqual(reading.n_obs, 20)

    def test_fingerprint_vote_bounded(self):
        history = make_market_hours_intraday_history(n_days=60)
        today = make_market_hours_intraday_history(n_days=1, seed=999).iloc[:40]
        fp = build_fingerprint(history, bucket_minutes=5)
        vote = fingerprint_vote(today, fp)
        self.assertGreaterEqual(vote.direction, -1.0)
        self.assertLessEqual(vote.direction, 1.0)


if __name__ == "__main__":
    unittest.main()
