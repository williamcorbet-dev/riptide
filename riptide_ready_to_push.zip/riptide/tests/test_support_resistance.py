import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))

import numpy as np
import pandas as pd

from support_resistance import find_swing_points, build_levels, support_resistance_vote


def _path_to_bars(anchors, noise=0.015, seed=1, start="2026-08-14 09:30"):
    """anchors: list of (minute_offset, price) checkpoints, linearly
    interpolated per minute with small noise, turned into 1-min OHLC bars."""
    rng = np.random.default_rng(seed)
    total_minutes = anchors[-1][0] + 1
    minutes = np.arange(total_minutes)
    xp = [a[0] for a in anchors]
    fp = [a[1] for a in anchors]
    close = np.interp(minutes, xp, fp) + rng.normal(0, noise, total_minutes)
    open_ = np.roll(close, 1)
    open_[0] = close[0]
    high = np.maximum(open_, close) + np.abs(rng.normal(0, noise / 2, total_minutes))
    low = np.minimum(open_, close) - np.abs(rng.normal(0, noise / 2, total_minutes))
    idx = pd.date_range(start, periods=total_minutes, freq="1min")
    return pd.DataFrame({"Open": open_, "High": high, "Low": low, "Close": close,
                          "Volume": 1000.0}, index=idx)


class TestFindSwingPoints(unittest.TestCase):
    def test_detects_a_clean_v_shape_low(self):
        anchors = [(0, 100), (10, 95), (20, 100)]
        bars = _path_to_bars(anchors, noise=0.01)
        swings = find_swing_points(bars, order=3)
        self.assertTrue(swings["swing_low"].any())
        low_idx = swings.index[swings["swing_low"]]
        # the detected low(s) should be near the true minimum around minute 10
        self.assertTrue(any(abs((t - bars.index[0]).total_seconds() / 60 - 10) < 3 for t in low_idx))


class TestBuildLevels(unittest.TestCase):
    def test_repeated_touches_cluster_into_one_stronger_level(self):
        # dips to ~98 three times, bouncing to ~101 in between
        anchors = [(0, 100), (20, 98), (40, 101), (60, 98), (80, 101), (100, 98), (120, 101)]
        bars = _path_to_bars(anchors, noise=0.01)
        levels = build_levels(bars, atr=1.0, timeframe="5min", order=2)
        near_98 = [lv for lv in levels if abs(lv.price - 98) < 0.5]
        self.assertTrue(near_98, f"expected a level near 98, got {[lv.price for lv in levels]}")
        self.assertGreaterEqual(near_98[0].strength, 2)

    def test_prior_day_levels_seed_immediately_with_no_intraday_swings(self):
        anchors = [(0, 100), (5, 100.2)]
        bars = _path_to_bars(anchors, noise=0.005)
        levels = build_levels(bars, atr=1.0, prior_day_levels={"high": 105.0, "low": 95.0, "close": 100.0})
        prices = [lv.price for lv in levels]
        self.assertIn(True, [abs(p - 105.0) < 0.01 for p in prices])
        self.assertIn(True, [abs(p - 95.0) < 0.01 for p in prices])

    def test_no_data_returns_no_levels(self):
        bars = _path_to_bars([(0, 100), (3, 100)], noise=0.0)
        levels = build_levels(bars, atr=1.0)
        self.assertEqual(levels, [])


class TestSupportResistanceVote(unittest.TestCase):
    def test_bounce_off_support_is_bullish(self):
        # two clean touches of ~98 with a bounce to ~101, then a THIRD
        # approach that's just started ticking back up as the window ends
        # (the "now") -- close enough to the level to still count as "at" it
        anchors = [(0, 100), (20, 98), (40, 101), (60, 98), (80, 101),
                   (100, 98.5), (103, 98.0), (105, 98.15)]
        bars = _path_to_bars(anchors, noise=0.005, seed=2)
        vote = support_resistance_vote(bars, atr=1.0, timeframe="5min", order=2)
        self.assertGreater(vote.confidence, 0.0)
        self.assertGreater(vote.direction, 0.0)
        self.assertEqual(vote.regime_tag, "bounce_support")

    def test_rejection_at_resistance_is_bearish(self):
        anchors = [(0, 98), (20, 102), (40, 99), (60, 102), (80, 99),
                   (100, 101.5), (103, 102.0), (105, 101.85)]
        bars = _path_to_bars(anchors, noise=0.005, seed=3)
        vote = support_resistance_vote(bars, atr=1.0, timeframe="5min", order=2)
        self.assertGreater(vote.confidence, 0.0)
        self.assertLess(vote.direction, 0.0)
        self.assertEqual(vote.regime_tag, "bounce_resistance")

    def test_far_from_any_level_is_neutral(self):
        anchors = [(0, 100), (20, 98), (40, 101), (60, 98), (80, 150)]
        bars = _path_to_bars(anchors, noise=0.01, seed=4)
        vote = support_resistance_vote(bars, atr=1.0, timeframe="5min", order=2)
        self.assertEqual(vote.confidence, 0.0)
        self.assertIn("not currently near", vote.detail.get("reason", ""))

    def test_too_little_data_is_neutral(self):
        bars = _path_to_bars([(0, 100), (1, 100.1)], noise=0.0)
        vote = support_resistance_vote(bars, atr=1.0)
        self.assertEqual(vote.confidence, 0.0)

    def test_strength_scales_confidence(self):
        # one touch vs. two touches of the same level -- more touches
        # should mean more confidence in the eventual bounce read
        weak_anchors = [(0, 100), (20, 98), (40, 101), (60, 98.5), (63, 98.0), (65, 98.15)]
        strong_anchors = [(0, 100), (20, 98), (40, 101), (60, 98), (80, 101),
                           (100, 98.5), (103, 98.0), (105, 98.15)]
        weak = support_resistance_vote(_path_to_bars(weak_anchors, noise=0.005, seed=5),
                                        atr=1.0, timeframe="5min", order=2)
        strong = support_resistance_vote(_path_to_bars(strong_anchors, noise=0.005, seed=5),
                                          atr=1.0, timeframe="5min", order=2)
        self.assertEqual(weak.regime_tag, "bounce_support")
        self.assertEqual(strong.regime_tag, "bounce_support")
        self.assertGreater(strong.detail["strength"], weak.detail["strength"])
        self.assertGreaterEqual(strong.confidence, weak.confidence)

    def test_direction_and_confidence_are_bounded(self):
        anchors = [(0, 100), (20, 98), (40, 101), (60, 98), (80, 101), (100, 98.5), (103, 98.0), (105, 98.15)]
        vote = support_resistance_vote(_path_to_bars(anchors, noise=0.005, seed=6), atr=1.0, timeframe="5min", order=2)
        self.assertGreaterEqual(vote.direction, -1.0)
        self.assertLessEqual(vote.direction, 1.0)
        self.assertGreaterEqual(vote.confidence, 0.0)
        self.assertLessEqual(vote.confidence, 1.0)


if __name__ == "__main__":
    unittest.main()
