import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))

import numpy as np

from helpers import make_daily_ohlcv
from indicator import compute_indicator, IndicatorConfig
from options_pricing import bs_price, nearest_strike


class TestIndicator(unittest.TestCase):
    def test_compute_indicator_adds_expected_columns(self):
        df = make_daily_ohlcv()
        ind = compute_indicator(df, IndicatorConfig())
        for col in ("score", "signal", "atr", "atr_pct_rank", "vwap", "rsi", "macd_hist"):
            self.assertIn(col, ind.columns)

    def test_score_bounded(self):
        df = make_daily_ohlcv()
        ind = compute_indicator(df, IndicatorConfig())
        valid = ind["score"].dropna()
        self.assertTrue((valid >= -1.0001).all())
        self.assertTrue((valid <= 1.0001).all())

    def test_signal_values_are_valid_labels(self):
        df = make_daily_ohlcv()
        ind = compute_indicator(df, IndicatorConfig())
        self.assertTrue(set(ind["signal"].unique()).issubset({"CALL", "PUT", "NONE"}))

    def test_missing_columns_raises(self):
        df = make_daily_ohlcv().drop(columns=["Volume"])
        with self.assertRaises(ValueError):
            compute_indicator(df, IndicatorConfig())

    def test_strong_uptrend_biases_bullish(self):
        # A close series that only goes up should skew the technical score positive
        # more often than negative once indicators have warmed up.
        import pandas as pd
        dates = pd.bdate_range("2024-01-02", periods=300)
        close = np.linspace(400, 500, 300)
        df = pd.DataFrame({
            "Open": close, "High": close * 1.002, "Low": close * 0.998,
            "Close": close, "Volume": np.full(300, 1e6),
        }, index=dates)
        ind = compute_indicator(df, IndicatorConfig())
        tail_scores = ind["score"].iloc[100:].dropna()
        self.assertGreater((tail_scores > 0).mean(), 0.5)


class TestOptionsPricing(unittest.TestCase):
    def test_bs_price_call_between_intrinsic_and_spot(self):
        price = bs_price(S=550, K=550, T=1 / 365, r=0.05, sigma=0.16, option_type="call")
        self.assertGreaterEqual(price, 0.0)
        self.assertLess(price, 550)

    def test_bs_price_deep_itm_call_approaches_intrinsic(self):
        price = bs_price(S=600, K=500, T=1 / 365, r=0.05, sigma=0.16, option_type="call")
        intrinsic = 100
        self.assertAlmostEqual(price, intrinsic, delta=2.0)

    def test_bs_price_put_call_relationship_at_zero_vol(self):
        call = bs_price(S=550, K=540, T=1 / 365, r=0.0, sigma=1e-6, option_type="call")
        self.assertAlmostEqual(call, 10.0, delta=0.5)

    def test_nearest_strike_rounds_correctly(self):
        self.assertEqual(nearest_strike(550.4, 1.0), 550.0)
        self.assertEqual(nearest_strike(550.6, 1.0), 551.0)


if __name__ == "__main__":
    unittest.main()
