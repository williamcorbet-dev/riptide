import datetime
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))

import numpy as np

from helpers import make_chain_snapshot
from gamma_positioning import compute_gamma_profile, pin_score
from vanna_charm import compute_vanna_charm, vanna_charm_vote, VannaCharmHistoryStore


class TestGammaPositioning(unittest.TestCase):
    def test_gamma_profile_fields_present_and_typed(self):
        chain = make_chain_snapshot()
        profile = compute_gamma_profile(chain)
        self.assertIn(profile.regime, ("positive", "negative"))
        self.assertIsInstance(profile.total_gex, float)
        self.assertIsInstance(profile.zero_gamma_flip, float)
        self.assertIsInstance(profile.max_pain_strike, float)

    def test_max_pain_within_strike_range(self):
        chain = make_chain_snapshot(spot=550.0, width=30)
        profile = compute_gamma_profile(chain)
        self.assertGreaterEqual(profile.max_pain_strike, chain.strike.min())
        self.assertLessEqual(profile.max_pain_strike, chain.strike.max())

    def test_flip_level_near_spot_for_symmetric_chain(self):
        # With a roughly symmetric random chain, the zero-gamma flip should
        # land somewhere in the searched neighborhood of spot, not blow up.
        chain = make_chain_snapshot(spot=550.0)
        profile = compute_gamma_profile(chain)
        self.assertGreater(profile.zero_gamma_flip, 550.0 * 0.85)
        self.assertLess(profile.zero_gamma_flip, 550.0 * 1.15)

    def test_pin_score_zero_when_negative_regime(self):
        chain = make_chain_snapshot(spot=550.0)
        profile = compute_gamma_profile(chain)
        if profile.regime == "negative":
            self.assertEqual(pin_score(profile, atr=3.0, hours_to_close=1.0), 0.0)

    def test_pin_score_bounded_0_100(self):
        chain = make_chain_snapshot(spot=550.0)
        profile = compute_gamma_profile(chain)
        score = pin_score(profile, atr=3.0, hours_to_close=1.0)
        self.assertGreaterEqual(score, 0.0)
        self.assertLessEqual(score, 100.0)


class TestVannaCharm(unittest.TestCase):
    def test_compute_vanna_charm_returns_finite_numbers(self):
        chain = make_chain_snapshot()
        profile = compute_vanna_charm(chain)
        self.assertTrue(np.isfinite(profile.vanna_exposure))
        self.assertTrue(np.isfinite(profile.charm_exposure))

    def test_no_history_or_scale_is_honestly_neutral(self):
        # Confirmed against real historical chain data (2026-08-14, see
        # README): combined vanna/charm exposure is always $100Ks+ for a
        # real chain, so an old fallback formula of
        # abs(combined)/max(abs(combined), 1.0) was mathematically ~1.0
        # on every real call -- silently maxing out confidence instead of
        # being the "weak/crude" signal it claimed to be. With neither
        # history_scale nor store supplied, this must now be honestly 0,
        # not a guess.
        chain = make_chain_snapshot()
        profile = compute_vanna_charm(chain)
        vote = vanna_charm_vote(profile, hours_to_close=1.0)
        self.assertEqual(vote.confidence, 0.0)
        self.assertEqual(vote.direction, 0.0)
        self.assertTrue(vote.live_only)
        self.assertIn("reason", vote.detail)

    def test_vanna_charm_vote_direction_bounded_with_explicit_scale(self):
        chain = make_chain_snapshot()
        profile = compute_vanna_charm(chain)
        combined = profile.vanna_exposure + profile.charm_exposure
        vote = vanna_charm_vote(profile, hours_to_close=1.0, history_scale=abs(combined) / 2)
        self.assertGreaterEqual(vote.direction, -1.0)
        self.assertLessEqual(vote.direction, 1.0)
        self.assertTrue(vote.live_only)

    def test_vanna_charm_vote_confidence_increases_late_session_with_explicit_scale(self):
        chain = make_chain_snapshot()
        profile = compute_vanna_charm(chain)
        combined = profile.vanna_exposure + profile.charm_exposure
        scale = abs(combined) / 2  # comfortably nonzero so magnitude isn't already saturated
        early = vanna_charm_vote(profile, hours_to_close=6.0, history_scale=scale)
        late = vanna_charm_vote(profile, hours_to_close=0.25, history_scale=scale)
        # Late-session confidence should be at least as high as early-session,
        # given the same underlying exposure (charm/gamma accelerate near close).
        self.assertGreaterEqual(late.confidence, early.confidence - 1e-9)


class TestVannaCharmHistoryStore(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.store = VannaCharmHistoryStore(path=os.path.join(self.tmpdir, "vc_history.json"))

    def test_record_and_history_roundtrip(self):
        for i, mag in enumerate([1e6, 2e6, 3e6]):
            self.store.record(datetime.date(2026, 1, i + 1), mag)
        self.assertEqual(self.store.history(), [1e6, 2e6, 3e6])

    def test_same_date_overwrites_not_duplicates(self):
        self.store.record(datetime.date(2026, 1, 1), 1e6)
        self.store.record(datetime.date(2026, 1, 1), 9e6)
        self.assertEqual(self.store.history(), [9e6])

    def test_lookback_days_truncates(self):
        for i in range(30):
            self.store.record(datetime.date(2026, 2, 1) + datetime.timedelta(days=i), float(i))
        hist = self.store.history(lookback_days=5)
        self.assertEqual(hist, [25.0, 26.0, 27.0, 28.0, 29.0])

    def test_persistence_across_new_store_instances(self):
        self.store.record(datetime.date(2026, 1, 1), 5e6)
        reloaded = VannaCharmHistoryStore(path=self.store.path)
        self.assertEqual(reloaded.history(), [5e6])


class TestVannaCharmVoteWithStore(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.store = VannaCharmHistoryStore(path=os.path.join(self.tmpdir, "vc_history.json"))

    def test_not_enough_history_is_honestly_neutral(self):
        for i in range(5):
            self.store.record(datetime.date(2026, 1, i + 1), 1e6)
        chain = make_chain_snapshot()
        profile = compute_vanna_charm(chain)
        vote = vanna_charm_vote(profile, hours_to_close=1.0, store=self.store,
                                 as_of=datetime.date(2026, 1, 10), min_history=20)
        self.assertEqual(vote.confidence, 0.0)

    def test_vote_records_todays_magnitude_into_store(self):
        for i in range(25):
            self.store.record(datetime.date(2026, 1, 1) + datetime.timedelta(days=i), 1e6)
        chain = make_chain_snapshot()
        profile = compute_vanna_charm(chain)
        today = datetime.date(2026, 2, 1)
        vanna_charm_vote(profile, hours_to_close=1.0, store=self.store, as_of=today, min_history=20)
        self.assertIn(today.isoformat(), self.store.readings)

    def test_unusually_large_exposure_against_history_is_confident(self):
        # 25 days of small, stable magnitude...
        for i in range(25):
            self.store.record(datetime.date(2026, 1, 1) + datetime.timedelta(days=i), 1e6)
        # ...today's chain has much larger open interest -> much larger exposure
        chain = make_chain_snapshot(seed=99)
        chain.call_oi[:] *= 50
        chain.put_oi[:] *= 50
        profile = compute_vanna_charm(chain)
        vote = vanna_charm_vote(profile, hours_to_close=1.0, store=self.store,
                                 as_of=datetime.date(2026, 2, 10), min_history=20)
        self.assertGreater(vote.confidence, 0.0)


if __name__ == "__main__":
    unittest.main()
