"""Shared synthetic-data generators for the test suite. No real market data
is used anywhere in these tests -- see README.md for why (no outbound
internet in the environment this was developed in). These generators are
built to exercise each module's actual mechanics (autocorrelation for
Hurst, regime-switching for the HMM, a plausible options chain shape for
gamma/vanna/charm), not just to avoid crashing.
"""

import numpy as np
import pandas as pd


def make_daily_ohlcv(n=500, seed=42, start_price=500.0, start_date="2024-01-02"):
    rng = np.random.default_rng(seed)
    dates = pd.bdate_range(start_date, periods=n)
    ret = rng.normal(0.0003, 0.011, n)
    close = start_price * np.exp(np.cumsum(ret))
    high = close * (1 + np.abs(rng.normal(0, 0.004, n)))
    low = close * (1 - np.abs(rng.normal(0, 0.004, n)))
    open_ = close * (1 + rng.normal(0, 0.002, n))
    volume = rng.lognormal(16.5, 0.3, n)
    return pd.DataFrame({"Open": open_, "High": high, "Low": low, "Close": close, "Volume": volume}, index=dates)


def make_intraday_ohlcv(n_days=30, bars_per_day=130, freq="3min", seed=3, start_price=550.0):
    rng = np.random.default_rng(seed)
    n = n_days * bars_per_day
    idx = pd.date_range("2026-06-01 09:30", periods=n, freq=freq)
    ret = rng.normal(0, 0.0008, n)
    close = start_price * np.exp(np.cumsum(ret))
    high = close * (1 + np.abs(rng.normal(0, 0.0006, n)))
    low = close * (1 - np.abs(rng.normal(0, 0.0006, n)))
    open_ = np.roll(close, 1)
    open_[0] = close[0]
    vol = rng.lognormal(10, 0.3, n)
    return pd.DataFrame({"Open": open_, "High": high, "Low": low, "Close": close, "Volume": vol}, index=idx)


def make_market_hours_intraday_history(n_days=60, freq="5min", seed=7, start_price=550.0):
    """Multiple days of 09:30-16:00 bars, for time-of-day fingerprint tests."""
    rng = np.random.default_rng(seed)

    def make_day(date, price):
        idx = pd.date_range(f"{date} 09:30", f"{date} 16:00", freq=freq)
        m = len(idx)
        shape = 1.5 - 1.0 * np.sin(np.pi * np.arange(m) / m)
        ret = rng.normal(0, 0.0006, m) * shape
        close = price * np.exp(np.cumsum(ret))
        open_ = np.roll(close, 1)
        open_[0] = close[0]
        return pd.DataFrame({"Open": open_, "High": close * 1.0008, "Low": close * 0.9992,
                              "Close": close, "Volume": 1000}, index=idx)

    days = pd.bdate_range("2026-05-01", periods=n_days)
    return pd.concat([make_day(d.date(), start_price) for d in days])


def make_chain_snapshot(spot=550.0, seed=11, width=30, time_to_expiry_years=1 / 365):
    from gamma_positioning import ChainSnapshot

    rng = np.random.default_rng(seed)
    strikes = np.arange(round(spot) - width, round(spot) + width + 1, 1.0)
    n = len(strikes)
    return ChainSnapshot(
        strike=strikes,
        call_oi=rng.integers(100, 5000, n).astype(float),
        put_oi=rng.integers(100, 5000, n).astype(float),
        call_iv=np.clip(0.15 + rng.normal(0, 0.02, n), 0.08, 0.6),
        put_iv=np.clip(0.16 + rng.normal(0, 0.02, n), 0.08, 0.6),
        call_volume=rng.integers(0, 2000, n).astype(float),
        put_volume=rng.integers(0, 2000, n).astype(float),
        time_to_expiry_years=time_to_expiry_years,
        spot=spot,
    )


def make_skewed_chain_snapshot(spot=550.0, skew_level=0.05, seed=11, width=40,
                                time_to_expiry_years=1 / 365, base_iv=0.15):
    """Like make_chain_snapshot, but with a directly controllable put/call
    skew level (put_iv - call_iv, approximately, near the 25-delta strikes)
    so tests can simulate a sequence of days with rising/falling skew."""
    from gamma_positioning import ChainSnapshot

    rng = np.random.default_rng(seed)
    strikes = np.arange(round(spot) - width, round(spot) + width + 1, 1.0)
    n = len(strikes)
    call_iv = np.clip(base_iv + rng.normal(0, 0.002, n), 0.05, 0.6)
    put_iv = np.clip(base_iv + skew_level + rng.normal(0, 0.002, n), 0.05, 0.6)
    return ChainSnapshot(
        strike=strikes,
        call_oi=np.full(n, 1000.0),
        put_oi=np.full(n, 1000.0),
        call_iv=call_iv,
        put_iv=put_iv,
        call_volume=np.full(n, 100.0),
        put_volume=np.full(n, 100.0),
        time_to_expiry_years=time_to_expiry_years,
        spot=spot,
    )


def make_leader_and_target_dict(target_close, tickers=("QQQ", "AAPL"), seed=21):
    """Synthetic leader Close-price series aligned to target_close's index,
    for full-stack tests that just need composite_signal's leader_data
    plumbing exercised end-to-end. The real lead-lag-detection math is
    covered independently in test_cross_asset_leadlag.py's
    make_leader_and_target(), which builds a genuine relationship by
    construction -- these leaders don't need one."""
    rng = np.random.default_rng(seed)
    leaders = {}
    for ticker in tickers:
        ret = rng.normal(0.0002, 0.012, len(target_close))
        price = 100 * np.exp(np.cumsum(ret))
        leaders[ticker] = pd.Series(price, index=target_close.index)
    return leaders


def make_vix_term_structure(n=500, seed=9, start_date="2024-01-02"):
    rng = np.random.default_rng(seed)
    dates = pd.bdate_range(start_date, periods=n)
    vix = np.clip(15 + rng.normal(0, 3, n).cumsum() * 0.02, 10, 50)
    vix3m = vix * rng.uniform(0.92, 1.05, n)
    df = pd.DataFrame({"VIX": vix, "VIX3M": vix3m}, index=dates)
    df["ratio"] = df["VIX"] / df["VIX3M"]
    return df


def make_ar1_returns(n=3000, phi=0.0, seed=0):
    """AR(1) synthetic returns for Hurst-exponent tests: phi>0 -> persistent
    (trending), phi<0 -> anti-persistent (mean-reverting), phi=0 -> white noise."""
    rng = np.random.default_rng(seed)
    x = np.zeros(n)
    for i in range(1, n):
        x[i] = phi * x[i - 1] + rng.normal(0, 1)
    return x


def make_regime_switching_returns(seed=5):
    rng = np.random.default_rng(seed)
    calm1 = rng.normal(0.0003, 0.006, 150)
    stressed = rng.normal(-0.001, 0.02, 60)
    calm2 = rng.normal(0.0003, 0.006, 150)
    return np.concatenate([calm1, stressed, calm2])
