import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))

from voters import Vote
from scenario_engine import aggregate, record_outcome, ScenarioStore, AdaptiveWeights, scenario_fingerprint


class TestScenarioEngine(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.store = ScenarioStore(path=os.path.join(self.tmpdir, "scenarios.json"))
        self.weights = AdaptiveWeights(path=os.path.join(self.tmpdir, "weights.json"))

    def test_fingerprint_is_order_independent(self):
        v1 = [Vote(name="a", direction=0.5, confidence=0.5, regime_tag="x"),
              Vote(name="b", direction=-0.5, confidence=0.5, regime_tag="y")]
        v2 = list(reversed(v1))
        self.assertEqual(scenario_fingerprint(v1), scenario_fingerprint(v2))

    def test_aggregate_falls_back_to_weighted_ensemble_with_no_history(self):
        votes = [Vote(name="a", direction=0.6, confidence=0.7),
                 Vote(name="b", direction=0.5, confidence=0.8)]
        result = aggregate(votes, scenario_store=self.store, adaptive_weights=self.weights)
        self.assertEqual(result.method, "weighted_ensemble")

    def test_aggregate_direction_matches_sign_of_agreeing_votes(self):
        votes = [Vote(name="a", direction=0.6, confidence=0.7),
                 Vote(name="b", direction=0.5, confidence=0.8)]
        result = aggregate(votes, scenario_store=self.store, adaptive_weights=self.weights,
                            signal_threshold=0.1)
        self.assertEqual(result.signal, "CALL")

    def test_empirical_scenario_used_once_enough_samples(self):
        votes = [Vote(name="a", direction=0.6, confidence=0.7),
                 Vote(name="b", direction=0.5, confidence=0.8, regime_tag="negative")]
        sig = aggregate(votes, scenario_store=self.store, adaptive_weights=self.weights,
                         min_scenario_samples=20)
        for _ in range(20):
            record_outcome(sig, 0.01, scenario_store=self.store, adaptive_weights=self.weights)
            sig = aggregate(votes, scenario_store=self.store, adaptive_weights=self.weights,
                             min_scenario_samples=20)
        self.assertEqual(sig.method, "empirical_scenario")

    def test_empirical_scenario_high_win_rate_produces_call(self):
        votes = [Vote(name="a", direction=0.6, confidence=0.7),
                 Vote(name="b", direction=0.5, confidence=0.8, regime_tag="negative")]
        sig = aggregate(votes, scenario_store=self.store, adaptive_weights=self.weights)
        for i in range(25):
            outcome = 0.01 if i % 4 != 0 else -0.005  # 75% win rate
            record_outcome(sig, outcome, scenario_store=self.store, adaptive_weights=self.weights)
            sig = aggregate(votes, scenario_store=self.store, adaptive_weights=self.weights)
        self.assertEqual(sig.signal, "CALL")
        self.assertGreater(sig.scenario_win_rate, 0.7)

    def test_persistence_across_new_store_instances(self):
        votes = [Vote(name="a", direction=0.6, confidence=0.7)]
        sig = aggregate(votes, scenario_store=self.store, adaptive_weights=self.weights)
        record_outcome(sig, 0.01, scenario_store=self.store, adaptive_weights=self.weights)

        reloaded = ScenarioStore(path=self.store.path)
        self.assertEqual(reloaded.get(sig.fingerprint).n, 1)

    def test_dampener_suppresses_confidence(self):
        votes = [Vote(name="a", direction=0.6, confidence=0.7),
                 Vote(name="vix", direction=0.0, confidence=0.0, detail={"dampener": 0.1})]
        result = aggregate(votes, scenario_store=self.store, adaptive_weights=self.weights)
        self.assertLessEqual(result.confidence, 0.7 * 0.1 + 1e-6)

    def test_adaptive_weights_reward_correct_voters(self):
        votes = [Vote(name="good", direction=1.0, confidence=1.0),
                 Vote(name="bad", direction=-1.0, confidence=1.0)]
        sig = aggregate(votes, scenario_store=self.store, adaptive_weights=self.weights)
        record_outcome(sig, 0.01, scenario_store=self.store, adaptive_weights=self.weights)  # positive outcome
        self.assertGreater(self.weights.get("good"), self.weights.get("bad"))


if __name__ == "__main__":
    unittest.main()
