import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))

import numpy as np
import pandas as pd

from cross_asset_leadlag import compute_leadlag_strength, leadlag_vote


def make_leader_and_target(n=600, alpha=0.5, seed=0):
    """Builds a target whose return at t is genuinely driven partly by the
    leader's return at t-1 -- a real lead-lag relationship by construction,
    so we can check the detector actually finds it."""
    rng = np.random.default_rng(seed)
    dates = pd.bdate_range("2023-01-02", periods=n)
    leader_ret = rng.normal(0, 0.01, n)
    noise = rng.normal(0, 0.01, n)
    target_ret = np.zeros(n)
    target_ret[1:] = alpha * leader_ret[:-1] + noise[1:]

    leader_close = pd.Series(100 * np.exp(np.cumsum(leader_ret)), index=dates)
    target_close = pd.Series(500 * np.exp(np.cumsum(target_ret)), index=dates)
    return leader_close, target_close


class TestLeadLagStrength(unittest.TestCase):
    def test_detects_genuine_lead_relationship(self):
        leader, target = make_leader_and_target(alpha=0.6, seed=1)
        corr = compute_leadlag_strength(leader, target)
        self.assertGreater(corr, 0.2)

    def test_no_relationship_gives_low_correlation(self):
        leader, target = make_leader_and_target(alpha=0.0, seed=2)
        corr = compute_leadlag_strength(leader, target)
        self.assertLess(abs(corr), 0.15)

    def test_short_history_returns_nan(self):
        dates = pd.bdate_range("2024-01-01", periods=10)
        leader = pd.Series(np.linspace(100, 101, 10), index=dates)
        target = pd.Series(np.linspace(500, 505, 10), index=dates)
        corr = compute_leadlag_strength(leader, target)
        self.assertTrue(np.isnan(corr))


class TestLeadLagVote(unittest.TestCase):
    def test_strong_leader_produces_confident_vote(self):
        leader, target = make_leader_and_target(alpha=0.6, seed=1)
        vote = leadlag_vote({"LEADER": leader}, target, min_abs_corr=0.05)
        self.assertGreater(vote.confidence, 0.0)
        self.assertIn("LEADER", vote.detail["per_leader"])
        self.assertTrue(vote.detail["per_leader"]["LEADER"]["used"])

    def test_vote_direction_matches_leaders_recent_move(self):
        leader, target = make_leader_and_target(alpha=0.6, seed=1)
        # Force the leader's most recent return to be clearly positive
        leader = leader.copy()
        leader.iloc[-1] = leader.iloc[-2] * 1.05
        vote = leadlag_vote({"LEADER": leader}, target, min_abs_corr=0.05)
        if vote.confidence > 0:
            self.assertGreaterEqual(vote.direction, 0.0)

    def test_no_leaders_meeting_threshold_is_neutral(self):
        leader, target = make_leader_and_target(alpha=0.0, seed=2)
        vote = leadlag_vote({"NOISE": leader}, target, min_abs_corr=0.5)  # unreachably high bar
        self.assertEqual(vote.confidence, 0.0)
        self.assertEqual(vote.direction, 0.0)

    def test_direction_bounded(self):
        leader, target = make_leader_and_target(alpha=0.6, seed=1)
        vote = leadlag_vote({"LEADER": leader}, target)
        self.assertGreaterEqual(vote.direction, -1.0)
        self.assertLessEqual(vote.direction, 1.0)


if __name__ == "__main__":
    unittest.main()
