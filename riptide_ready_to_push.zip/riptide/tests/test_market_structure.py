import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))

import numpy as np
import pandas as pd

from market_structure import compute_market_structure, market_structure_vote, MarketStructureConfig


def _bars(closes, noise=0.02, seed=1, start="2026-08-14 09:30"):
    rng = np.random.default_rng(seed)
    n = len(closes)
    closes = np.asarray(closes, dtype=float) + rng.normal(0, noise, n)
    open_ = np.roll(closes, 1); open_[0] = closes[0]
    high = np.maximum(open_, closes) + np.abs(rng.normal(0, noise, n))
    low = np.minimum(open_, closes) - np.abs(rng.normal(0, noise, n))
    idx = pd.date_range(start, periods=n, freq="1min")
    return pd.DataFrame({"Open": open_, "High": high, "Low": low, "Close": closes}, index=idx)


class TestComputeMarketStructure(unittest.TestCase):
    def test_output_length_matches_input(self):
        bars = _bars(100 + np.arange(60) * 0.05, seed=17)
        out = compute_market_structure(bars, MarketStructureConfig(pivot_sensitivity=3))
        self.assertEqual(len(out), len(bars))

    def test_strictly_alternating_pivot_types(self):
        rng = np.random.default_rng(9)
        n = 300
        closes = 100 + np.cumsum(rng.normal(0, 0.2, n))
        bars = _bars(closes, noise=0.02, seed=9)
        out = compute_market_structure(bars, MarketStructureConfig(pivot_sensitivity=3))
        types = [p["type"] for p in out.attrs["pivot_log"]]
        for a, b in zip(types, types[1:]):
            self.assertNotEqual(a, b)

    def test_stair_step_uptrend_produces_all_bullish_classifications(self):
        # a clean series of higher highs and higher lows (a rising staircase
        # with pullbacks) should classify every non-first pivot as HH or HL
        n = 200
        t = np.arange(n)
        closes = 100 + t * 0.15 + 2.0 * np.sin(t / 8.0)  # rising trend + regular pullback oscillation
        bars = _bars(closes, noise=0.01, seed=21)
        out = compute_market_structure(bars, MarketStructureConfig(pivot_sensitivity=3))
        classified = [p["cls"] for p in out.attrs["pivot_log"] if p["cls"] is not None]
        self.assertTrue(len(classified) >= 3)
        self.assertTrue(all(c in ("HH", "HL") for c in classified))

    def test_stair_step_downtrend_produces_all_bearish_classifications(self):
        n = 200
        t = np.arange(n)
        closes = 100 - t * 0.15 + 2.0 * np.sin(t / 8.0)
        bars = _bars(closes, noise=0.01, seed=22)
        out = compute_market_structure(bars, MarketStructureConfig(pivot_sensitivity=3))
        classified = [p["cls"] for p in out.attrs["pivot_log"] if p["cls"] is not None]
        self.assertTrue(len(classified) >= 3)
        self.assertTrue(all(c in ("LH", "LL") for c in classified))

    def test_pure_bullish_structure_scores_near_positive_100(self):
        n = 200
        t = np.arange(n)
        closes = 100 + t * 0.15 + 2.0 * np.sin(t / 8.0)
        bars = _bars(closes, noise=0.005, seed=21)
        out = compute_market_structure(bars, MarketStructureConfig(pivot_sensitivity=3))
        final_score = out["score"].iloc[-1]
        self.assertFalse(np.isnan(final_score))
        self.assertGreater(final_score, 50.0)

    def test_weaker_same_type_pivot_is_dropped_not_appended(self):
        # a lower high immediately following a higher high, before any low
        # pivot separates them, must not create two consecutive highs
        n = 40
        closes = np.full(n, 100.0)
        bars = _bars(closes, noise=0.0, seed=5)
        # first bump (bigger), a few bars later a smaller bump (weaker high)
        bars.iloc[10, bars.columns.get_loc("High")] = 110.0
        bars.iloc[18, bars.columns.get_loc("High")] = 105.0
        out = compute_market_structure(bars, MarketStructureConfig(pivot_sensitivity=3))
        highs = [p for p in out.attrs["pivot_log"] if p["type"] == "high"]
        self.assertEqual(len(highs), 1)
        self.assertAlmostEqual(highs[0]["price"], 110.0)

    def test_no_lookahead_first_n_bars_identical_when_series_extended(self):
        rng = np.random.default_rng(11)
        n = 150
        closes = 100 + np.cumsum(rng.normal(0, 0.2, n))
        bars_full = _bars(closes, noise=0.01, seed=11)
        bars_prefix = bars_full.iloc[:100].copy()
        cfg = MarketStructureConfig(pivot_sensitivity=3)

        out_full = compute_market_structure(bars_full, cfg)
        out_prefix = compute_market_structure(bars_prefix, cfg)

        pd.testing.assert_series_equal(
            out_full["score"].iloc[:100], out_prefix["score"].iloc[:100], check_names=False)
        pd.testing.assert_series_equal(
            out_full["choch_bull"].iloc[:100], out_prefix["choch_bull"].iloc[:100], check_names=False)
        pd.testing.assert_series_equal(
            out_full["bos_bull"].iloc[:100], out_prefix["bos_bull"].iloc[:100], check_names=False)

    def test_choch_fires_on_first_break_against_no_established_bias(self):
        # a clean uptrend's very first break above a swing high, with no
        # prior bias established, is defined here as a CHoCH (see module
        # docstring's stated assumption)
        n = 100
        t = np.arange(n)
        closes = 100 + t * 0.2 + 1.5 * np.sin(t / 6.0)
        bars = _bars(closes, noise=0.005, seed=31)
        out = compute_market_structure(bars, MarketStructureConfig(pivot_sensitivity=3))
        if out["choch_bull"].any() or out["bos_bull"].any():
            first_bull_break = min(
                (out.index[out["choch_bull"]][0] if out["choch_bull"].any() else pd.Timestamp.max),
                (out.index[out["bos_bull"]][0] if out["bos_bull"].any() else pd.Timestamp.max))
            self.assertTrue(out.loc[first_bull_break, "choch_bull"] or not out.loc[first_bull_break, "bos_bull"])

    def test_each_swing_extreme_fires_at_most_one_break_until_rearmed(self):
        # Using the chronological break_log (not the final pivot_log, which
        # can later overwrite/replace an intermediate pivot that legitimately
        # re-armed a level before a subsequent, stronger same-type pivot
        # replaced it in the log) -- consecutive same-side break events must
        # reference two DIFFERENT levels, since a level is disarmed the
        # instant it fires and only a fresh (kept) pivot can re-arm it.
        rng = np.random.default_rng(44)
        n = 250
        closes = 100 + np.cumsum(rng.normal(0, 0.2, n))
        bars = _bars(closes, noise=0.02, seed=44)
        out = compute_market_structure(bars, MarketStructureConfig(pivot_sensitivity=3))
        for side in ("bull", "bear"):
            levels = [e["level"] for e in out.attrs["break_log"] if e["side"] == side]
            for a, b in zip(levels, levels[1:]):
                self.assertNotEqual(a, b, f"consecutive {side} breaks fired against the same un-rearmed level")


class TestMarketStructureVote(unittest.TestCase):
    def test_not_enough_bars_sits_out(self):
        bars = _bars([100.0] * 4, noise=0.02, seed=51)
        vote = market_structure_vote(bars)
        self.assertEqual(vote.confidence, 0.0)

    def test_confidence_and_direction_always_in_bounds(self):
        rng = np.random.default_rng(53)
        for seed in range(8):
            n = 250
            closes = 100 + np.cumsum(rng.normal(0, 0.2, n))
            bars = _bars(closes, noise=0.02, seed=seed + 300)
            vote = market_structure_vote(bars)
            self.assertGreaterEqual(vote.confidence, 0.0)
            self.assertLessEqual(vote.confidence, 1.0)
            self.assertGreaterEqual(vote.direction, -1.0)
            self.assertLessEqual(vote.direction, 1.0)

    def test_mixed_zone_score_yields_zero_confidence(self):
        cfg = MarketStructureConfig(pivot_sensitivity=3)
        rng = np.random.default_rng(61)
        n = 300
        # pure sideways chop should tend to keep the score inside the Mixed band
        closes = 100 + rng.normal(0, 0.3, n).cumsum() * 0.0 + rng.normal(0, 0.15, n)
        bars = _bars(closes, noise=0.02, seed=61)
        vote = market_structure_vote(bars, cfg=cfg)
        if vote.regime_tag == "Mixed":
            self.assertEqual(vote.confidence, 0.0)

    def test_fresh_break_outranks_plain_continuation_confidence(self):
        # Checking only the single final bar of a long series per trial has
        # low power (a break is a per-bar event, not guaranteed to land
        # exactly on the last bar) -- replay each series at multiple
        # expanding cutoffs, same way this voter is actually called
        # incrementally as new bars arrive.
        rng = np.random.default_rng(71)
        seen_break = False
        for seed in range(12):
            n = 250
            closes = 100 + np.cumsum(rng.normal(0, 0.25, n))
            bars = _bars(closes, noise=0.02, seed=seed + 500)
            for cutoff in range(60, n, 5):
                vote = market_structure_vote(bars.iloc[:cutoff])
                if vote.regime_tag in ("choch_bull", "choch_bear"):
                    seen_break = True
                    self.assertAlmostEqual(vote.confidence, 0.5)
                elif vote.regime_tag in ("bos_bull", "bos_bear"):
                    seen_break = True
                    self.assertAlmostEqual(vote.confidence, 0.45)
                elif vote.confidence > 0:
                    self.assertLessEqual(vote.confidence, 0.35)
        self.assertTrue(seen_break)


if __name__ == "__main__":
    unittest.main()
