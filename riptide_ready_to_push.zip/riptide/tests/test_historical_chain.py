import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))

import pandas as pd

from historical_chain import (load_symbol_from_greek_csvs, list_expirations,
                               build_chain_snapshot, nearest_expiration_chain_snapshot)

COLUMNS = ["OptionKey", "Symbol", "ExpirationDate", "AskPrice", "AskSize", "BidPrice", "BidSize",
           "LastPrice", "PutCall", "StrikePrice", "Volume", "OpenInterest", "UnderlyingPrice",
           "ImpliedVolatility", "Delta", "Gamma", "Vega", "Rho", "Theta", "DataDate"]


def _row(symbol, expiration, put_call, strike, oi, iv, volume, spot, data_date):
    return {
        "OptionKey": f"{symbol}{expiration}{'C' if put_call == 'call' else 'P'}{strike:.2f}{data_date}",
        "Symbol": symbol, "ExpirationDate": expiration, "AskPrice": 1.0, "AskSize": 1, "BidPrice": 0.9,
        "BidSize": 1, "LastPrice": 1.0, "PutCall": put_call, "StrikePrice": strike, "Volume": volume,
        "OpenInterest": oi, "UnderlyingPrice": spot, "ImpliedVolatility": iv, "Delta": 0.5, "Gamma": 0.01,
        "Vega": 0.1, "Rho": 0.01, "Theta": -0.02, "DataDate": data_date,
    }


def _make_greek_csv(path, rows):
    pd.DataFrame(rows, columns=COLUMNS).to_csv(path, index=False)


class TestLoadSymbolFromGreekCsvs(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()

    def test_finds_symbol_split_across_two_files(self):
        f1 = os.path.join(self.tmpdir, "Greek_20260814_OData1.csv")
        f2 = os.path.join(self.tmpdir, "Greek_20260814_OData2.csv")
        _make_greek_csv(f1, [_row("AAPL", "2026-08-17", "call", 220, 500, 0.25, 10, 221.0, "2026-08-14")])
        _make_greek_csv(f2, [
            _row("SPY", "2026-08-17", "call", 776, 1000, 0.15, 50, 776.34, "2026-08-14"),
            _row("SPY", "2026-08-17", "put", 776, 800, 0.16, 40, 776.34, "2026-08-14"),
        ])
        spy = load_symbol_from_greek_csvs([f1, f2], "SPY")
        self.assertEqual(len(spy), 2)
        self.assertTrue((spy["Symbol"] == "SPY").all())

    def test_missing_symbol_raises_with_helpful_message(self):
        f1 = os.path.join(self.tmpdir, "Greek_20260814_OData1.csv")
        _make_greek_csv(f1, [_row("AAPL", "2026-08-17", "call", 220, 500, 0.25, 10, 221.0, "2026-08-14")])
        with self.assertRaises(ValueError) as ctx:
            load_symbol_from_greek_csvs([f1], "SPY")
        self.assertIn("SPY", str(ctx.exception))

    def test_exact_case_sensitive_match(self):
        f1 = os.path.join(self.tmpdir, "Greek_20260814_OData1.csv")
        _make_greek_csv(f1, [_row("spy", "2026-08-17", "call", 776, 1000, 0.15, 50, 776.34, "2026-08-14")])
        with self.assertRaises(ValueError):
            load_symbol_from_greek_csvs([f1], "SPY")


class TestListExpirationsAndBuildSnapshot(unittest.TestCase):
    def setUp(self):
        rows = []
        # two expirations, several strikes each, both calls and puts
        for exp in ("2026-08-17", "2026-08-19"):
            for strike, oi_c, oi_p in ((770, 500, 400), (776, 900, 850), (780, 300, 350)):
                rows.append(_row("SPY", exp, "call", strike, oi_c, 0.15, 20, 776.34, "2026-08-14"))
                rows.append(_row("SPY", exp, "put", strike, oi_p, 0.16, 18, 776.34, "2026-08-14"))
        self.symbol_df = pd.DataFrame(rows, columns=COLUMNS)

    def test_list_expirations_counts_rows_per_expiration(self):
        exps = list_expirations(self.symbol_df)
        self.assertEqual(set(exps["ExpirationDate"]), {"2026-08-17", "2026-08-19"})
        self.assertTrue((exps["n_rows"] == 6).all())

    def test_build_chain_snapshot_pivots_calls_and_puts_by_strike(self):
        snap = build_chain_snapshot(self.symbol_df, "2026-08-17")
        self.assertEqual(len(snap.strike), 3)
        self.assertEqual(snap.spot, 776.34)
        # strike 776's OI should match what was fed in
        idx = list(snap.strike).index(776.0)
        self.assertEqual(snap.call_oi[idx], 900)
        self.assertEqual(snap.put_oi[idx], 850)

    def test_time_to_expiry_reflects_days_between_data_date_and_expiration(self):
        snap = build_chain_snapshot(self.symbol_df, "2026-08-17")  # 3 calendar days out
        expected_years = 3 * 24 * 3600 / (365 * 24 * 3600)
        self.assertAlmostEqual(snap.time_to_expiry_years, expected_years, places=6)

    def test_nearest_expiration_picks_the_soonest(self):
        snap = nearest_expiration_chain_snapshot(self.symbol_df, min_days_out=0)
        # 2026-08-17 is 3 days out, 2026-08-19 is 5 days out -- should pick the sooner one
        expected_years = 3 * 24 * 3600 / (365 * 24 * 3600)
        self.assertAlmostEqual(snap.time_to_expiry_years, expected_years, places=6)

    def test_min_days_out_skips_the_nearest_expiration(self):
        snap = nearest_expiration_chain_snapshot(self.symbol_df, min_days_out=4)
        expected_years = 5 * 24 * 3600 / (365 * 24 * 3600)
        self.assertAlmostEqual(snap.time_to_expiry_years, expected_years, places=6)

    def test_min_days_out_too_far_raises(self):
        with self.assertRaises(ValueError):
            nearest_expiration_chain_snapshot(self.symbol_df, min_days_out=30)

    def test_build_chain_snapshot_unknown_expiration_raises(self):
        with self.assertRaises(ValueError):
            build_chain_snapshot(self.symbol_df, "2099-01-01")


class TestFeedsExistingVoters(unittest.TestCase):
    def test_snapshot_is_usable_by_gamma_positioning_and_vanna_charm(self):
        from gamma_positioning import compute_gamma_profile
        from vanna_charm import compute_vanna_charm

        rows = []
        for strike, oi_c, oi_p in ((770, 500, 400), (776, 900, 850), (780, 300, 350)):
            rows.append(_row("SPY", "2026-08-17", "call", strike, oi_c, 0.15, 20, 776.34, "2026-08-14"))
            rows.append(_row("SPY", "2026-08-17", "put", strike, oi_p, 0.16, 18, 776.34, "2026-08-14"))
        symbol_df = pd.DataFrame(rows, columns=COLUMNS)
        snap = build_chain_snapshot(symbol_df, "2026-08-17")

        profile = compute_gamma_profile(snap)
        self.assertIn(profile.regime, ("positive", "negative"))
        vc = compute_vanna_charm(snap)
        self.assertIsNotNone(vc)


if __name__ == "__main__":
    unittest.main()
