import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))

import numpy as np
import pandas as pd

from helpers import make_market_hours_intraday_history
from daily_review import grade_signals, voter_breakdown, summarize_voter_reliability, review_day


def _make_replay_df():
    idx = pd.date_range("2026-08-14 09:30", periods=6, freq="15min")
    return pd.DataFrame({
        "price": [100.0, 101.0, 99.0, 98.0, 100.0, 100.0],
        "signal": ["CALL", "PUT", "CALL", "PUT", "NONE", "CALL"],
        "direction": [0.4, -0.4, 0.3, -0.3, 0.1, 0.25],
        "confidence": [0.4, 0.4, 0.3, 0.3, 0.1, 0.25],
        # day_close = 102 for all rows -- consistent hindsight target
        "day_close": [102.0] * 6,
        "price_+30m": [101.0, 99.0, 98.0, 100.0, 100.0, np.nan],
    }, index=idx)
    # Row-by-row expected close grading (day_close=102 fixed):
    #   0 CALL @100 -> close 102 > 100 -> correct
    #   1 PUT  @101 -> close 102 > 101 -> price rose -> PUT is WRONG
    #   2 CALL @99  -> close 102 > 99  -> correct
    #   3 PUT  @98  -> close 102 > 98  -> price rose -> PUT is WRONG
    #   4 NONE       -> not graded (NaN)
    #   5 CALL @100 -> close 102 > 100 -> correct


class TestGradeSignals(unittest.TestCase):
    def setUp(self):
        self.df = _make_replay_df()

    def test_none_rows_are_not_graded(self):
        graded = grade_signals(self.df)
        self.assertTrue(np.isnan(graded.loc[graded["signal"] == "NONE", "correct_by_close"].iloc[0]))

    def test_correct_and_incorrect_calls_by_close(self):
        graded = grade_signals(self.df)
        results = graded["correct_by_close"].tolist()
        # indices 0,2,5 are CALL and correct; 1,3 are PUT and wrong (price went up, not down)
        self.assertTrue(results[0])
        self.assertFalse(results[1])
        self.assertTrue(results[2])
        self.assertFalse(results[3])
        self.assertTrue(results[5])

    def test_missing_30m_price_is_nan_not_false(self):
        graded = grade_signals(self.df)
        self.assertTrue(np.isnan(graded["correct_by_30m"].iloc[5]))

    def test_30m_grading_uses_the_30m_column_not_close(self):
        graded = grade_signals(self.df)
        # row 1: PUT @101, price_+30m=99 -> price fell -> PUT correct over 30m
        # even though it was wrong by day close (102) -- the two horizons can disagree
        self.assertTrue(graded["correct_by_30m"].iloc[1])
        self.assertFalse(graded["correct_by_close"].iloc[1])

    def test_no_signals_fired_returns_all_nan_gracefully(self):
        df = _make_replay_df().copy()
        df["signal"] = "NONE"
        graded = grade_signals(df)
        self.assertTrue(graded["correct_by_close"].isna().all())


class TestVoterBreakdownAndReliability(unittest.TestCase):
    def test_agreement_and_correctness_are_tracked_per_voter(self):
        # Fired rows (see _make_replay_df's comment): 0 CALL correct, 1 PUT
        # wrong, 2 CALL correct, 3 PUT wrong, 5 CALL correct -- 3 right, 2
        # wrong by close. One voter always agrees with whatever the
        # ensemble fired, the other always opposes it, at every fired row.
        graded = grade_signals(_make_replay_df())
        idx = graded.index
        fired_rows = [0, 1, 2, 3, 5]
        signal_sign = {0: 1, 1: -1, 2: 1, 3: -1, 5: 1}  # CALL=+1, PUT=-1

        votes = pd.DataFrame([
            {"time": idx[i], "voter": "confirmer", "direction": 0.5 * signal_sign[i],
             "confidence": 0.5, "regime_tag": None}
            for i in fired_rows
        ] + [
            {"time": idx[i], "voter": "opposer", "direction": -0.5 * signal_sign[i],
             "confidence": 0.5, "regime_tag": None}
            for i in fired_rows
        ])
        breakdown = voter_breakdown(graded, votes)
        self.assertFalse(breakdown.empty)

        reliability = summarize_voter_reliability(breakdown)
        # "confirmer" agrees with every fired signal -- inherits the ensemble's
        # own 3-right/2-wrong record exactly (rows 0,2,5 right; 1,3 wrong)
        self.assertEqual(reliability.loc["confirmer", "agreed_and_right"], 3)
        self.assertEqual(reliability.loc["confirmer", "agreed_and_wrong"], 2)
        self.assertEqual(reliability.loc["confirmer", "disagreed_but_signal_wrong"], 0)
        self.assertAlmostEqual(reliability.loc["confirmer", "agree_accuracy"], 0.6)

        # "opposer" never agrees, so agreed_* are both zero -- but it was
        # right both times the fired signal was wrong (rows 1 and 3), which
        # shows up as disagreed_but_signal_wrong
        self.assertEqual(reliability.loc["opposer", "agreed_and_right"], 0)
        self.assertEqual(reliability.loc["opposer", "agreed_and_wrong"], 0)
        self.assertEqual(reliability.loc["opposer", "disagreed_but_signal_wrong"], 2)

    def test_low_confidence_votes_are_excluded(self):
        graded = grade_signals(_make_replay_df())
        idx = graded.index
        votes = pd.DataFrame([
            {"time": idx[0], "voter": "quiet", "direction": 0.9, "confidence": 0.01, "regime_tag": None},
        ])
        breakdown = voter_breakdown(graded, votes)
        self.assertTrue(breakdown.empty)

    def test_empty_breakdown_yields_empty_reliability_with_expected_columns(self):
        reliability = summarize_voter_reliability(pd.DataFrame())
        self.assertTrue(reliability.empty)
        for col in ("agreed_and_right", "agreed_and_wrong", "disagreed_but_signal_wrong", "agree_accuracy"):
            self.assertIn(col, reliability.columns)


class TestReviewDayIntegration(unittest.TestCase):
    def test_loosening_the_threshold_fires_at_least_as_many_signals(self):
        history = make_market_hours_intraday_history(n_days=10, seed=13, start_price=400.0)
        today = make_market_hours_intraday_history(n_days=1, seed=99, start_price=400.0)
        today.index = today.index + (pd.Timestamp("2026-08-14") - today.index[0].normalize())
        minute_df = pd.concat([history, today])

        tight_graded, _, _, _ = review_day(minute_df, "2026-08-14", interval_minutes=30, signal_threshold=0.35)
        loose_graded, _, _, loose_reliability = review_day(minute_df, "2026-08-14", interval_minutes=30,
                                                             signal_threshold=0.05)

        n_tight = (tight_graded["signal"] != "NONE").sum()
        n_loose = (loose_graded["signal"] != "NONE").sum()
        self.assertGreaterEqual(n_loose, n_tight)

    def test_review_day_returns_four_frames_with_expected_shape(self):
        history = make_market_hours_intraday_history(n_days=10, seed=13, start_price=400.0)
        today = make_market_hours_intraday_history(n_days=1, seed=99, start_price=400.0)
        today.index = today.index + (pd.Timestamp("2026-08-14") - today.index[0].normalize())
        minute_df = pd.concat([history, today])

        graded, votes, breakdown, reliability = review_day(minute_df, "2026-08-14", interval_minutes=30,
                                                             signal_threshold=0.05)
        self.assertIn("correct_by_close", graded.columns)
        self.assertIn("voter", votes.columns)
        if not breakdown.empty:
            self.assertIn("agreed_with_fired_signal", breakdown.columns)
        if not reliability.empty:
            self.assertIn("agree_accuracy", reliability.columns)


if __name__ == "__main__":
    unittest.main()
