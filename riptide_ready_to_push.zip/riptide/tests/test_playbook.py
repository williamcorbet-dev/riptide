import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))

import numpy as np
import pandas as pd

from playbook import (
    zigzag_legs, classify_entry_window, evaluate_bounce_opportunity,
    simulate_playbook, TradeLogEntry, append_trade, load_trades,
)


def _bars(times, prices):
    return pd.DataFrame({"Close": prices}, index=pd.DatetimeIndex(times))


class TestZigzagLegs(unittest.TestCase):
    def test_single_clean_uptrend_is_one_leg(self):
        times = pd.date_range("2026-01-05 09:30", periods=10, freq="5min")
        prices = np.linspace(100, 110, 10)
        legs = zigzag_legs(list(times), prices, retrace_pct=0.001)
        self.assertEqual(len(legs), 1)
        self.assertEqual(legs[0]["direction"], "up")

    def test_small_pullback_within_tolerance_does_not_split_the_leg(self):
        # up, up, up, tiny dip (< retrace_pct), up, up -- should stay ONE leg
        prices = np.array([100, 101, 102, 103, 102.98, 104, 105])
        times = pd.date_range("2026-01-05 09:30", periods=len(prices), freq="5min")
        legs = zigzag_legs(list(times), prices, retrace_pct=0.005)
        self.assertEqual(len(legs), 1)
        self.assertAlmostEqual(legs[0]["end_px"], 105)

    def test_large_pullback_splits_into_two_legs(self):
        prices = np.array([100, 102, 104, 106, 100, 98, 96])
        times = pd.date_range("2026-01-05 09:30", periods=len(prices), freq="5min")
        legs = zigzag_legs(list(times), prices, retrace_pct=0.01)
        self.assertGreaterEqual(len(legs), 2)
        self.assertEqual(legs[0]["direction"], "up")
        self.assertEqual(legs[1]["direction"], "down")

    def test_too_short_series_returns_empty(self):
        self.assertEqual(zigzag_legs([pd.Timestamp("2026-01-05 09:30")], np.array([100.0])), [])


class TestClassifyEntryWindow(unittest.TestCase):
    def test_up_move_classified_as_call(self):
        times = pd.date_range("2026-01-05 09:30", "2026-01-05 12:00", freq="5min")
        prices = np.linspace(100, 101, len(times))
        bars = _bars(times, prices)
        result = classify_entry_window(bars, window=("10:00", "11:30"), min_move_pct=0.05)
        self.assertIsNotNone(result)
        self.assertEqual(result["direction"], "CALL")

    def test_tiny_move_returns_none(self):
        times = pd.date_range("2026-01-05 09:30", "2026-01-05 12:00", freq="5min")
        prices = np.full(len(times), 100.0)
        prices[-1] = 100.02  # far below min_move_pct
        bars = _bars(times, prices)
        result = classify_entry_window(bars, window=("10:00", "11:30"), min_move_pct=0.10)
        self.assertIsNone(result)


class TestEvaluateBounceOpportunity(unittest.TestCase):
    def test_recommends_average_down_on_real_countertrend_leg(self):
        # CALL entered at 10:00 near 100; price dips well into the bounce
        # window, giving a real countertrend (down, since trade is CALL)
        # leg for the bounce logic to catch -- then recovers.
        times = pd.date_range("2026-01-05 09:30", "2026-01-05 13:00", freq="5min")
        prices = pd.Series(100.5, index=times)
        prices.loc["2026-01-05 12:00":"2026-01-05 12:30"] = np.linspace(100.5, 99.0, len(
            prices.loc["2026-01-05 12:00":"2026-01-05 12:30"]))
        bars = _bars(times, prices.values)
        result = evaluate_bounce_opportunity(
            bars, direction="CALL", entry_price=100.5,
            as_of=pd.Timestamp("2026-01-05 12:30"), bounce_window=("11:55", "13:00"),
            min_leg_pct=0.10,
        )
        self.assertTrue(result["underwater"])
        self.assertTrue(result["in_bounce_window"])
        self.assertIsNotNone(result["favorable_bounce_price"])
        self.assertTrue(result["recommend_average_down"])

    def test_no_recommendation_outside_bounce_window(self):
        times = pd.date_range("2026-01-05 09:30", "2026-01-05 11:00", freq="5min")
        prices = np.linspace(100.5, 99.0, len(times))  # underwater CALL, but too early
        bars = _bars(times, prices)
        result = evaluate_bounce_opportunity(
            bars, direction="CALL", entry_price=100.5,
            as_of=pd.Timestamp("2026-01-05 11:00"), bounce_window=("11:55", "13:00"),
        )
        self.assertFalse(result["in_bounce_window"])
        self.assertFalse(result["recommend_average_down"])

    def test_no_recommendation_when_not_underwater(self):
        times = pd.date_range("2026-01-05 09:30", "2026-01-05 12:30", freq="5min")
        prices = np.linspace(100.0, 102.0, len(times))  # CALL, and it's working
        bars = _bars(times, prices)
        result = evaluate_bounce_opportunity(
            bars, direction="CALL", entry_price=100.0,
            as_of=pd.Timestamp("2026-01-05 12:30"), bounce_window=("11:55", "13:00"),
        )
        self.assertFalse(result["underwater"])
        self.assertFalse(result["recommend_average_down"])


class TestSimulatePlaybook(unittest.TestCase):
    def _two_day_minute_df(self):
        rows = []
        for day, shape in [("2026-01-05", 1), ("2026-01-06", -1)]:
            times = pd.date_range(f"{day} 09:30", f"{day} 16:00", freq="1min")
            n = len(times)
            # a real entry-window move, then a countertrend dip in the
            # bounce window, then recovers into the close
            prices = np.full(n, 500.0)
            idx = pd.DatetimeIndex(times)
            entry_mask = (idx.time >= pd.Timestamp("10:00").time()) & (idx.time <= pd.Timestamp("11:30").time())
            bounce_mask = (idx.time >= pd.Timestamp("11:55").time()) & (idx.time <= pd.Timestamp("12:30").time())
            prices[entry_mask] = np.linspace(500, 500 + shape * 2, entry_mask.sum())
            prices[idx.time > pd.Timestamp("11:30").time()] = 500 + shape * 2
            prices[bounce_mask] = np.linspace(500 + shape * 2, 500 + shape * 2 - shape * 1.5, bounce_mask.sum())
            after_bounce = idx.time > pd.Timestamp("12:30").time()
            prices[after_bounce] = 500 + shape * 2 - shape * 0.5
            rows.append(pd.DataFrame({"Close": prices}, index=idx))
        return pd.concat(rows)

    def test_produces_one_row_per_day(self):
        minute_df = self._two_day_minute_df()
        result = simulate_playbook(minute_df, min_move_pct=0.05, min_leg_pct=0.05)
        self.assertEqual(len(result), 2)
        self.assertTrue(result["has_setup"].all())

    def test_no_setup_day_is_flagged_and_skipped(self):
        times = pd.date_range("2026-01-05 09:30", "2026-01-05 16:00", freq="5min")
        flat = _bars(times, np.full(len(times), 500.0))
        result = simulate_playbook(flat, min_move_pct=0.10)
        self.assertEqual(len(result), 1)
        self.assertFalse(result.iloc[0]["has_setup"])


class TestTradeLog(unittest.TestCase):
    def test_append_and_load_roundtrip(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "trades.csv")
            entry = TradeLogEntry(date="2026-08-17", entry_time="10:20", direction="CALL",
                                   spy_entry_price=780.5, setup_notes="W shape off the open")
            append_trade(entry, path=path)
            df = load_trades(path=path)
            self.assertEqual(len(df), 1)
            self.assertEqual(df.iloc[0]["direction"], "CALL")

    def test_load_missing_file_returns_empty_frame(self):
        df = load_trades(path="/tmp/_definitely_does_not_exist_trades.csv")
        self.assertEqual(len(df), 0)


if __name__ == "__main__":
    unittest.main()
