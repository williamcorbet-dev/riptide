import os
import sys
import unittest
from datetime import date

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))

from helpers import make_vix_term_structure, make_chain_snapshot
from vol_regime import (term_structure_reading, vix_term_structure_vote, put_call_ratio_vote,
                        put_call_ratio_vote_from_ratio)
from calendar_overlay import calendar_context, calendar_vote, FOMC_DECISION_DATES


class TestVolRegime(unittest.TestCase):
    def test_term_structure_reading_regime_matches_ratio(self):
        df = make_vix_term_structure()
        reading = term_structure_reading(df)
        expected = "backwardation" if reading.ratio > 1.0 else "contango"
        self.assertEqual(reading.regime, expected)

    def test_vix_vote_never_sets_a_direction(self):
        # By design this voter only dampens confidence, it doesn't call direction.
        df = make_vix_term_structure()
        vote = vix_term_structure_vote(df)
        self.assertEqual(vote.direction, 0.0)

    def test_put_call_ratio_extreme_fear_is_bullish_lean(self):
        chain = make_chain_snapshot()
        # Force an extreme put-heavy chain
        chain.put_volume = chain.put_volume * 5 + 1000
        vote = put_call_ratio_vote(chain, extreme_low=0.7, extreme_high=1.3)
        self.assertGreaterEqual(vote.direction, 0.0)

    def test_put_call_ratio_no_call_volume_is_neutral(self):
        chain = make_chain_snapshot()
        chain.call_volume = chain.call_volume * 0
        vote = put_call_ratio_vote(chain)
        self.assertEqual(vote.confidence, 0.0)

    def test_put_call_ratio_from_ratio_matches_chain_based_at_same_ratio(self):
        # A source that hands us the ratio directly (e.g. Alpha Vantage)
        # should score identically to the chain-based path at the same
        # underlying ratio.
        from_ratio_fear = put_call_ratio_vote_from_ratio(1.5)
        self.assertEqual(from_ratio_fear.regime_tag, "extreme_fear")
        self.assertGreater(from_ratio_fear.direction, 0.0)

        from_ratio_complacency = put_call_ratio_vote_from_ratio(0.4)
        self.assertEqual(from_ratio_complacency.regime_tag, "extreme_complacency")
        self.assertLess(from_ratio_complacency.direction, 0.0)

        from_ratio_neutral = put_call_ratio_vote_from_ratio(1.0)
        self.assertEqual(from_ratio_neutral.confidence, 0.0)


class TestCalendarOverlay(unittest.TestCase):
    def test_day_before_fomc_flagged_pre_fomc(self):
        # Jan 28, 2026 is a known FOMC date; Jan 27 is the prior business day.
        self.assertIn(date(2026, 1, 28), FOMC_DECISION_DATES)
        ctx = calendar_context(date(2026, 1, 27))
        self.assertTrue(ctx.is_pre_fomc)
        self.assertFalse(ctx.is_fomc_day)

    def test_fomc_day_itself_flagged(self):
        ctx = calendar_context(date(2026, 1, 28))
        self.assertTrue(ctx.is_fomc_day)

    def test_pre_fomc_vote_is_mildly_bullish(self):
        vote = calendar_vote(date(2026, 1, 27))
        self.assertEqual(vote.direction, 1.0)
        self.assertLess(vote.confidence, 1.0)  # deliberately capped, not a hard override

    def test_fomc_day_vote_has_no_direction(self):
        vote = calendar_vote(date(2026, 1, 28))
        self.assertEqual(vote.direction, 0.0)
        self.assertEqual(vote.regime_tag, "fomc_event_risk")

    def test_ordinary_day_neutral(self):
        vote = calendar_vote(date(2026, 8, 16))
        self.assertEqual(vote.direction, 0.0)
        self.assertEqual(vote.confidence, 0.0)


if __name__ == "__main__":
    unittest.main()
