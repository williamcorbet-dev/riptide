import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))

import numpy as np
import pandas as pd

from webull_data import load_webull_intraday_csv, derive_daily_from_intraday, split_latest_day


def _make_webull_csv(path, n_days=4, bars_per_day=10, start_price=550.0, seed=1):
    """Writes a synthetic CSV in the exact shape of a real Webull intraday
    export (see webull_data.py's module docstring for the real header)."""
    rng = np.random.default_rng(seed)
    rows = []
    price = start_price
    for d in pd.bdate_range("2026-06-01", periods=n_days):
        for i in range(bars_per_day):
            ts = pd.Timestamp(f"{d.date()} 09:30:00") + pd.Timedelta(minutes=i)
            o = price
            c = float(price + rng.normal(0, 0.1))
            h = max(o, c) + abs(float(rng.normal(0, 0.05)))
            l = min(o, c) - abs(float(rng.normal(0, 0.05)))
            vol = int(rng.integers(1000, 5000))
            rows.append([f"{ts.strftime('%Y-%m-%d %H:%M:%S')}-04:00", 123, "SPY",
                         o, c, h, l, vol, "RTH", 123, str(d.date())])
            price = c
    df = pd.DataFrame(rows, columns=["timestamp", "tickerid", "symbol", "open", "close", "high",
                                      "low", "volume", "trading_session", "instrument_id", "day"])
    df.to_csv(path, index=False)


class TestWebullDataLoader(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.path = os.path.join(self.tmpdir, "webull.csv")
        _make_webull_csv(self.path, n_days=4, bars_per_day=10)

    def test_load_returns_standard_ohlcv_shape(self):
        df = load_webull_intraday_csv(self.path)
        self.assertListEqual(list(df.columns), ["Open", "High", "Low", "Close", "Volume"])
        self.assertTrue(df.index.is_monotonic_increasing)
        self.assertIsNone(df.index.tz)
        self.assertEqual(len(df), 40)  # 4 days * 10 bars

    def test_session_filter_excludes_non_rth_by_default(self):
        with open(self.path, "a") as f:
            f.write("2026-06-05 08:00:00-04:00,123,SPY,551.0,551.5,551.6,550.9,1000,PRE,123,2026-06-05\n")
        rth_only = load_webull_intraday_csv(self.path)
        self.assertNotIn(pd.Timestamp("2026-06-05 08:00:00"), rth_only.index)

        with_premarket = load_webull_intraday_csv(self.path, session=None)
        self.assertIn(pd.Timestamp("2026-06-05 08:00:00"), with_premarket.index)

    def test_derive_daily_matches_day_count(self):
        minute = load_webull_intraday_csv(self.path)
        daily = derive_daily_from_intraday(minute)
        self.assertEqual(len(daily), 4)
        self.assertTrue((daily["High"] >= daily["Low"]).all())
        self.assertTrue((daily["High"] >= daily["Open"]).all())
        self.assertTrue((daily["High"] >= daily["Close"]).all())

    def test_split_latest_day_separates_today_from_history(self):
        minute = load_webull_intraday_csv(self.path)
        today, history = split_latest_day(minute)
        self.assertEqual(len(today), 10)
        self.assertEqual(len(history), 30)
        self.assertLess(history.index.max(), today.index.min())

    def test_split_latest_day_handles_empty_input(self):
        empty = pd.DataFrame(columns=["Open", "High", "Low", "Close", "Volume"])
        today, history = split_latest_day(empty)
        self.assertTrue(today.empty)
        self.assertTrue(history.empty)


if __name__ == "__main__":
    unittest.main()
