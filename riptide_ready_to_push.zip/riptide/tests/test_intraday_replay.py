import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))

import pandas as pd

from helpers import make_market_hours_intraday_history, make_chain_snapshot
from intraday_replay import replay_day, replay_day_votes, _checkpoints


class TestCheckpoints(unittest.TestCase):
    def test_includes_first_and_last_bar(self):
        idx = pd.date_range("2026-01-05 09:30", "2026-01-05 16:00", freq="1min")
        day_bars = pd.DataFrame({"Close": 1.0}, index=idx)
        points = _checkpoints(day_bars, interval_minutes=30)
        self.assertEqual(points[0], idx[0])
        self.assertEqual(points[-1], idx[-1])

    def test_empty_day_returns_empty(self):
        empty = pd.DataFrame({"Close": []})
        self.assertEqual(_checkpoints(empty, 30), [])


class TestReplayDay(unittest.TestCase):
    def setUp(self):
        # 60 days of 5-min market-hours history -- last day is the one replayed
        self.minute_df = make_market_hours_intraday_history(n_days=60, freq="5min")

    def _last_day(self):
        return self.minute_df.index.normalize().unique()[-1]

    def test_replay_produces_one_row_per_checkpoint(self):
        target = self._last_day()
        replay = replay_day(self.minute_df, target, interval_minutes=30)
        self.assertGreater(len(replay), 0)
        self.assertIn("signal", replay.columns)
        self.assertTrue(replay["signal"].isin(["CALL", "PUT", "NONE"]).all())

    def test_replay_is_point_in_time_no_lookahead(self):
        # A checkpoint mid-day should only ever see bars up to itself --
        # verify indirectly: the very first checkpoint's price must equal
        # that day's opening bar, not some later value.
        target = self._last_day()
        replay = replay_day(self.minute_df, target, interval_minutes=30)
        day_bars = self.minute_df[self.minute_df.index.normalize() == target]
        self.assertAlmostEqual(replay["price"].iloc[0], float(day_bars["Close"].iloc[0]), places=6)

    def test_raises_on_missing_date(self):
        with self.assertRaises(ValueError):
            replay_day(self.minute_df, "2099-01-01", interval_minutes=30)

    def test_raises_when_no_prior_history(self):
        first_day = self.minute_df.index.normalize().unique()[0]
        with self.assertRaises(ValueError):
            replay_day(self.minute_df, first_day, interval_minutes=30)

    def test_votes_long_format_matches_checkpoint_count(self):
        target = self._last_day()
        replay = replay_day(self.minute_df, target, interval_minutes=60)
        votes = replay_day_votes(self.minute_df, target, interval_minutes=60)
        # every checkpoint should contribute at least one voter row, and
        # the set of checkpoint times should match exactly
        self.assertEqual(set(votes["time"].unique()), set(replay.index))


class TestAdaptiveWeightsSeed(unittest.TestCase):
    """Regression coverage for a real bug (2026-08-21, see daily_reviews.md):
    replay_day()/replay_day_votes() always used fresh, default (all-1.0)
    throwaway weights -- a caller asking to replay "using the current live
    weights" got silently ignored defaults instead, with no error. Added
    adaptive_weights_seed/scenario_history_seed so a caller can explicitly
    opt into using a read-only copy of the real weights for one replay,
    still without ever touching state/ itself."""

    def setUp(self):
        self.minute_df = make_market_hours_intraday_history(n_days=60, freq="5min")
        self.target = self.minute_df.index.normalize().unique()[-1]

    def test_seed_changes_direction_vs_unseeded_default(self):
        votes_default = replay_day_votes(self.minute_df, self.target, interval_minutes=60)
        replay_default = replay_day(self.minute_df, self.target, interval_minutes=60)

        # give one voter an enormous seeded weight -- if the seed is really
        # applied, its direction should dominate the weighted_ensemble sign
        # at every checkpoint where it has nonzero confidence
        boosted_voter = votes_default["voter"].iloc[0]
        seed = {boosted_voter: 1e6}
        votes_seeded = replay_day_votes(self.minute_df, self.target, interval_minutes=60,
                                         adaptive_weights_seed=seed)
        replay_seeded = replay_day(self.minute_df, self.target, interval_minutes=60,
                                    adaptive_weights_seed=seed)

        checked_any = False
        for t in replay_seeded.index:
            if replay_seeded.loc[t, "method"] != "weighted_ensemble":
                continue
            row = votes_seeded[(votes_seeded["time"] == t) & (votes_seeded["voter"] == boosted_voter)]
            if row.empty or row["confidence"].iloc[0] <= 0:
                continue
            checked_any = True
            expected_sign = 1.0 if row["direction"].iloc[0] > 0 else -1.0
            actual_sign = 1.0 if replay_seeded.loc[t, "direction"] > 0 else -1.0
            self.assertEqual(actual_sign, expected_sign,
                              f"seeded weight didn't dominate at {t} as expected")
        self.assertTrue(checked_any, "boosted voter never had confidence>0 -- test didn't exercise anything")

        # and the seeded run should differ from the plain default run somewhere
        self.assertFalse(replay_default["direction"].equals(replay_seeded["direction"]))

    def test_seed_none_keeps_old_default_behavior(self):
        # omitting the new params entirely must behave exactly as before
        r1 = replay_day(self.minute_df, self.target, interval_minutes=60)
        r2 = replay_day(self.minute_df, self.target, interval_minutes=60, adaptive_weights_seed=None,
                         scenario_history_seed=None)
        pd.testing.assert_frame_equal(r1, r2)


class TestReplayNeverTouchesRealState(unittest.TestCase):
    """Regression coverage for a real bug: --chain-dir support was added
    for vanna_charm with a throwaway store, but skew_dynamics was missed
    -- it silently fell back to skew_vote()'s own default, which is the
    REAL persistent state/skew_history.json, breaking this module's
    documented "never touches state/, run it as many times as you like"
    guarantee whenever a chain was supplied. Both are now covered."""

    def setUp(self):
        self.minute_df = make_market_hours_intraday_history(n_days=60, freq="5min")
        self.state_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "state")

    def _real_state_files(self):
        if not os.path.isdir(self.state_dir):
            return set()
        return set(os.listdir(self.state_dir))

    def test_replay_with_chain_does_not_write_real_state_dir(self):
        before = self._real_state_files()
        target = self.minute_df.index.normalize().unique()[-1]
        chain = make_chain_snapshot(spot=550.0)
        replay_day(self.minute_df, target, interval_minutes=60, chain=chain)
        replay_day_votes(self.minute_df, target, interval_minutes=60, chain=chain)
        after = self._real_state_files()
        self.assertEqual(before, after, f"replay wrote into the real state/ dir: {after - before}")

    def test_replay_with_seeds_does_not_write_real_state_dir(self):
        before = self._real_state_files()
        target = self.minute_df.index.normalize().unique()[-1]
        replay_day(self.minute_df, target, interval_minutes=60,
                   adaptive_weights_seed={"technical": 5.0}, scenario_history_seed={"fake=tag": [0.001, -0.002]})
        after = self._real_state_files()
        self.assertEqual(before, after, f"seeded replay wrote into the real state/ dir: {after - before}")


if __name__ == "__main__":
    unittest.main()
