import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))

from risk_management import RiskConfig, size_position, build_exit_plan, DailyRiskTracker


class FakeSignal:
    def __init__(self, signal, confidence, method="empirical_scenario"):
        self.signal = signal
        self.confidence = confidence
        self.method = method


class TestPositionSizing(unittest.TestCase):
    def test_none_signal_sizes_zero(self):
        sig = FakeSignal("NONE", 0.8)
        size = size_position(sig, entry_premium=2.0)
        self.assertEqual(size.contracts, 0)

    def test_zero_premium_sizes_zero(self):
        sig = FakeSignal("CALL", 0.8)
        size = size_position(sig, entry_premium=0.0)
        self.assertEqual(size.contracts, 0)

    def test_higher_confidence_sizes_larger(self):
        cfg = RiskConfig(account_size=25000, max_risk_per_trade_pct=0.02)
        low = size_position(FakeSignal("CALL", 0.2), entry_premium=2.0, cfg=cfg)
        high = size_position(FakeSignal("CALL", 0.95), entry_premium=2.0, cfg=cfg)
        self.assertGreaterEqual(high.contracts, low.contracts)

    def test_weighted_ensemble_method_discounts_size(self):
        cfg = RiskConfig(account_size=100000, max_risk_per_trade_pct=0.02)
        validated = size_position(FakeSignal("CALL", 0.9, method="empirical_scenario"), entry_premium=2.0, cfg=cfg)
        fallback = size_position(FakeSignal("CALL", 0.9, method="weighted_ensemble"), entry_premium=2.0, cfg=cfg)
        self.assertLess(fallback.dollar_risk, validated.dollar_risk)
        self.assertTrue(any("hasn't accumulated" in n for n in fallback.sizing_notes))

    def test_dollar_risk_never_exceeds_max_budget(self):
        cfg = RiskConfig(account_size=10000, max_risk_per_trade_pct=0.01)
        size = size_position(FakeSignal("CALL", 1.0), entry_premium=1.5, cfg=cfg)
        max_budget = cfg.account_size * cfg.max_risk_per_trade_pct
        self.assertLessEqual(size.dollar_risk, max_budget + 1e-6)

    def test_tiny_account_can_size_zero_contracts_with_a_note(self):
        cfg = RiskConfig(account_size=500, max_risk_per_trade_pct=0.01)
        size = size_position(FakeSignal("CALL", 1.0), entry_premium=5.0, cfg=cfg)
        self.assertEqual(size.contracts, 0)
        self.assertTrue(len(size.sizing_notes) > 0)


class TestExitPlan(unittest.TestCase):
    def test_stop_below_entry_target_above(self):
        plan = build_exit_plan(entry_premium=2.0)
        self.assertLess(plan.stop_loss_price, 2.0)
        self.assertGreater(plan.profit_target_price, 2.0)

    def test_trailing_trigger_between_entry_and_target(self):
        plan = build_exit_plan(entry_premium=2.0)
        self.assertGreater(plan.trailing_stop_trigger_price, 2.0)


class TestDailyRiskTracker(unittest.TestCase):
    def test_starts_able_to_trade(self):
        tracker = DailyRiskTracker(RiskConfig(account_size=25000, daily_loss_limit_pct=0.03))
        self.assertTrue(tracker.can_enter_new_trade())

    def test_circuit_breaker_trips_after_large_loss(self):
        cfg = RiskConfig(account_size=25000, daily_loss_limit_pct=0.03)
        tracker = DailyRiskTracker(cfg)
        tracker.record_trade_result(-800)  # 3.2% of 25000, past the 3% limit
        self.assertFalse(tracker.can_enter_new_trade())
        self.assertTrue(tracker.status()["circuit_breaker_tripped"])

    def test_gains_do_not_trip_breaker(self):
        tracker = DailyRiskTracker(RiskConfig(account_size=25000, daily_loss_limit_pct=0.03))
        tracker.record_trade_result(1000)
        self.assertTrue(tracker.can_enter_new_trade())


if __name__ == "__main__":
    unittest.main()
