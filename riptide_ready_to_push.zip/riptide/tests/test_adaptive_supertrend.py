import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))

import numpy as np
import pandas as pd

from adaptive_supertrend import compute_adaptive_supertrend, adaptive_supertrend_vote, AdaptiveSupertrendConfig


def _bars(closes, noise=0.02, seed=1, start="2026-08-14 09:30"):
    rng = np.random.default_rng(seed)
    n = len(closes)
    closes = np.asarray(closes, dtype=float) + rng.normal(0, noise, n)
    open_ = np.roll(closes, 1); open_[0] = closes[0]
    high = np.maximum(open_, closes) + np.abs(rng.normal(0, noise, n))
    low = np.minimum(open_, closes) - np.abs(rng.normal(0, noise, n))
    idx = pd.date_range(start, periods=n, freq="1min")
    return pd.DataFrame({"Open": open_, "High": high, "Low": low, "Close": closes}, index=idx)


class TestAdaptiveSupertrend(unittest.TestCase):
    def test_zero_volatility_series_has_no_valid_atr_and_stays_neutral(self):
        # a perfectly flat series has True Range == 0 every bar -> atr == 0
        # everywhere -> validAtr is False (Pine requires atr > 0.0), so the
        # state machine correctly never leaves its initial "waiting" state.
        bars = _bars([100.0] * 30, noise=0.0)
        out = compute_adaptive_supertrend(bars)
        self.assertTrue((out["trend"] == 0).all())

    def test_first_trend_read_uses_close_vs_source_once_atr_is_valid(self):
        # once real range appears (atr > 0), the very first trend read should
        # be the prev_trend==0 fallback: close >= source(hl2) ? 1 : -1
        bars = _bars(100 + np.zeros(30), noise=0.05, seed=21)
        out = compute_adaptive_supertrend(bars)
        first_valid_idx = out["trend"].to_numpy().nonzero()[0]
        self.assertTrue(len(first_valid_idx) > 0)
        i = first_valid_idx[0]
        source_i = (bars["High"].iloc[i] + bars["Low"].iloc[i]) / 2
        expected = 1 if bars["Close"].iloc[i] >= source_i else -1
        self.assertEqual(out["trend"].iloc[i], expected)

    def test_clean_strong_uptrend_ends_bullish_no_late_flip(self):
        n = 80
        closes = 100 + np.arange(n) * 0.3  # steady, strong climb
        bars = _bars(closes, noise=0.01, seed=2)
        out = compute_adaptive_supertrend(bars)
        self.assertEqual(out["trend"].iloc[-1], 1)
        # once trend turns bullish partway through a clean climb, it should not
        # flip back to bearish for the rest of a still-climbing series
        first_bullish = out.index[out["trend"] == 1]
        self.assertTrue(len(first_bullish) > 0)
        after = out.loc[first_bullish[0]:]
        self.assertTrue((after["trend"] == 1).all())

    def test_clean_strong_downtrend_ends_bearish(self):
        n = 80
        closes = 100 - np.arange(n) * 0.3
        bars = _bars(closes, noise=0.01, seed=3)
        out = compute_adaptive_supertrend(bars)
        self.assertEqual(out["trend"].iloc[-1], -1)

    def test_factors_stay_within_configured_bounds(self):
        rng = np.random.default_rng(5)
        n = 200
        closes = 100 + np.cumsum(rng.normal(0, 0.3, n))
        bars = _bars(closes, noise=0.02, seed=5)
        cfg = AdaptiveSupertrendConfig(minimum_factor=0.75, maximum_factor=6.0)
        out = compute_adaptive_supertrend(bars, cfg)
        bf = out["bullish_factor"].dropna()
        sf = out["bearish_factor"].dropna()
        self.assertTrue((bf >= cfg.minimum_factor - 1e-9).all())
        self.assertTrue((bf <= cfg.maximum_factor + 1e-9).all())
        self.assertTrue((sf >= cfg.minimum_factor - 1e-9).all())
        self.assertTrue((sf <= cfg.maximum_factor + 1e-9).all())

    def test_sample_confidence_ramps_toward_one_with_more_bars(self):
        n = 300
        # a long choppy-but-net-up series gives plenty of established bullish bars
        rng = np.random.default_rng(9)
        closes = 100 + np.cumsum(rng.normal(0.02, 0.15, n))
        bars = _bars(closes, noise=0.01, seed=9)
        cfg = AdaptiveSupertrendConfig(minimum_samples=25, sample_length=150)
        out = compute_adaptive_supertrend(bars, cfg)
        early_conf = out["bullish_sample_confidence"].iloc[30]
        late_conf = out["bullish_sample_confidence"].iloc[-1]
        self.assertGreaterEqual(late_conf, early_conf)
        self.assertLessEqual(late_conf, 1.0)

    def test_no_lookahead_first_n_bars_identical_when_series_extended(self):
        rng = np.random.default_rng(11)
        n = 120
        closes = 100 + np.cumsum(rng.normal(0, 0.2, n))
        bars_full = _bars(closes, noise=0.01, seed=11)
        bars_prefix = bars_full.iloc[:80].copy()

        out_full = compute_adaptive_supertrend(bars_full)
        out_prefix = compute_adaptive_supertrend(bars_prefix)

        pd.testing.assert_series_equal(
            out_full["trend"].iloc[:80], out_prefix["trend"].iloc[:80], check_names=False)
        pd.testing.assert_series_equal(
            out_full["super_trend"].iloc[:80], out_prefix["super_trend"].iloc[:80], check_names=False)

    def test_bounce_reaction_only_fires_within_active_trend(self):
        rng = np.random.default_rng(13)
        n = 150
        closes = 100 + np.cumsum(rng.normal(0.01, 0.25, n))
        bars = _bars(closes, noise=0.02, seed=13)
        out = compute_adaptive_supertrend(bars)
        bullish_reactions = out[out["bullish_bounce_reaction"]]
        bearish_reactions = out[out["bearish_bounce_reaction"]]
        if len(bullish_reactions) > 0:
            self.assertTrue((bullish_reactions["trend"] == 1).all())
        if len(bearish_reactions) > 0:
            self.assertTrue((bearish_reactions["trend"] == -1).all())

    def test_output_length_matches_input(self):
        bars = _bars(100 + np.arange(50) * 0.05, seed=17)
        out = compute_adaptive_supertrend(bars)
        self.assertEqual(len(out), len(bars))


class TestAdaptiveSupertrendVote(unittest.TestCase):
    def test_not_enough_bars_sits_out(self):
        bars = _bars([100.0] * 4, noise=0.02, seed=31)
        vote = adaptive_supertrend_vote(bars)
        self.assertEqual(vote.confidence, 0.0)

    def test_confidence_and_direction_always_in_bounds(self):
        rng = np.random.default_rng(33)
        for seed in range(8):
            n = 200
            closes = 100 + np.cumsum(rng.normal(0, 0.2, n))
            bars = _bars(closes, noise=0.02, seed=seed + 100)
            vote = adaptive_supertrend_vote(bars)
            self.assertGreaterEqual(vote.confidence, 0.0)
            self.assertLessEqual(vote.confidence, 1.0)
            self.assertGreaterEqual(vote.direction, -1.0)
            self.assertLessEqual(vote.direction, 1.0)

    def test_confidence_tiers_match_regime_tag(self):
        # confidence must follow the documented tiers exactly: a fresh
        # shift (0.55) > a bounce reaction (0.45) > plain continuation
        # (<=0.35), regardless of which specific bar produces which tag.
        rng = np.random.default_rng(43)
        seen_tags = set()
        for seed in range(40):
            n = 250
            closes = 100 + np.cumsum(rng.normal(0, 0.25, n))
            bars = _bars(closes, noise=0.02, seed=seed + 200)
            vote = adaptive_supertrend_vote(bars)
            seen_tags.add(vote.regime_tag)
            if vote.regime_tag in ("bullish_shift", "bearish_shift"):
                self.assertAlmostEqual(vote.confidence, 0.55)
            elif vote.regime_tag in ("bullish_bounce", "bearish_bounce"):
                self.assertAlmostEqual(vote.confidence, 0.45)
            elif vote.regime_tag in ("uptrend", "downtrend"):
                self.assertLessEqual(vote.confidence, 0.35)
        # sanity: across 40 random walks, this should have actually exercised
        # more than just the trivial "not enough data" path
        self.assertTrue(len(seen_tags - {None}) > 0)


if __name__ == "__main__":
    unittest.main()
