import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))

import numpy as np

from helpers import make_skewed_chain_snapshot
from skew_dynamics import SkewReading, compute_skew, SkewHistoryStore, skew_vote


class TestComputeSkew(unittest.TestCase):
    def test_finds_otm_strikes_on_either_side_of_spot(self):
        chain = make_skewed_chain_snapshot(spot=550.0, skew_level=0.05)
        reading = compute_skew(chain)
        self.assertGreater(reading.call_25d_strike, chain.spot)
        self.assertLess(reading.put_25d_strike, chain.spot)

    def test_skew_reflects_put_minus_call_iv(self):
        chain = make_skewed_chain_snapshot(spot=550.0, skew_level=0.08, seed=3)
        reading = compute_skew(chain)
        # skew should be roughly the constructed offset (small noise tolerance)
        self.assertAlmostEqual(reading.skew, 0.08, delta=0.02)

    def test_flatter_chain_has_smaller_skew(self):
        steep = compute_skew(make_skewed_chain_snapshot(skew_level=0.10, seed=1))
        flat = compute_skew(make_skewed_chain_snapshot(skew_level=0.01, seed=1))
        self.assertGreater(steep.skew, flat.skew)

    def test_as_of_sets_the_reading_date(self):
        chain = make_skewed_chain_snapshot()
        reading = compute_skew(chain, as_of=__import__("datetime").date(2026, 1, 5))
        self.assertEqual(reading.date, "2026-01-05")


class TestSkewHistoryStore(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.store = SkewHistoryStore(path=os.path.join(self.tmpdir, "skew_history.json"))

    def test_record_and_history_roundtrip(self):
        for i, skew in enumerate([0.03, 0.04, 0.05]):
            reading = SkewReading(date=f"2026-01-0{i+1}", spot=550.0,
                                   call_25d_strike=555.0, call_25d_iv=0.15,
                                   put_25d_strike=545.0, put_25d_iv=0.15 + skew,
                                   skew=skew)
            self.store.record(reading)
        hist = self.store.history()
        self.assertEqual(hist, [0.03, 0.04, 0.05])

    def test_same_date_overwrites_not_duplicates(self):
        for skew in [0.03, 0.09]:
            reading = SkewReading(date="2026-01-01", spot=550.0,
                                   call_25d_strike=555.0, call_25d_iv=0.15,
                                   put_25d_strike=545.0, put_25d_iv=0.15 + skew,
                                   skew=skew)
            self.store.record(reading)
        hist = self.store.history()
        self.assertEqual(hist, [0.09])

    def test_lookback_days_truncates(self):
        for i in range(30):
            reading = SkewReading(date=f"2026-02-{i+1:02d}", spot=550.0,
                                   call_25d_strike=555.0, call_25d_iv=0.15,
                                   put_25d_strike=545.0, put_25d_iv=0.16,
                                   skew=0.01 * i)
            self.store.record(reading)
        hist = self.store.history(lookback_days=5)
        self.assertEqual(len(hist), 5)
        self.assertEqual(hist, [0.25, 0.26, 0.27, 0.28, 0.29])

    def test_persistence_across_new_store_instances(self):
        reading = SkewReading(date="2026-01-01", spot=550.0,
                               call_25d_strike=555.0, call_25d_iv=0.15,
                               put_25d_strike=545.0, put_25d_iv=0.20, skew=0.05)
        self.store.record(reading)
        reloaded = SkewHistoryStore(path=self.store.path)
        self.assertEqual(reloaded.history(), [0.05])


class TestSkewVote(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.store = SkewHistoryStore(path=os.path.join(self.tmpdir, "skew_history.json"))

    def _seed_history(self, skew_levels, start_day=1):
        for i, skew in enumerate(skew_levels):
            reading = SkewReading(date=f"2026-03-{start_day + i:02d}", spot=550.0,
                                   call_25d_strike=555.0, call_25d_iv=0.15,
                                   put_25d_strike=545.0, put_25d_iv=0.15 + skew,
                                   skew=skew)
            self.store.record(reading)

    def test_not_enough_history_is_honestly_neutral(self):
        self._seed_history([0.05] * 5)
        chain = make_skewed_chain_snapshot(skew_level=0.05)
        vote = skew_vote(chain, store=self.store, min_history=20)
        self.assertEqual(vote.confidence, 0.0)
        self.assertIn("reason", vote.detail)
        self.assertIn("only", vote.detail["reason"])

    def test_steepening_skew_is_bearish(self):
        # trailing history hovers with normal day-to-day noise around 0.03...
        jittered = [0.03 + 0.004 * np.sin(i) for i in range(25)]
        self._seed_history(jittered)
        # ...today's chain is much steeper (higher relative put IV)
        chain = make_skewed_chain_snapshot(skew_level=0.15, seed=1)
        vote = skew_vote(chain, store=self.store, min_history=20)
        self.assertGreater(vote.confidence, 0.0)
        self.assertLess(vote.direction, 0.0)

    def test_flattening_skew_is_bullish(self):
        jittered = [0.10 + 0.004 * np.sin(i) for i in range(25)]
        self._seed_history(jittered)
        chain = make_skewed_chain_snapshot(skew_level=0.01, seed=1)
        vote = skew_vote(chain, store=self.store, min_history=20)
        self.assertGreater(vote.confidence, 0.0)
        self.assertGreater(vote.direction, 0.0)

    def test_no_variation_in_history_is_neutral(self):
        self._seed_history([0.05] * 25)
        chain = make_skewed_chain_snapshot(skew_level=0.05, seed=1)
        vote = skew_vote(chain, store=self.store, min_history=20)
        # today's skew matches a flat, zero-variance history -- no z-score possible
        self.assertEqual(vote.direction, 0.0)

    def test_direction_bounded(self):
        self._seed_history([0.02, 0.03, 0.04, 0.02, 0.05] * 5)
        chain = make_skewed_chain_snapshot(skew_level=0.25, seed=1)
        vote = skew_vote(chain, store=self.store, min_history=20)
        self.assertGreaterEqual(vote.direction, -1.0)
        self.assertLessEqual(vote.direction, 1.0)

    def test_vote_records_todays_reading_into_store(self):
        self._seed_history([0.03] * 25)
        chain = make_skewed_chain_snapshot(skew_level=0.06, seed=1)
        skew_vote(chain, store=self.store, min_history=20)
        # today's date should now be present in the store
        import datetime
        today = datetime.date.today().isoformat()
        self.assertIn(today, self.store.readings)

    def test_as_of_records_under_the_given_date_not_wall_clock_today(self):
        # Without threading as_of through, a walk-forward backtest that
        # simulates many historical days in one process would stamp every
        # reading under the real wall-clock date and silently overwrite
        # itself each iteration -- see backtest.py's chain_by_date walk.
        import datetime
        self._seed_history([0.03] * 25)
        chain = make_skewed_chain_snapshot(skew_level=0.06, seed=1)
        simulated_day = datetime.date(2022, 3, 1)
        skew_vote(chain, store=self.store, min_history=20, as_of=simulated_day)
        self.assertIn("2022-03-01", self.store.readings)
        self.assertNotIn(datetime.date.today().isoformat(), self.store.readings)

    def test_walk_forward_days_accumulate_distinct_entries(self):
        # The actual scenario this protects: several distinct simulated
        # days, each passed as `as_of`, must produce separate entries --
        # not all collapse into one same-date overwrite.
        import datetime
        chain = make_skewed_chain_snapshot(skew_level=0.05, seed=2)
        for i in range(5):
            skew_vote(chain, store=self.store, min_history=20,
                      as_of=datetime.date(2026, 3, 1) + datetime.timedelta(days=i))
        self.assertEqual(len(self.store.history()), 5)


if __name__ == "__main__":
    unittest.main()
