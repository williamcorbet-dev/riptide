import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))

import numpy as np
import pandas as pd

from price_action import compute_price_action, price_action_vote, PriceActionConfig


def _bars(closes, noise=0.02, seed=1, start="2026-08-14 09:30"):
    rng = np.random.default_rng(seed)
    n = len(closes)
    closes = np.asarray(closes, dtype=float) + rng.normal(0, noise, n)
    open_ = np.roll(closes, 1); open_[0] = closes[0]
    high = np.maximum(open_, closes) + np.abs(rng.normal(0, noise, n))
    low = np.minimum(open_, closes) - np.abs(rng.normal(0, noise, n))
    idx = pd.date_range(start, periods=n, freq="1min")
    return pd.DataFrame({"Open": open_, "High": high, "Low": low, "Close": closes}, index=idx)


def _set_row(df, i, o, h, l, c):
    df.iloc[i, df.columns.get_loc("Open")] = o
    df.iloc[i, df.columns.get_loc("High")] = h
    df.iloc[i, df.columns.get_loc("Low")] = l
    df.iloc[i, df.columns.get_loc("Close")] = c


def _append_bar(df, o, h, l, c):
    row = pd.DataFrame({"Open": [o], "High": [h], "Low": [l], "Close": [c]},
                        index=[df.index[-1] + pd.Timedelta(minutes=1)])
    return pd.concat([df, row])


class TestComputePriceAction(unittest.TestCase):
    def test_output_length_matches_input(self):
        bars = _bars(100 + np.arange(30) * 0.05, seed=17)
        out = compute_price_action(bars)
        self.assertEqual(len(out), len(bars))

    def test_no_lookahead_first_n_bars_identical_when_series_extended(self):
        rng = np.random.default_rng(11)
        n = 120
        closes = 100 + np.cumsum(rng.normal(0, 0.2, n))
        bars_full = _bars(closes, noise=0.05, seed=11)
        bars_prefix = bars_full.iloc[:80].copy()

        out_full = compute_price_action(bars_full)
        out_prefix = compute_price_action(bars_prefix)

        for col in ["is_nr", "breakout_up", "breakout_down", "sweep_high", "sweep_low",
                    "up_streak", "down_streak"]:
            pd.testing.assert_series_equal(
                out_full[col].iloc[:80], out_prefix[col].iloc[:80], check_names=False)

    def test_tight_bar_after_wider_bars_flagged_as_nr(self):
        bars = _bars(100 + np.zeros(19), noise=0.15, seed=41)
        _set_row(bars, 18, 100.00, 100.05, 99.98, 100.02)  # much tighter range than the noisy warmup
        out = compute_price_action(bars, PriceActionConfig(compression_window=7))
        self.assertTrue(bool(out["is_nr"].iloc[18]))

    def test_breakout_up_fires_after_squeeze_bar(self):
        bars = _bars(100 + np.zeros(20), noise=0.15, seed=41)
        _set_row(bars, 18, 100.00, 100.05, 99.98, 100.02)  # squeeze
        _set_row(bars, 19, 100.05, 100.60, 100.03, 100.55)  # wide expansion, closes well above squeeze high
        out = compute_price_action(bars, PriceActionConfig(compression_window=7))
        self.assertTrue(bool(out["breakout_up"].iloc[19]))
        self.assertFalse(bool(out["breakout_down"].iloc[19]))

    def test_breakout_down_fires_after_squeeze_bar(self):
        bars = _bars(100 + np.zeros(20), noise=0.15, seed=42)
        _set_row(bars, 18, 100.00, 100.05, 99.98, 100.02)  # squeeze
        _set_row(bars, 19, 99.95, 99.97, 99.40, 99.45)  # wide expansion, closes well below squeeze low
        out = compute_price_action(bars, PriceActionConfig(compression_window=7))
        self.assertTrue(bool(out["breakout_down"].iloc[19]))
        self.assertFalse(bool(out["breakout_up"].iloc[19]))

    def test_squeeze_alone_without_expansion_does_not_break_out(self):
        bars = _bars(100 + np.zeros(19), noise=0.15, seed=41)
        _set_row(bars, 18, 100.00, 100.05, 99.98, 100.02)
        out = compute_price_action(bars, PriceActionConfig(compression_window=7))
        self.assertFalse(bool(out["breakout_up"].iloc[18]))
        self.assertFalse(bool(out["breakout_down"].iloc[18]))

    def test_sweep_high_detected_on_pierce_and_reject(self):
        bars = _bars(100 + np.zeros(13), noise=0.1, seed=51)
        for _ in range(6):
            bars = _append_bar(bars, 100.00, 100.10, 99.90, 100.00)
        bars = _append_bar(bars, 100.05, 100.60, 99.90, 99.95)  # pierces above the recent high, closes back below
        out = compute_price_action(bars, PriceActionConfig(sweep_lookback=6))
        self.assertTrue(bool(out["sweep_high"].iloc[-1]))
        self.assertFalse(bool(out["sweep_low"].iloc[-1]))

    def test_sweep_low_detected_on_pierce_and_reject(self):
        bars = _bars(100 + np.zeros(13), noise=0.1, seed=52)
        for _ in range(6):
            bars = _append_bar(bars, 100.00, 100.10, 99.90, 100.00)
        bars = _append_bar(bars, 99.95, 100.10, 99.40, 100.05)  # pierces below the recent low, closes back above
        out = compute_price_action(bars, PriceActionConfig(sweep_lookback=6))
        self.assertTrue(bool(out["sweep_low"].iloc[-1]))
        self.assertFalse(bool(out["sweep_high"].iloc[-1]))

    def test_momentum_thrust_streak_counts_consecutive_qualifying_closes(self):
        bars = _bars(100 + np.zeros(13), noise=0.1, seed=61)
        thrust_closes = [100.0, 100.5, 101.0, 101.5, 102.0, 102.5, 103.0]
        prev_close = 100.0
        for c in thrust_closes:
            bars = _append_bar(bars, prev_close, c + 0.05, prev_close - 0.05, c)
            prev_close = c
        out = compute_price_action(bars, PriceActionConfig(thrust_min_consecutive=4))
        streak = out["up_streak"].to_numpy()[-7:]
        self.assertTrue((np.diff(streak) == 1).all())  # strictly incrementing across the thrust
        self.assertEqual(streak[-1], 6)

    def test_doji_bar_resets_the_streak(self):
        bars = _bars(100 + np.zeros(13), noise=0.05, seed=62)
        bars = _append_bar(bars, 100.0, 100.55, 99.95, 100.5)
        bars = _append_bar(bars, 100.5, 101.05, 100.45, 101.0)
        bars = _append_bar(bars, 101.0, 101.01, 100.99, 101.001)  # doji: tiny body, breaks the streak
        bars = _append_bar(bars, 101.001, 101.55, 100.95, 101.5)
        out = compute_price_action(bars, PriceActionConfig(thrust_body_atr_floor_mult=0.1))
        streak = out["up_streak"].to_numpy()
        self.assertGreaterEqual(streak[-3], 1)  # the bar right before the doji did extend the streak
        self.assertEqual(streak[-2], 0)         # the doji bar itself does not extend it
        self.assertEqual(streak[-1], 1)         # the streak restarts fresh right after the doji


class TestPriceActionVote(unittest.TestCase):
    def test_not_enough_bars_sits_out(self):
        bars = _bars([100.0] * 4, noise=0.02, seed=31)
        vote = price_action_vote(bars)
        self.assertEqual(vote.confidence, 0.0)

    def test_not_enough_resampled_bars_sits_out(self):
        bars = _bars(100 + np.arange(60) * 0.05, noise=0.02, seed=32)  # 60 1-min -> 12 5-min bars, below 20
        vote = price_action_vote(bars)
        self.assertEqual(vote.confidence, 0.0)
        self.assertIn("5min bars", vote.detail.get("reason", ""))

    def test_confidence_and_direction_always_in_bounds(self):
        rng = np.random.default_rng(33)
        for seed in range(10):
            n = 300
            closes = 100 + np.cumsum(rng.normal(0, 0.25, n))
            bars = _bars(closes, noise=0.03, seed=seed + 100)
            vote = price_action_vote(bars)
            self.assertGreaterEqual(vote.confidence, 0.0)
            self.assertLessEqual(vote.confidence, 1.0)
            self.assertGreaterEqual(vote.direction, -1.0)
            self.assertLessEqual(vote.direction, 1.0)

    def test_confidence_tiers_match_regime_tag(self):
        rng = np.random.default_rng(43)
        seen_tags = set()
        for seed in range(40):
            n = 300
            closes = 100 + np.cumsum(rng.normal(0, 0.3, n))
            bars = _bars(closes, noise=0.03, seed=seed + 200)
            vote = price_action_vote(bars)
            seen_tags.add(vote.regime_tag)
            if vote.regime_tag in ("liquidity_sweep_high", "liquidity_sweep_low"):
                self.assertAlmostEqual(vote.confidence, 0.5)
            elif vote.regime_tag in ("range_expansion_up", "range_expansion_down"):
                self.assertAlmostEqual(vote.confidence, 0.4)
            elif vote.regime_tag in ("momentum_thrust_up", "momentum_thrust_down"):
                self.assertAlmostEqual(vote.confidence, 0.45)
            elif vote.regime_tag in ("momentum_thrust_up_continuation", "momentum_thrust_down_continuation"):
                self.assertGreaterEqual(vote.confidence, 0.15)
                self.assertLess(vote.confidence, 0.45)
            elif vote.regime_tag == "range_compressing":
                self.assertEqual(vote.confidence, 0.0)
        self.assertTrue(len(seen_tags - {None}) > 0)

    def test_sweep_vote_wired_end_to_end_with_priority_over_other_reads(self):
        # same sweep scenario as the compute-level test, driven through
        # price_action_vote with resample_rule="1min" (an identity resample
        # on already-1min data) so the full vote path, including priority
        # ordering, is exercised.
        bars = _bars(100 + np.zeros(13), noise=0.1, seed=51)
        for _ in range(6):
            bars = _append_bar(bars, 100.00, 100.10, 99.90, 100.00)
        bars = _append_bar(bars, 100.05, 100.60, 99.90, 99.95)
        vote = price_action_vote(bars, cfg=PriceActionConfig(sweep_lookback=6), resample_rule="1min")
        self.assertEqual(vote.regime_tag, "liquidity_sweep_high")
        self.assertEqual(vote.direction, -1.0)
        self.assertAlmostEqual(vote.confidence, 0.5)

    def test_pure_squeeze_with_no_breakout_is_zero_confidence_not_a_guess(self):
        bars = _bars(100 + np.zeros(20), noise=0.15, seed=41)
        _set_row(bars, 19, 100.00, 100.05, 99.98, 100.02)  # last bar itself is the tight squeeze -- no breakout yet
        vote = price_action_vote(bars, cfg=PriceActionConfig(compression_window=7), resample_rule="1min")
        self.assertEqual(vote.regime_tag, "range_compressing")
        self.assertEqual(vote.confidence, 0.0)
        self.assertEqual(vote.direction, 0.0)


if __name__ == "__main__":
    unittest.main()
