import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))

import numpy as np
import pandas as pd

from vwap_reversion import vwap_reversion_vote


def _bars(anchors, noise=0.01, seed=1, start="2026-08-19 09:30", volume=50000.0):
    rng = np.random.default_rng(seed)
    total_minutes = anchors[-1][0] + 1
    minutes = np.arange(total_minutes)
    xp = [a[0] for a in anchors]
    fp = [a[1] for a in anchors]
    close = np.interp(minutes, xp, fp) + rng.normal(0, noise, total_minutes)
    open_ = np.roll(close, 1)
    open_[0] = close[0]
    high = np.maximum(open_, close) + np.abs(rng.normal(0, noise / 2, total_minutes))
    low = np.minimum(open_, close) - np.abs(rng.normal(0, noise / 2, total_minutes))
    idx = pd.date_range(start, periods=total_minutes, freq="1min")
    return pd.DataFrame({"Open": open_, "High": high, "Low": low, "Close": close,
                          "Volume": volume}, index=idx)


class TestVwapReversionVote(unittest.TestCase):
    def test_not_enough_bars_sits_out(self):
        bars = _bars([(0, 100), (5, 100.5)])
        vote = vwap_reversion_vote(bars)
        self.assertEqual(vote.confidence, 0.0)
        self.assertEqual(vote.direction, 0.0)

    def test_bounce_off_vwap_from_above_is_bullish(self):
        # ramps up early (pulls VWAP up), pulls back down TO vwap, then
        # ticks back up over the last few bars -- a bounce off VWAP support.
        anchors = [(0, 100), (20, 103), (35, 100.3), (39, 100.6)]
        bars = _bars(anchors, noise=0.005)
        vote = vwap_reversion_vote(bars)
        if vote.regime_tag == "vwap_bounce_support":
            self.assertGreater(vote.direction, 0)
            self.assertGreater(vote.confidence, 0)
        else:
            # noise can occasionally break the exact shape -- at minimum it
            # must not read this as a confident SELL right into a support bounce
            self.assertGreaterEqual(vote.direction, -0.05)

    def test_bounce_off_vwap_from_below_is_bearish(self):
        anchors = [(0, 100), (20, 97), (35, 99.7), (39, 99.4)]
        bars = _bars(anchors, noise=0.005)
        vote = vwap_reversion_vote(bars)
        if vote.regime_tag == "vwap_bounce_resistance":
            self.assertLess(vote.direction, 0)
            self.assertGreater(vote.confidence, 0)
        else:
            self.assertLessEqual(vote.direction, 0.05)

    def test_far_above_vwap_fades_bearish_but_capped(self):
        # a strong one-directional ramp with no pullback: price ends up
        # well above its own session VWAP.
        anchors = [(0, 100), (39, 106)]
        bars = _bars(anchors, noise=0.01)
        vote = vwap_reversion_vote(bars)
        self.assertEqual(vote.regime_tag, "extended_from_vwap")
        self.assertLess(vote.direction, 0)  # fades back toward VWAP
        self.assertLessEqual(vote.confidence, 0.4)  # capped well below the bounce case

    def test_far_below_vwap_fades_bullish_but_capped(self):
        anchors = [(0, 100), (39, 94)]
        bars = _bars(anchors, noise=0.01)
        vote = vwap_reversion_vote(bars)
        self.assertEqual(vote.regime_tag, "extended_from_vwap")
        self.assertGreater(vote.direction, 0)
        self.assertLessEqual(vote.confidence, 0.4)

    def test_flat_at_vwap_is_neutral(self):
        anchors = [(0, 100), (39, 100.05)]
        bars = _bars(anchors, noise=0.001)
        vote = vwap_reversion_vote(bars)
        self.assertLessEqual(abs(vote.direction), 0.6)  # shouldn't be a confident call either way

    def test_confidence_and_direction_always_in_bounds(self):
        rng = np.random.default_rng(42)
        for seed in range(10):
            anchors = [(0, 100), (39, float(100 + rng.normal(0, 3)))]
            bars = _bars(anchors, noise=0.02, seed=seed)
            vote = vwap_reversion_vote(bars)
            self.assertGreaterEqual(vote.confidence, 0.0)
            self.assertLessEqual(vote.confidence, 1.0)
            self.assertGreaterEqual(vote.direction, -1.0)
            self.assertLessEqual(vote.direction, 1.0)


if __name__ == "__main__":
    unittest.main()
