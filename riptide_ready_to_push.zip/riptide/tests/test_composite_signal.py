import os
import sys
import tempfile
import unittest
from datetime import date

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))

from helpers import (make_daily_ohlcv, make_intraday_ohlcv, make_market_hours_intraday_history,
                      make_chain_snapshot, make_vix_term_structure, make_leader_and_target_dict)
from composite_signal import SignalInputs, generate_signal
from scenario_engine import ScenarioStore, AdaptiveWeights
from skew_dynamics import SkewHistoryStore


class TestCompositeSignalFullStack(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.store = ScenarioStore(path=os.path.join(self.tmpdir, "s.json"))
        self.weights = AdaptiveWeights(path=os.path.join(self.tmpdir, "w.json"))
        self.skew_store = SkewHistoryStore(path=os.path.join(self.tmpdir, "skew.json"))

    def test_daily_only_inputs_produce_a_signal(self):
        daily = make_daily_ohlcv()
        inputs = SignalInputs(daily_df=daily, today=date(2026, 8, 16))
        sig = generate_signal(inputs, scenario_store=self.store, adaptive_weights=self.weights)
        self.assertIn(sig.signal, ("CALL", "PUT", "NONE"))
        voter_names = {v.name for v in sig.votes}
        self.assertIn("technical", voter_names)
        self.assertIn("hurst", voter_names)
        self.assertIn("hmm_regime", voter_names)
        self.assertIn("fomc_calendar", voter_names)
        self.assertIn("gamma_regime", voter_names)  # present as a neutral no-opinion vote

    def test_gamma_regime_sits_out_without_chain(self):
        daily = make_daily_ohlcv()
        inputs = SignalInputs(daily_df=daily, today=date(2026, 8, 16))
        sig = generate_signal(inputs, scenario_store=self.store, adaptive_weights=self.weights)
        gamma_vote = next(v for v in sig.votes if v.name == "gamma_regime")
        self.assertEqual(gamma_vote.confidence, 0.0)

    def test_put_call_ratio_fires_from_standalone_ratio_without_a_chain(self):
        # No `chain` supplied (so gamma/vanna/skew still sit out), but a
        # pre-computed put/call ratio is -- e.g. from Alpha Vantage, which
        # gives that ratio for free even without a paid full options chain.
        daily = make_daily_ohlcv()
        inputs = SignalInputs(daily_df=daily, today=date(2026, 8, 16), put_call_ratio=1.5)
        sig = generate_signal(inputs, scenario_store=self.store, adaptive_weights=self.weights)
        voter_names = {v.name for v in sig.votes}
        self.assertIn("put_call_ratio", voter_names)
        pcr_vote = next(v for v in sig.votes if v.name == "put_call_ratio")
        self.assertEqual(pcr_vote.regime_tag, "extreme_fear")
        gamma_vote = next(v for v in sig.votes if v.name == "gamma_regime")
        self.assertEqual(gamma_vote.confidence, 0.0)  # still sits out -- no chain

    def test_full_stack_with_all_optional_inputs(self):
        daily = make_daily_ohlcv()
        spot = float(daily["Close"].iloc[-1])
        intraday_history = make_market_hours_intraday_history(n_days=60, start_price=spot)
        intraday_today = make_market_hours_intraday_history(n_days=1, seed=999, start_price=spot).iloc[:40]
        chain = make_chain_snapshot(spot=spot)
        vix_df = make_vix_term_structure(n=len(daily), start_date=daily.index[0])
        leader_data = make_leader_and_target_dict(daily["Close"])

        inputs = SignalInputs(
            daily_df=daily, intraday_df=intraday_today, intraday_history=intraday_history,
            chain=chain, vix_df=vix_df, leader_data=leader_data, skew_store=self.skew_store,
            today=date(2026, 8, 16), hours_to_close=2.5,
        )
        sig = generate_signal(inputs, scenario_store=self.store, adaptive_weights=self.weights)

        voter_names = {v.name for v in sig.votes}
        expected = {"technical", "intraday_technical", "hurst", "hmm_regime", "fomc_calendar",
                    "gamma_regime", "vanna_charm", "put_call_ratio", "vix_term_structure",
                    "candlesticks", "time_of_day", "cross_asset_leadlag", "skew_dynamics",
                    "support_resistance", "vwap_reversion", "mfi_divergence", "adaptive_supertrend"}
        self.assertEqual(voter_names, expected)
        self.assertIn(sig.signal, ("CALL", "PUT", "NONE"))
        self.assertGreaterEqual(sig.confidence, 0.0)
        self.assertLessEqual(sig.confidence, 1.0)

    def test_gamma_negative_regime_follows_technical_direction(self):
        from composite_signal import gamma_regime_vote
        from gamma_positioning import GammaProfile
        import pandas as pd

        profile = GammaProfile(total_gex=-1e8, zero_gamma_flip=545.0, max_pain_strike=552.0,
                                spot=550.0, regime="negative", distance_to_flip_pct=0.01,
                                strike_gex=pd.DataFrame({"strike": [550.0], "gex": [-1.0]}))
        vote = gamma_regime_vote(profile, technical_direction=0.7, atr=3.0)
        self.assertAlmostEqual(vote.direction, 0.7, delta=1e-6)

    def test_gamma_positive_regime_fades_toward_max_pain(self):
        from composite_signal import gamma_regime_vote
        from gamma_positioning import GammaProfile
        import pandas as pd

        # spot above max pain -> fade should pull direction negative (down toward max pain)
        profile = GammaProfile(total_gex=1e8, zero_gamma_flip=545.0, max_pain_strike=540.0,
                                spot=550.0, regime="positive", distance_to_flip_pct=0.02,
                                strike_gex=pd.DataFrame({"strike": [550.0], "gex": [1.0]}))
        vote = gamma_regime_vote(profile, technical_direction=0.7, atr=3.0)
        self.assertLess(vote.direction, 0.7)  # damped/pulled down from pure technical direction


class TestGrindGate(unittest.TestCase):
    """Regression coverage for the low-volatility 'grind' gate added
    2026-08-21 (see daily_reviews.md): a 30-day empirical check found the
    ensemble fires MORE often during a real intraday grind (75% vs 49%)
    and is LESS accurate when it does (46.2% vs 56.8% vs +30min) --
    several voters normalize by ATR/realized range, so a near-zero
    denominator during a genuine low-vol coil inflates confidence instead
    of reducing it. generate_signal() now downgrades a CALL/PUT to NONE
    when find_reversals.is_grinding_now() flags the current moment.

    is_grinding_now() itself has its own dedicated tests (see
    tests/test_find_reversals.py, including two no-lookahead checks) --
    these tests isolate the WIRING (does generate_signal correctly apply
    the override and leave everything else untouched) by mocking that
    flag directly, rather than re-deriving a genuinely flat 1-min series
    that also happens to make some voter fire a confident CALL/PUT."""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.store = ScenarioStore(path=os.path.join(self.tmpdir, "s.json"))
        self.weights = AdaptiveWeights(path=os.path.join(self.tmpdir, "w.json"))

    def _signal_with_mocked_grind_flag(self, grinding):
        from unittest.mock import patch
        daily = make_daily_ohlcv()
        intraday = make_intraday_ohlcv(n_days=1, bars_per_day=60, freq="1min")
        inputs = SignalInputs(daily_df=daily, intraday_df=intraday, today=date(2026, 8, 16))
        with patch("composite_signal.is_grinding_now", return_value=grinding):
            return generate_signal(inputs, scenario_store=self.store, adaptive_weights=self.weights)

    def test_grind_flag_true_suppresses_a_fired_call_or_put_to_none(self):
        unsuppressed = self._signal_with_mocked_grind_flag(grinding=False)
        if unsuppressed.signal == "NONE":
            self.skipTest("synthetic data didn't happen to fire a CALL/PUT to suppress")
        gated = self._signal_with_mocked_grind_flag(grinding=True)
        self.assertEqual(gated.signal, "NONE")
        self.assertTrue(gated.grind_suppressed)
        # direction/confidence/votes must be UNCHANGED -- the gate only
        # touches the tradeable classification, not the underlying read
        # (record_outcome()/learning still needs the real values)
        self.assertEqual(gated.direction, unsuppressed.direction)
        self.assertEqual(gated.confidence, unsuppressed.confidence)
        self.assertEqual(len(gated.votes), len(unsuppressed.votes))

    def test_grind_flag_false_is_a_no_op(self):
        sig = self._signal_with_mocked_grind_flag(grinding=False)
        self.assertFalse(sig.grind_suppressed)

    def test_grind_flag_true_is_a_no_op_when_already_none(self):
        # if the ensemble already landed on NONE for its own reasons, the
        # gate has nothing to suppress -- grind_suppressed should stay False
        from unittest.mock import patch
        with patch("composite_signal.is_grinding_now", return_value=True):
            daily = make_daily_ohlcv()
            inputs = SignalInputs(daily_df=daily, today=date(2026, 8, 16))  # no intraday_df at all
            sig = generate_signal(inputs, scenario_store=self.store, adaptive_weights=self.weights)
        self.assertFalse(sig.grind_suppressed)

    def test_daily_only_backtest_never_calls_the_grind_check(self):
        """No intraday_df -> the gate must be a complete no-op, so the
        already-validated 3-year daily backtest is unaffected by this."""
        from unittest.mock import patch
        daily = make_daily_ohlcv()
        inputs = SignalInputs(daily_df=daily, today=date(2026, 8, 16))
        with patch("composite_signal.is_grinding_now") as mock_grind:
            generate_signal(inputs, scenario_store=self.store, adaptive_weights=self.weights)
            mock_grind.assert_not_called()


if __name__ == "__main__":
    unittest.main()
