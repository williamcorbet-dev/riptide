import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))

import numpy as np
import pandas as pd

from anchored_vwap_swings import (compute_anchored_swing_avwaps, anchored_vwap_swings_vote,
                                   AnchoredVwapSwingsConfig)


def _bars(closes, noise=0.02, seed=1, start="2026-08-14 09:30", volume=1000.0):
    rng = np.random.default_rng(seed)
    n = len(closes)
    closes = np.asarray(closes, dtype=float) + rng.normal(0, noise, n)
    open_ = np.roll(closes, 1); open_[0] = closes[0]
    high = np.maximum(open_, closes) + np.abs(rng.normal(0, noise, n))
    low = np.minimum(open_, closes) - np.abs(rng.normal(0, noise, n))
    vol = np.full(n, volume) + rng.normal(0, volume * 0.1, n)
    vol = np.clip(vol, 1.0, None)
    idx = pd.date_range(start, periods=n, freq="1min")
    return pd.DataFrame({"Open": open_, "High": high, "Low": low, "Close": closes, "Volume": vol}, index=idx)


class TestComputeAnchoredSwingAvwaps(unittest.TestCase):
    def test_output_length_matches_input(self):
        bars = _bars(100 + np.arange(50) * 0.05, seed=17)
        out = compute_anchored_swing_avwaps(bars, AnchoredVwapSwingsConfig(pivot_left=3, pivot_right=2))
        self.assertEqual(len(out), len(bars))

    def test_no_anchors_before_any_pivot_confirms(self):
        # a monotonic climb has no interior pivot high/low candidate that
        # beats both neighbors on both sides until enough bars exist
        bars = _bars(100 + np.arange(15) * 0.1, noise=0.001, seed=2)
        cfg = AnchoredVwapSwingsConfig(pivot_left=8, pivot_right=5, minimum_prominence_atr=0.1)
        out = compute_anchored_swing_avwaps(bars, cfg)
        self.assertTrue(np.isnan(out["high_anchor_bar"].to_numpy()).all())

    def test_clean_v_shape_confirms_a_low_anchor_and_avwap_trails_above_it(self):
        n = 60
        down = 100 - np.arange(30) * 0.3
        up = down[-1] + np.arange(30) * 0.3
        closes = np.concatenate([down, up])
        bars = _bars(closes, noise=0.01, seed=3)
        cfg = AnchoredVwapSwingsConfig(pivot_left=5, pivot_right=5, minimum_prominence_atr=0.5,
                                        minimum_bars_between_same_type=5)
        out = compute_anchored_swing_avwaps(bars, cfg)
        self.assertTrue(out["low_pivot_confirmed"].any())
        confirmed_idx = out.index[out["low_pivot_confirmed"]][0]
        after = out.loc[confirmed_idx:]
        # once anchored, the low-origin AVWAP must be a real number for every
        # bar after the anchor confirms (continuous cumulative weighting)
        self.assertFalse(after["low_avwap"].isna().any())

    def test_no_lookahead_first_n_bars_identical_when_series_extended(self):
        rng = np.random.default_rng(11)
        n = 120
        closes = 100 + np.cumsum(rng.normal(0, 0.2, n))
        bars_full = _bars(closes, noise=0.01, seed=11)
        bars_prefix = bars_full.iloc[:80].copy()
        cfg = AnchoredVwapSwingsConfig(pivot_left=4, pivot_right=3, minimum_prominence_atr=0.3)

        out_full = compute_anchored_swing_avwaps(bars_full, cfg)
        out_prefix = compute_anchored_swing_avwaps(bars_prefix, cfg)

        pd.testing.assert_series_equal(
            out_full["high_avwap"].iloc[:80], out_prefix["high_avwap"].iloc[:80], check_names=False)
        pd.testing.assert_series_equal(
            out_full["low_avwap"].iloc[:80], out_prefix["low_avwap"].iloc[:80], check_names=False)
        pd.testing.assert_series_equal(
            out_full["high_pivot_confirmed"].iloc[:80], out_prefix["high_pivot_confirmed"].iloc[:80],
            check_names=False)

    def test_pivot_only_confirms_after_right_bars_have_printed(self):
        # a sharp single-bar spike at index 10 must not be reflected in any
        # anchor until at least pivot_right bars later
        n = 30
        closes = np.full(n, 100.0)
        bars = _bars(closes, noise=0.0, seed=5)
        bars.iloc[10, bars.columns.get_loc("High")] = 110.0
        bars.iloc[10, bars.columns.get_loc("Close")] = 109.0
        cfg = AnchoredVwapSwingsConfig(pivot_left=5, pivot_right=5, minimum_prominence_atr=0.1)
        out = compute_anchored_swing_avwaps(bars, cfg)
        for t in range(10, 15):
            self.assertTrue(np.isnan(out["high_anchor_bar"].iloc[t]))

    def test_pair_converged_when_curves_are_close(self):
        # a long, nearly flat series after an initial small swing should
        # eventually pull the two anchored VWAPs close together
        n = 150
        rng = np.random.default_rng(23)
        closes = 100 + np.concatenate([np.linspace(0, 2, 20), np.zeros(n - 20)]) + rng.normal(0, 0.02, n)
        bars = _bars(closes, noise=0.01, seed=23)
        cfg = AnchoredVwapSwingsConfig(pivot_left=4, pivot_right=3, minimum_prominence_atr=0.3,
                                        minimum_bars_between_same_type=5)
        out = compute_anchored_swing_avwaps(bars, cfg)
        # not asserting convergence is guaranteed (depends on random pivots),
        # just that the column is well-formed booleans with no crash
        self.assertEqual(out["pair_converged"].dtype, bool)


class TestAnchoredVwapSwingsVote(unittest.TestCase):
    def test_not_enough_bars_sits_out(self):
        bars = _bars([100.0] * 4, noise=0.02, seed=31)
        vote = anchored_vwap_swings_vote(bars)
        self.assertEqual(vote.confidence, 0.0)

    def test_not_enough_resampled_bars_sits_out(self):
        # 60 raw 1-min bars resamples to only 12 5-min bars, below the 20 minimum
        bars = _bars(100 + np.arange(60) * 0.05, noise=0.02, seed=32)
        vote = anchored_vwap_swings_vote(bars)
        self.assertEqual(vote.confidence, 0.0)
        self.assertIn("5min bars", vote.detail.get("reason", ""))

    def test_confidence_and_direction_always_in_bounds(self):
        rng = np.random.default_rng(33)
        for seed in range(8):
            n = 250
            closes = 100 + np.cumsum(rng.normal(0, 0.2, n))
            bars = _bars(closes, noise=0.02, seed=seed + 100)
            vote = anchored_vwap_swings_vote(bars)
            self.assertGreaterEqual(vote.confidence, 0.0)
            self.assertLessEqual(vote.confidence, 1.0)
            self.assertGreaterEqual(vote.direction, -1.0)
            self.assertLessEqual(vote.direction, 1.0)

    def test_confidence_tiers_match_regime_tag(self):
        rng = np.random.default_rng(43)
        seen_tags = set()
        for seed in range(40):
            n = 300
            closes = 100 + np.cumsum(rng.normal(0, 0.25, n))
            bars = _bars(closes, noise=0.02, seed=seed + 200)
            vote = anchored_vwap_swings_vote(bars)
            seen_tags.add(vote.regime_tag)
            if vote.regime_tag in ("broke_above_both", "broke_below_both"):
                self.assertAlmostEqual(vote.confidence, 0.5)
            elif vote.regime_tag in ("above_both", "below_both"):
                self.assertAlmostEqual(vote.confidence, 0.25)
            elif vote.regime_tag in ("between_avwaps", "avwap_converged"):
                self.assertEqual(vote.confidence, 0.0)
        self.assertTrue(len(seen_tags - {None}) > 0)

    def test_converged_pair_is_neutral_not_a_guess(self):
        n = 150
        rng = np.random.default_rng(23)
        closes = 100 + np.concatenate([np.linspace(0, 2, 20), np.zeros(n - 20)]) + rng.normal(0, 0.02, n)
        bars = _bars(closes, noise=0.01, seed=23)
        vote = anchored_vwap_swings_vote(bars)
        if vote.regime_tag == "avwap_converged":
            self.assertEqual(vote.direction, 0.0)
            self.assertEqual(vote.confidence, 0.0)


if __name__ == "__main__":
    unittest.main()
