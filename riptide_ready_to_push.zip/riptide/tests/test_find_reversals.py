import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))

import numpy as np
import pandas as pd

from find_reversals import find_reversals_one_day, find_reversals, is_grinding_now


def _grind_then_reversal_day(grind_minutes=60, grind_move_per_min=-0.025, tick=0.02,
                              reversal_move_per_min=0.09, reversal_minutes=40, seed=5):
    """A synthetic session: an hour of slow, low-volatility decline (a real
    'grind', matching the 2026-08-21 case this module was built from), then
    a genuine multi-bar rally the other way. Should be picked up as one
    low_to_high reversal near the end of the grind."""
    rng = np.random.default_rng(seed)
    idx = pd.date_range("2026-01-05 09:30", periods=grind_minutes + reversal_minutes, freq="1min")
    price = 500.0
    closes = []
    for i in range(grind_minutes):
        price += grind_move_per_min + rng.normal(0, tick)
        closes.append(price)
    for i in range(reversal_minutes):
        price += reversal_move_per_min + rng.normal(0, tick)
        closes.append(price)
    closes = np.array(closes)
    highs = closes + np.abs(rng.normal(0, tick, len(closes)))
    lows = closes - np.abs(rng.normal(0, tick, len(closes)))
    opens = np.roll(closes, 1)
    opens[0] = closes[0]
    return pd.DataFrame({"Open": opens, "High": highs, "Low": lows, "Close": closes,
                          "Volume": 1000}, index=idx)


def _flat_day(n_minutes=390, tick=0.015, seed=9):
    """A whole session of tiny back-and-forth ticks, no real leg either
    direction -- should never qualify as a reversal (fails the minimum-leg
    check both ways), used to check the detector doesn't fire on pure
    noise."""
    rng = np.random.default_rng(seed)
    idx = pd.date_range("2026-01-06 09:30", periods=n_minutes, freq="1min")
    closes = 500.0 + np.cumsum(rng.normal(0, tick, n_minutes))
    highs = closes + np.abs(rng.normal(0, tick, n_minutes))
    lows = closes - np.abs(rng.normal(0, tick, n_minutes))
    opens = np.roll(closes, 1)
    opens[0] = closes[0]
    return pd.DataFrame({"Open": opens, "High": highs, "Low": lows, "Close": closes,
                          "Volume": 1000}, index=idx)


class TestFindReversalsOneDay(unittest.TestCase):
    def test_detects_grind_then_reversal(self):
        day = _grind_then_reversal_day()
        found = find_reversals_one_day(day)
        self.assertTrue(len(found) >= 1, "should detect the engineered grind-then-reversal")
        r = found[0]
        self.assertEqual(r["kind"], "low_to_high")
        self.assertLess(r["entry_leg"], 0)
        self.assertGreater(r["exit_leg"], 0)

    def test_no_false_positive_on_flat_noise(self):
        day = _flat_day()
        found = find_reversals_one_day(day)
        self.assertEqual(found, [], "pure noise with no real leg either side should never qualify")

    def test_find_reversals_splits_by_day(self):
        d1 = _grind_then_reversal_day(seed=1)
        d2 = _grind_then_reversal_day(seed=2)
        d2.index = d2.index + pd.Timedelta(days=1)
        combined = pd.concat([d1, d2])
        out = find_reversals(combined)
        self.assertGreaterEqual(len(out), 2)
        self.assertEqual(out["time"].dt.normalize().nunique(), 2)


class TestIsGrindingNow(unittest.TestCase):
    def test_true_during_a_real_grind(self):
        day = _grind_then_reversal_day()
        now = day.index[45]  # well inside the 60-minute grind
        self.assertTrue(is_grinding_now(day, now))

    def test_false_during_the_fast_reversal_leg(self):
        day = _grind_then_reversal_day()
        now = day.index[-1]  # end of the fast 40-minute reversal leg
        self.assertFalse(is_grinding_now(day, now))

    def test_none_when_not_enough_trailing_data(self):
        day = _grind_then_reversal_day()
        now = day.index[3]  # only a few bars in
        self.assertIsNone(is_grinding_now(day, now))

    def test_no_lookahead_same_result_whether_or_not_future_bars_exist(self):
        """The core safety property: is_grinding_now(df, t) must depend only
        on bars up to and including t. Truncating the dataframe to end
        exactly at t (dropping everything after) must give the identical
        answer as passing the full day -- otherwise a live caller who only
        has data up to `now` would get a different read than a backtest
        that (accidentally) had the whole day available."""
        day = _grind_then_reversal_day()
        now = day.index[70]
        full_day_result = is_grinding_now(day, now)
        truncated = day[day.index <= now]
        truncated_result = is_grinding_now(truncated, now)
        self.assertEqual(full_day_result, truncated_result)

    def test_no_lookahead_across_every_checkpoint(self):
        """Same property, swept across many checkpoints in one day (the
        style used throughout this project's other no-lookahead tests)."""
        day = _grind_then_reversal_day()
        for i in range(35, len(day), 10):
            now = day.index[i]
            full = is_grinding_now(day, now)
            truncated_result = is_grinding_now(day[day.index <= now], now)
            self.assertEqual(full, truncated_result, f"mismatch at checkpoint {i} ({now})")


if __name__ == "__main__":
    unittest.main()
