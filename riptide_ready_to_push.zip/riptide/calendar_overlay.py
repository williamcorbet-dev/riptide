"""
FOMC calendar overlay: the pre-FOMC announcement drift is one of the more
robust documented anomalies in equity markets (Lucca & Moench, NY Fed) --
SPX has historically drifted up from the close before an FOMC decision to
the close after, and a disproportionate share of annual index returns
concentrates in just ~8 trading days a year. Some later research (see
README sources) finds the effect has weakened/become less reliable since
roughly the mid-2010s as it became widely known and arbitraged -- so this
is implemented as a modest nudge, not a hard override, and confidence is
kept deliberately capped.

Fully backtestable: meeting dates are public record and don't require any
live data feed.
"""

from dataclasses import dataclass
from datetime import date, timedelta

from voters import Vote

# Verified against federalreserve.gov's published tentative schedule.
# Extend this list as the Fed publishes further years.
FOMC_DECISION_DATES = [
    # 2024
    date(2024, 1, 31), date(2024, 3, 20), date(2024, 5, 1), date(2024, 6, 12),
    date(2024, 7, 31), date(2024, 9, 18), date(2024, 11, 7), date(2024, 12, 18),
    # 2025
    date(2025, 1, 29), date(2025, 3, 19), date(2025, 5, 7), date(2025, 6, 18),
    date(2025, 7, 30), date(2025, 9, 17), date(2025, 10, 29), date(2025, 12, 10),
    # 2026
    date(2026, 1, 28), date(2026, 3, 18), date(2026, 4, 29), date(2026, 6, 17),
    date(2026, 7, 29), date(2026, 9, 16), date(2026, 10, 28), date(2026, 12, 9),
]


@dataclass
class CalendarContext:
    is_pre_fomc: bool       # today is the trading day immediately before a decision
    is_fomc_day: bool       # today IS the decision day
    is_post_fomc: bool      # today is the trading day immediately after a decision
    days_to_next_fomc: int


def calendar_context(today: date, decision_dates=None) -> CalendarContext:
    decision_dates = sorted(decision_dates or FOMC_DECISION_DATES)
    is_fomc_day = today in decision_dates

    is_pre_fomc = any(0 < (d - today).days <= 3 and _is_prior_business_day(today, d) for d in decision_dates)
    is_post_fomc = any(0 < (today - d).days <= 3 and _is_prior_business_day(d, today) for d in decision_dates)

    future = [d for d in decision_dates if d >= today]
    days_to_next = (future[0] - today).days if future else -1

    return CalendarContext(is_pre_fomc=is_pre_fomc, is_fomc_day=is_fomc_day,
                            is_post_fomc=is_post_fomc, days_to_next_fomc=days_to_next)


def _is_prior_business_day(d1: date, d2: date) -> bool:
    """True if d1 is the most recent weekday before d2 (handles the common
    case without pulling in a full holiday calendar -- good enough for a
    ~1-3 day window around FOMC dates)."""
    cursor = d2 - timedelta(days=1)
    while cursor.weekday() >= 5:  # skip weekends
        cursor -= timedelta(days=1)
    return cursor == d1


def calendar_vote(today: date, decision_dates=None, drift_confidence: float = 0.35) -> Vote:
    """Pre-FOMC day -> modest bullish nudge (historical drift direction).
    FOMC decision day itself and the day after -> flagged as elevated
    event-risk with no directional lean (the post-announcement reaction is
    driven by the outcome, not by calendar position, and can go either way
    hard -- this is exactly the kind of day where 1DTE gamma risk is
    highest, so the ensemble should know to be cautious here even without
    a direction to offer).
    """
    ctx = calendar_context(today, decision_dates)

    if ctx.is_pre_fomc:
        return Vote(
            name="fomc_calendar", direction=1.0, confidence=drift_confidence,
            regime_tag="pre_fomc_drift",
            detail={"note": "historical pre-FOMC drift is bullish-biased but has "
                             "weakened since the mid-2010s as it became widely known; "
                             "kept as a light nudge, not a primary driver",
                    "days_to_next_fomc": ctx.days_to_next_fomc},
        )

    if ctx.is_fomc_day or ctx.is_post_fomc:
        return Vote(
            name="fomc_calendar", direction=0.0, confidence=0.0,
            regime_tag="fomc_event_risk",
            detail={"note": "decision day or immediate aftermath -- outcome-driven, "
                             "no directional prior; elevated gamma/vol risk for 1DTE",
                    "is_fomc_day": ctx.is_fomc_day, "is_post_fomc": ctx.is_post_fomc},
        )

    return Vote(name="fomc_calendar", direction=0.0, confidence=0.0,
                 detail={"days_to_next_fomc": ctx.days_to_next_fomc})
