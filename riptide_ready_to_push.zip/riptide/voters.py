"""
Standardized "voter" interface.

Every methodology in this system (technical composite, gamma regime,
vanna/charm, VIX term structure, put/call ratio, HMM regime, Hurst regime,
FOMC calendar, multi-timeframe candlestick confluence, time-of-day
fingerprint, and any Phase-2 modules added later) produces a `Vote`. No
single voter decides the trade -- the scenario engine (scenario_engine.py)
combines all of them.

Design intent: each voter should be honest about its own uncertainty. A
voter that has nothing useful to say right now should return low
confidence / neutral direction rather than forcing an opinion -- the whole
point of the ensemble is that weak, noisy voters get diluted rather than
each acting as its own trade trigger.
"""

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class Vote:
    name: str                      # voter identifier, e.g. "gamma_regime"
    direction: float                # -1 (max bearish) .. +1 (max bullish)
    confidence: float               # 0 (no opinion) .. 1 (maximally confident)
    regime_tag: Optional[str] = None  # e.g. "trending" / "mean_reverting" / "event" / None
    detail: dict = field(default_factory=dict)  # free-form breakdown for transparency/debugging
    live_only: bool = False         # True if this voter needs live data that can't be backtested for free

    def __post_init__(self):
        self.direction = float(max(-1.0, min(1.0, self.direction)))
        self.confidence = float(max(0.0, min(1.0, self.confidence)))

    @property
    def weighted_direction(self) -> float:
        """direction scaled by confidence -- a voter with confidence 0
        contributes nothing regardless of how strong its direction is."""
        return self.direction * self.confidence


def neutral_vote(name: str, reason: str = "insufficient data") -> Vote:
    """Convenience constructor for a voter that has no opinion right now."""
    return Vote(name=name, direction=0.0, confidence=0.0, detail={"reason": reason})
