"""
VWAP reversion / rejection voter.

Why this exists (2026-08-19 case, see daily_reviews.md): Will pointed out
two very concrete bad calls from the same session -- the ensemble fired
CALL at 11:00am, exactly today's high, and PUT at 11:40am, exactly where
price bounced hard off session VWAP acting as support. Both are the same
underlying mechanism: `intraday_technical` and `candlesticks` are
trend-CONFIRMING voters (EMA spread, MACD, RSI, recent candle direction).
They need a move already underway to reach high confidence, which means
they structurally tend to hit peak conviction right as that move is
exhausting -- chasing tops and bottoms instead of anticipating them. At
11:00am `intraday_technical` was maximally bullish (confidence 1.0) right
at the top of the run; at 11:40am it was maximally bearish (confidence
1.0) right at the VWAP bounce. Nothing in the ensemble was looking at
"how stretched is price from a level real flow actually respects" or
"did price just get rejected at that level" -- this voter is that read.

Session VWAP (`indicator.session_vwap`) is a good level for this
specifically because, unlike swing-based support/resistance
(`support_resistance.py`), it needs no multi-bar confirmation lag -- it's
a cumulative volume-weighted average known the instant a new bar prints,
so a bounce right at VWAP can be read in real time instead of ~15 minutes
after the fact.

Two distinct, independently-gated reads:

1. Bounce/rejection at VWAP -- price approached VWAP and the last few
   bars are ticking back away from it without a real break through. Same
   shape as support_resistance.py's bounce_support/bounce_resistance, but
   keyed to VWAP specifically.
2. Overextension fade -- price sitting unusually far from VWAP relative
   to today's OWN realized range (not the multi-week daily ATR used
   elsewhere, which doesn't reflect what today has actually done) is
   over-extended more often than it's the start of a fresh leg. This
   component is deliberately capped well below the bounce case's
   confidence -- it should be able to dent a maximally-confident momentum
   read, not flip a genuine breakout into a fade call on its own.

Honest limitations, stated up front:
  - This is a today-only, real-time-only read (needs intraday_df); it has
    no opinion at all in the daily-only backtest path, same as
    intraday_technical/candlesticks/support_resistance.
  - Early in the session VWAP is noisy (few bars behind it) and today's
    realized range is small and not yet representative -- both components
    are gated to zero confidence until enough bars exist (see
    MIN_BARS_FOR_VWAP/MIN_BARS_FOR_RANGE).
  - This is new as of 2026-08-19, validated so far only against a replay
    of that one real session (see daily_reviews.md) -- it starts in
    AdaptiveWeights at the same default weight as every other voter and
    has to earn trust the same way, not something hand-tuned to make that
    one day look better in hindsight.
"""

import numpy as np
import pandas as pd

from indicator import session_vwap
from voters import Vote, neutral_vote

MIN_BARS_FOR_VWAP = 15   # ~15 bars before session VWAP has seen enough volume to be stable
MIN_BARS_FOR_RANGE = 15  # ~15 bars before today's own high-low range means anything


def vwap_reversion_vote(intraday_df: pd.DataFrame, lookback_bars: int = 4,
                         bounce_proximity_mult: float = 0.35,
                         extension_cap_mult: float = 2.5) -> Vote:
    """`bounce_proximity_mult`/`extension_cap_mult` are both in units of
    today's own realized (High.max() - Low.min()) range, not ATR -- see
    module docstring for why."""
    if intraday_df is None or len(intraday_df) < MIN_BARS_FOR_VWAP:
        return neutral_vote("vwap_reversion", "not enough intraday bars yet to trust VWAP")

    vwap = session_vwap(intraday_df)
    vwap_now = float(vwap.iloc[-1])
    if np.isnan(vwap_now):
        return neutral_vote("vwap_reversion", "VWAP not yet defined (no volume)")

    price_now = float(intraday_df["Close"].iloc[-1])

    today_range = float(intraday_df["High"].max() - intraday_df["Low"].min())
    scale = max(today_range, price_now * 0.001)  # floor avoids a div-by-near-zero blowup on a dead-flat open

    distance = price_now - vwap_now
    distance_scaled = distance / scale

    lookback = min(lookback_bars, len(intraday_df) - 1)
    price_then = float(intraday_df["Close"].iloc[-1 - lookback])
    prev_close = float(intraday_df["Close"].iloc[-2])
    ticking_up = price_now > prev_close
    ticking_down = price_now < prev_close

    detail_base = {"vwap": round(vwap_now, 4), "price": round(price_now, 4),
                    "distance_scaled": round(distance_scaled, 3), "today_range": round(today_range, 4)}

    # --- 1. bounce/rejection right at VWAP ---------------------------------
    if abs(distance_scaled) <= bounce_proximity_mult:
        approached_from_above = price_then > vwap_now
        approached_from_below = price_then < vwap_now
        if approached_from_above and price_now > vwap_now and ticking_up:
            return Vote(name="vwap_reversion", direction=0.55, confidence=0.55,
                        regime_tag="vwap_bounce_support", detail=detail_base)
        if approached_from_below and price_now < vwap_now and ticking_down:
            return Vote(name="vwap_reversion", direction=-0.55, confidence=0.55,
                        regime_tag="vwap_bounce_resistance", detail=detail_base)
        return Vote(name="vwap_reversion", direction=0.0, confidence=0.0,
                    regime_tag="at_vwap_undecided", detail=detail_base)

    # --- 2. overextension fade ----------------------------------------------
    if len(intraday_df) < MIN_BARS_FOR_RANGE:
        return neutral_vote("vwap_reversion", "not enough bars yet to trust today's range")

    extension = min(abs(distance_scaled), extension_cap_mult) / extension_cap_mult  # 0..1
    fade_direction = -np.sign(distance) * min(1.0, extension)
    confidence = min(0.4, 0.15 + 0.25 * extension)  # capped well below the bounce case's 0.55
    return Vote(name="vwap_reversion", direction=float(fade_direction), confidence=float(confidence),
                regime_tag="extended_from_vwap", detail=detail_base)
