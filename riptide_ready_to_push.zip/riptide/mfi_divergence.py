"""
Money Flow Index (MFI) voter: extreme-reading fade + price/flow divergence.

Why this exists (2026-08-19, same session as vwap_reversion.py): Will
asked whether adding the Stochastic Momentum Index (SMI) and Money Flow
Index would help. Checked before building anything, rather than assuming
either textbook indicator adds real information on top of what's already
here:

  - RSI vs SMI: correlation 0.83 across 30 real trading days
    (data/SPY_Webull_1min_20260706_to_20260814.csv). Both are pure-price
    "position within recent range" oscillators from the same family as
    the RSI/MACD already inside `indicator.compute_indicator`'s momentum
    component -- SMI would very likely just be a relabeled copy of a
    signal already being voted on, not new information. Skipped.
  - RSI vs MFI: correlation only 0.68 over the same 30 days, with the two
    disagreeing by >20 points (same 0-100 scale) on 12% of bars and >25
    points on 5% -- MFI folds in volume, RSI doesn't, and empirically
    that volume weighting does make it read something different from
    price alone often enough to matter. Built.

Also worth being honest about: on 2026-08-19 itself (the day that
prompted this), RSI and MFI actually moved together closely (correlation
0.83 that specific day, right at the day's high RSI=76/MFI=83, right at
the low RSI=25/MFI=18) -- so this voter would NOT have added a
meaningfully different read on that exact day beyond what `rsi_component`
already carries inside `technical`/`intraday_technical`, or what
`vwap_reversion.py` already reads from a different angle (VWAP distance
instead of price-range position). Its actual value is on the ~1-in-8
bars where the two genuinely disagree -- a real volume-vs-price
divergence, which is a signal type nothing else in this ensemble
currently looks for.

Two independently-gated reads:

1. Divergence -- price and money flow disagree in direction over the
   same lookback window (price up while money flow is falling = real
   buying isn't behind the move; price down while money flow is rising =
   real selling isn't behind the drop). This is the genuinely novel part
   -- nothing else here compares a price swing against a volume-weighted
   read of the same move.
2. Extreme-reading fade -- MFI itself at a classic overbought/oversold
   extreme (>=80 / <=20), independent of any divergence, leans toward
   reversion. Kept deliberately weaker than the divergence case since
   RSI's own extremity already partially covers this territory (see the
   0.68 correlation above -- they still agree most of the time).

Honest limitations: today-only, real-time-only (needs intraday_df, sits
out entirely in the daily-only backtest path, like intraday_technical/
candlesticks/support_resistance/vwap_reversion). New as of 2026-08-19,
validated only against a same-day sanity check and 30 days of replayed
history for the correlation claim above, not yet against real forward-
return grading. Starts in AdaptiveWeights at the default weight like
every new voter -- no hand-tuning.
"""

import numpy as np
import pandas as pd

from indicator import money_flow_index
from voters import Vote, neutral_vote

MFI_PERIOD = 14
MIN_BARS = MFI_PERIOD + 5
OVERBOUGHT = 80.0
OVERSOLD = 20.0
DIVERGENCE_LOOKBACK = 20
DIVERGENCE_MIN_MFI_GAP = 12.0  # points on MFI's 0-100 scale, roughly this voter's own "meaningful gap" bar


def mfi_divergence_vote(intraday_df: pd.DataFrame, period: int = MFI_PERIOD,
                         lookback_bars: int = DIVERGENCE_LOOKBACK) -> Vote:
    if intraday_df is None or len(intraday_df) < MIN_BARS:
        return neutral_vote("mfi_divergence", "not enough intraday bars yet to trust MFI")

    mfi_series = money_flow_index(intraday_df, period)
    mfi_now = float(mfi_series.iloc[-1])
    if np.isnan(mfi_now):
        return neutral_vote("mfi_divergence", "MFI not yet defined (no volume/flow yet)")

    detail = {"mfi": round(mfi_now, 2)}
    price_now = float(intraday_df["Close"].iloc[-1])

    # --- 1. divergence: price direction disagrees with money-flow direction ---
    lookback = min(lookback_bars, len(intraday_df) - 1)
    mfi_then = mfi_series.iloc[-1 - lookback]
    if not np.isnan(mfi_then):
        price_then = float(intraday_df["Close"].iloc[-1 - lookback])
        price_change = price_now - price_then
        mfi_change = mfi_now - float(mfi_then)
        detail["mfi_change"] = round(mfi_change, 2)

        if price_change > 0 and mfi_change <= -DIVERGENCE_MIN_MFI_GAP:
            confidence = min(0.6, 0.3 + abs(mfi_change) / 100)
            return Vote(name="mfi_divergence", direction=-confidence, confidence=confidence,
                        regime_tag="bearish_divergence", detail=detail)
        if price_change < 0 and mfi_change >= DIVERGENCE_MIN_MFI_GAP:
            confidence = min(0.6, 0.3 + abs(mfi_change) / 100)
            return Vote(name="mfi_divergence", direction=confidence, confidence=confidence,
                        regime_tag="bullish_divergence", detail=detail)

    # --- 2. extreme-reading fade (weaker than divergence -- RSI overlaps this some) ---
    if mfi_now >= OVERBOUGHT:
        confidence = min(0.45, 0.15 + (mfi_now - OVERBOUGHT) / 80)
        return Vote(name="mfi_divergence", direction=-confidence, confidence=confidence,
                    regime_tag="overbought", detail=detail)
    if mfi_now <= OVERSOLD:
        confidence = min(0.45, 0.15 + (OVERSOLD - mfi_now) / 80)
        return Vote(name="mfi_divergence", direction=confidence, confidence=confidence,
                    regime_tag="oversold", detail=detail)

    return Vote(name="mfi_divergence", direction=0.0, confidence=0.0, regime_tag="neutral_flow", detail=detail)
