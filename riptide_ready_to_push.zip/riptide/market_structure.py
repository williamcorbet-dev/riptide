"""
Build-to-spec (not a port -- Will had only a written description of this
one, no Pine source) of a "market structure score" indicator: classify
each confirmed swing pivot as HH/HL/LH/LL (higher-high, higher-low,
lower-high, lower-low), roll the last `history_depth` classified pivots
into a weighted, normalized -100..+100 score, and separately track
CHoCH (Change of Character -- a close beyond the last swing extreme
AGAINST the prevailing bias, i.e. a reversal warning) and BOS (Break of
Structure -- a close beyond the last swing extreme WITH the prevailing
bias, i.e. a continuation confirmation).

Because there's no source to check exact formulas against, every design
choice below is a judgment call, stated explicitly rather than silently
picked:

  - Score formula: `100 * (bull_weighted - bear_weighted) / (bull_weighted
    + bear_weighted)` over the last `history_depth` classified pivots.
    This is the simplest formula that satisfies the description's stated
    properties (bounded [-100, 100], 0 at a perfectly mixed window, +-100
    at a purely one-sided window, and responsive to per-classification
    weights) -- but it is a guess, not a verified match to the original.
  - Pivot alternation: pivots must strictly alternate high/low. A new
    same-type pivot candidate REPLACES the currently-held one only if
    it's more extreme (a higher high replaces a lower high candidate; a
    lower low replaces a higher low candidate); otherwise it's dropped.
    This matches the description's "weaker consecutive same-type pivots
    are replaced or dropped."
  - CHoCH/BOS on an undetermined (not-yet-established) bias: the
    description only defines CHoCH-after-bearish-bias and
    CHoCH-after-bullish-bias. The very first break, with no established
    bias yet, is treated here as a CHoCH (it can't be "in line with" a
    bias that doesn't exist yet, so it's not a BOS by the description's
    own definition) -- this also establishes the initial bias.
  - Each swing extreme can fire at most one break event before a fresh
    pivot of that type re-arms it, exactly as described.

Not built (out of scope for a project with no chart/plotting UI): the
oscillator pane, on-price labels/lines, the info panel table, and the
eight Pine `alertcondition()`s -- those are TradingView-chart-specific
presentation, not decision logic. The `detail` dict on the returned Vote
carries the same information (score, regime, bias, counts, pattern) a
chart reader would see in the info panel.
"""

from dataclasses import dataclass, field
from typing import Optional

import numpy as np
import pandas as pd

from candlestick_patterns import resample_ohlc
from voters import Vote, neutral_vote


@dataclass
class MarketStructureConfig:
    pivot_sensitivity: int = 3   # bars each side, "lower timeframe" default per the description
    history_depth: int = 10      # most recent classified pivots included in the score window
    hh_weight: float = 1.0
    hl_weight: float = 1.0
    lh_weight: float = 1.0
    ll_weight: float = 1.0
    strong_threshold: float = 75.0
    medium_threshold: float = 50.0
    weak_threshold: float = 25.0


REGIME_ORDER = ["Strong Bear", "Medium Bear", "Weak Bear", "Mixed",
                "Weak Bull", "Medium Bull", "Strong Bull"]


def _regime_tag(score: float, cfg: MarketStructureConfig) -> str:
    if score >= cfg.strong_threshold:
        return "Strong Bull"
    if score >= cfg.medium_threshold:
        return "Medium Bull"
    if score >= cfg.weak_threshold:
        return "Weak Bull"
    if score <= -cfg.strong_threshold:
        return "Strong Bear"
    if score <= -cfg.medium_threshold:
        return "Medium Bear"
    if score <= -cfg.weak_threshold:
        return "Weak Bear"
    return "Mixed"


def compute_market_structure(df: pd.DataFrame, cfg: MarketStructureConfig = None) -> pd.DataFrame:
    """`df` needs High/Low/Close. Returns a copy of `df` with: score
    (float, NaN until >=1 classified pivot exists), regime_tag, bias
    ("bull"/"bear"/None), bull_count/bear_count (within the scoring
    window), choch_bull/choch_bear/bos_bull/bos_bear (bool, True only on
    the bar the event fires). `out.attrs["pivot_log"]` holds the full
    chronological list of kept pivots as of the LAST bar (for the
    P-numbered pattern readout) -- a live list of dicts, not a per-bar
    column, since only the current state is normally of interest."""
    cfg = cfg or MarketStructureConfig()
    n = len(df)
    high, low, close = df["High"].to_numpy(), df["Low"].to_numpy(), df["Close"].to_numpy()
    s = cfg.pivot_sensitivity
    window = 2 * s + 1

    pivots = []  # chronological list of {"type": "high"/"low", "price": float, "bar": int, "cls": str or None}
    break_log = []  # chronological list of {"side": "bull"/"bear", "bar": int, "level": float} -- one per fired event

    def _classify_and_append_or_replace(kind, price, bar_idx) -> bool:
        """Returns True iff `price` was actually kept (appended as a new
        alternating pivot, or replaced the held same-type candidate) --
        False if it was a weaker same-type candidate and dropped. Only a
        True result should re-arm that side's break detector; a dropped
        candidate changes nothing about the currently active level."""
        if pivots and pivots[-1]["type"] == kind:
            more_extreme = price > pivots[-1]["price"] if kind == "high" else price < pivots[-1]["price"]
            if not more_extreme:
                return False  # weaker same-type candidate: dropped
            # replace: reclassify against the same prior-same-type reference as before
            prev_same = next((p for p in reversed(pivots[:-1]) if p["type"] == kind), None)
            cls = None
            if prev_same is not None:
                if kind == "high":
                    cls = "HH" if price > prev_same["price"] else "LH"
                else:
                    cls = "HL" if price > prev_same["price"] else "LL"
            pivots[-1] = {"type": kind, "price": price, "bar": bar_idx, "cls": cls}
            return True
        prev_same = next((p for p in reversed(pivots) if p["type"] == kind), None)
        cls = None
        if prev_same is not None:
            if kind == "high":
                cls = "HH" if price > prev_same["price"] else "LH"
            else:
                cls = "HL" if price > prev_same["price"] else "LL"
        pivots.append({"type": kind, "price": price, "bar": bar_idx, "cls": cls})
        return True

    score_arr = np.full(n, np.nan)
    bull_count_arr = np.zeros(n, dtype=int)
    bear_count_arr = np.zeros(n, dtype=int)
    choch_bull = np.zeros(n, dtype=bool)
    choch_bear = np.zeros(n, dtype=bool)
    bos_bull = np.zeros(n, dtype=bool)
    bos_bear = np.zeros(n, dtype=bool)
    bias_arr = np.array([None] * n, dtype=object)

    last_high_price, last_high_armed = None, False
    last_low_price, last_low_armed = None, False
    bias = None

    for t in range(n):
        pivot_idx = t - s
        if t >= window - 1 and pivot_idx - s >= 0:
            win_hi = high[pivot_idx - s: pivot_idx + s + 1]
            win_lo = low[pivot_idx - s: pivot_idx + s + 1]
            if high[pivot_idx] == win_hi.max() and (win_hi == high[pivot_idx]).sum() == 1:
                kept = _classify_and_append_or_replace("high", float(high[pivot_idx]), pivot_idx)
                # only a genuinely kept (appended/replaced) pivot re-arms the
                # break detector -- a dropped weaker candidate must not
                # silently re-arm a level that a prior break already disarmed
                if kept:
                    last_high_price, last_high_armed = pivots[-1]["price"], True
            if low[pivot_idx] == win_lo.min() and (win_lo == low[pivot_idx]).sum() == 1:
                kept = _classify_and_append_or_replace("low", float(low[pivot_idx]), pivot_idx)
                if kept:
                    last_low_price, last_low_armed = pivots[-1]["price"], True

        # --- CHoCH / BOS: close crossing the currently-armed swing extreme ---
        if t > 0:
            prev_close = close[t - 1]
            if last_high_armed and prev_close <= last_high_price < close[t]:
                if bias in (None, "bear"):
                    choch_bull[t] = True
                else:
                    bos_bull[t] = True
                break_log.append({"side": "bull", "bar": t, "level": last_high_price})
                bias = "bull"
                last_high_armed = False
            if last_low_armed and prev_close >= last_low_price > close[t]:
                if bias in (None, "bull"):
                    choch_bear[t] = True
                else:
                    bos_bear[t] = True
                break_log.append({"side": "bear", "bar": t, "level": last_low_price})
                bias = "bear"
                last_low_armed = False

        bias_arr[t] = bias

        window_pivots = [p for p in pivots if p["cls"] is not None][-cfg.history_depth:]
        bull_w = sum((cfg.hh_weight if p["cls"] == "HH" else cfg.hl_weight) for p in window_pivots if p["cls"] in ("HH", "HL"))
        bear_w = sum((cfg.lh_weight if p["cls"] == "LH" else cfg.ll_weight) for p in window_pivots if p["cls"] in ("LH", "LL"))
        bull_count_arr[t] = sum(1 for p in window_pivots if p["cls"] in ("HH", "HL"))
        bear_count_arr[t] = sum(1 for p in window_pivots if p["cls"] in ("LH", "LL"))
        if bull_w + bear_w > 0:
            score_arr[t] = 100.0 * (bull_w - bear_w) / (bull_w + bear_w)

    regime_arr = [None if np.isnan(sc) else _regime_tag(sc, cfg) for sc in score_arr]

    out = df.copy()
    out["score"] = score_arr
    out["regime_tag"] = regime_arr
    out["bias"] = bias_arr
    out["bull_count"] = bull_count_arr
    out["bear_count"] = bear_count_arr
    out["choch_bull"] = choch_bull
    out["choch_bear"] = choch_bear
    out["bos_bull"] = bos_bull
    out["bos_bear"] = bos_bear
    out.attrs["pivot_log"] = list(pivots)
    out.attrs["break_log"] = list(break_log)
    return out


VOTER_RESAMPLE_RULE = None  # native 1-min, NOT resampled -- see daily_reviews.md 2026-08-20:
# unlike adaptive_supertrend.py/anchored_vwap_swings.py, this one's own written
# guidance recommends pivot_sensitivity 2-3 for 1m-15m charts specifically, and
# checked against real data, raw 1-min bars produced a non-degenerate score
# distribution and a reasonable 2-5 zero-crossings/day -- no resample needed or
# used.
VOTER_CONFIG = MarketStructureConfig()
MIN_BARS = 40


def market_structure_vote(intraday_df: pd.DataFrame, cfg: MarketStructureConfig = None,
                           resample_rule: str = VOTER_RESAMPLE_RULE) -> Vote:
    """A fresh CHoCH or BOS this bar is the strongest read (0.5,
    mirroring the fresh-event tier used by the other structural voters
    in this project) -- CHoCH slightly favored over BOS since it marks a
    bias change, not just a continuation. Absent a fresh event, the
    score itself is used as a continuation read: 0 confidence inside the
    Mixed zone (-25..+25, by design -- the description calls this "no
    directional lean" and this project's convention is to say nothing
    rather than force an opinion), ramping linearly to 0.35 at a
    Strong-zone score (|score| >= strong_threshold)."""
    if intraday_df is None or len(intraday_df) < 5:
        return neutral_vote("market_structure", "not enough intraday bars yet")

    bars = resample_ohlc(intraday_df, resample_rule) if resample_rule else intraday_df
    if len(bars) < MIN_BARS:
        return neutral_vote("market_structure", f"not enough bars yet ({len(bars)}/{MIN_BARS})")

    cfg = cfg or VOTER_CONFIG
    out = compute_market_structure(bars, cfg)
    last = out.iloc[-1]
    score = last["score"]
    pattern = " -> ".join(p["cls"] or "?" for p in out.attrs["pivot_log"][-cfg.history_depth:])
    detail = {
        "score": None if pd.isna(score) else round(float(score), 1),
        "regime_tag": last["regime_tag"],
        "bias": last["bias"],
        "bull_count": int(last["bull_count"]),
        "bear_count": int(last["bear_count"]),
        "pattern": pattern,
    }

    if pd.isna(score):
        return neutral_vote("market_structure", "not enough classified pivots yet")

    if bool(last["choch_bull"]):
        return Vote(name="market_structure", direction=1.0, confidence=0.5, regime_tag="choch_bull", detail=detail)
    if bool(last["choch_bear"]):
        return Vote(name="market_structure", direction=-1.0, confidence=0.5, regime_tag="choch_bear", detail=detail)
    if bool(last["bos_bull"]):
        return Vote(name="market_structure", direction=1.0, confidence=0.45, regime_tag="bos_bull", detail=detail)
    if bool(last["bos_bear"]):
        return Vote(name="market_structure", direction=-1.0, confidence=0.45, regime_tag="bos_bear", detail=detail)

    direction = float(np.clip(score / 100.0, -1.0, 1.0))
    strength = max(0.0, (abs(score) - cfg.weak_threshold)) / max(1e-9, (100.0 - cfg.weak_threshold))
    confidence = min(0.35, 0.35 * strength)
    return Vote(name="market_structure", direction=direction, confidence=confidence,
                regime_tag=last["regime_tag"], detail=detail)
