"""
Loader for a Webull intraday-history CSV export.

This is deliberately a CSV loader, not a live API adapter. Building
`webull_data.py` against Webull's live API was blocked earlier because
that requires handling real account credentials (API key/secret) -- and
even when offered those credentials directly, the right call was to
decline and ask for a manually-exported data file instead (see the
project history / conversation this was built in). Webull's own app can
export a symbol's intraday bar history to CSV with no API integration
required at all, which is exactly the file this module reads:

    timestamp,tickerid,symbol,open,close,high,low,volume,trading_session,instrument_id,day
    2026-07-06 09:30:00-04:00,913243251,SPY,748.74,749.29,749.38,748.14,573831,RTH,913243251,2026-07-06

This sidesteps API credentials entirely while still getting real intraday
SPY data into the system -- a real, if manual, alternative to the live
Webull API for the two voters that specifically need intraday history:
`candlestick_patterns.py`'s multi-timeframe engine and
`time_of_day_fingerprint.py`'s self-calibrating baseline.

Note this is intraday-only. It is NOT a substitute for a long real DAILY
history -- Hurst and the HMM regime detector both need far more daily bars
than resampling a few weeks of intraday data up to daily can provide, and
will honestly report "not enough history" rather than fake a read (see
`backtest.py`'s Nasdaq-CSV support for a real long-history daily source).
"""

import pandas as pd

OHLCV_COLUMNS = ["Open", "High", "Low", "Close", "Volume"]


def load_webull_intraday_csv(path: str, session: str = "RTH") -> pd.DataFrame:
    """Loads a Webull intraday-history CSV export into a standard
    Open/High/Low/Close/Volume DataFrame, indexed by (timezone-stripped,
    wall-clock) timestamp, sorted ascending.

    `session`: filter to this `trading_session` value. "RTH" (regular
    trading hours, the default) is generally what you want for a 1DTE
    system -- pass `None` to keep pre/post-market bars too, if your export
    includes them and you want them.
    """
    df = pd.read_csv(path, parse_dates=["timestamp"])
    if session is not None and "trading_session" in df.columns:
        df = df[df["trading_session"] == session]

    if getattr(df["timestamp"].dt, "tz", None) is not None:
        # Keep the local wall-clock time (09:30 stays 09:30) rather than
        # converting to a different timezone -- Webull's export timestamps
        # are already local exchange time with an offset attached.
        df["timestamp"] = df["timestamp"].dt.tz_localize(None)

    df = df.set_index("timestamp").sort_index()
    df = df.rename(columns=str.title)
    return df[OHLCV_COLUMNS]


def derive_daily_from_intraday(minute_df: pd.DataFrame) -> pd.DataFrame:
    """Resamples intraday bars up to daily OHLCV. Real daily bars derived
    this way are only as long as the intraday history in the export -- a
    few weeks at most for a typical Webull export, nowhere near enough for
    Hurst/HMM to have real statistical power (see module docstring)."""
    agg = {"Open": "first", "High": "max", "Low": "min", "Close": "last", "Volume": "sum"}
    return minute_df.resample("1D").agg(agg).dropna()


def split_latest_day(minute_df: pd.DataFrame):
    """Splits intraday bars into (today, history): the most recent
    calendar day's bars as `today` (for candlestick_vote / fingerprint
    scoring), everything before as `history` (for building the
    time-of-day fingerprint baseline). Mirrors
    composite_signal.SignalInputs' intraday_df / intraday_history split."""
    if minute_df.empty:
        return minute_df, minute_df
    last_day = minute_df.index.normalize().max()
    is_last_day = minute_df.index.normalize() == last_day
    return minute_df[is_last_day], minute_df[~is_last_day]
