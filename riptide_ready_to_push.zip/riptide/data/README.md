# Reference data

`SPY_Webull_1min_20260706_to_20260814.csv` -- a real Webull intraday-history
export: 1-minute SPY bars, regular trading hours only, 2026-07-06 through
2026-08-14 (30 trading days, 11,700 bars). Loaded via `webull_data.py`.

This is the first real (non-synthetic) data this project was validated
against. Feed it to `live_signal.py` with `--webull-intraday-csv
data/SPY_Webull_1min_20260706_to_20260814.csv` to unlock the candlestick
and time-of-day voters with real data instead of them sitting out.

30 days of intraday history is enough for those two voters (which
self-calibrate against their own recent history) but is NOT enough daily
history for Hurst or the HMM regime detector, which need much longer daily
series -- they'll honestly report low/no confidence when run against the
daily bars derived from this file alone via
`webull_data.derive_daily_from_intraday()`. See the main README's "What I
could and couldn't verify" section for what a first real-data run through
the full ensemble looked like.

This file was obtained as a manual CSV export from Webull -- no API key
was used or handled to get it. See `webull_data.py`'s module docstring for
why that was a deliberate choice.
