"""
Multi-timeframe candlestick pattern engine (3m and up -- anything faster is
treated as too noisy on SPY to carry real information).

Hand-rolled rather than TA-Lib: the patterns are simple, well-documented
OHLC geometry rules, and avoiding TA-Lib's C dependency keeps this project
installable with nothing but pip + pure-Python packages.

Two ideas beyond "just run standard patterns":
  1. Timeframe-weighted confluence: a pattern on the 4h chart matters more
     than the same pattern on the 5m chart. We weight by timeframe and also
     track how many timeframes agree, since confluence across scales is
     itself informative.
  2. Pattern-at-structure bonus: a reversal pattern that prints near a
     gamma-significant level (max pain / zero-gamma flip, from
     gamma_positioning.py) is a structurally different event than the same
     pattern printing in open space -- see `candlestick_vote`.
"""

from dataclasses import dataclass

import numpy as np
import pandas as pd

from voters import Vote

# Default timeframe set and their relative weights (longer TF = more weight).
# "T" suffix = minutes for pandas resample rule.
DEFAULT_TIMEFRAMES = {
    "3m": ("3min", 0.6),
    "5m": ("5min", 0.7),
    "15m": ("15min", 0.85),
    "30m": ("30min", 1.0),
    "1h": ("1h", 1.2),
    "4h": ("4h", 1.5),
    "1D": ("1D", 2.0),
}


def resample_ohlc(df: pd.DataFrame, rule: str) -> pd.DataFrame:
    agg = {"Open": "first", "High": "max", "Low": "min", "Close": "last"}
    if "Volume" in df.columns:
        agg["Volume"] = "sum"
    out = df.resample(rule).agg(agg).dropna()
    return out


# ---------------------------------------------------------------------------
# Candle geometry helpers
# ---------------------------------------------------------------------------

def _geometry(df: pd.DataFrame) -> pd.DataFrame:
    g = pd.DataFrame(index=df.index)
    g["body"] = (df["Close"] - df["Open"]).abs()
    g["range"] = (df["High"] - df["Low"]).replace(0, np.nan)
    g["upper_wick"] = df["High"] - df[["Open", "Close"]].max(axis=1)
    g["lower_wick"] = df[["Open", "Close"]].min(axis=1) - df["Low"]
    g["bullish"] = df["Close"] > df["Open"]
    g["body_pct"] = g["body"] / g["range"]
    return g


def _trend_context(close: pd.Series, lookback: int = 5) -> pd.Series:
    """+1 if price has been rising into this bar, -1 if falling, used to
    disambiguate hammer/hanging-man and inverted-hammer/shooting-star,
    which share identical candle shapes but opposite implications
    depending on what preceded them."""
    return np.sign(close - close.shift(lookback)).fillna(0)


# ---------------------------------------------------------------------------
# Pattern detectors -- each returns a Series with values in {-1, 0, +1}
# (bearish, none, bullish) aligned to df.index.
# ---------------------------------------------------------------------------

def detect_patterns(df: pd.DataFrame, trend_lookback: int = 5) -> pd.DataFrame:
    """Runs the full pattern library on a single-timeframe OHLC DataFrame.
    Returns a DataFrame with one signed (-1/0/+1) column per pattern."""
    o, h, l, c = df["Open"], df["High"], df["Low"], df["Close"]
    g = _geometry(df)
    trend = _trend_context(c, trend_lookback)
    out = pd.DataFrame(index=df.index)

    small_body = g["body_pct"] < 0.3
    tiny_body = g["body_pct"] < 0.1
    long_lower = g["lower_wick"] > 2 * g["body"]
    long_upper = g["upper_wick"] > 2 * g["body"]
    tiny_wicks = (g["upper_wick"] < 0.1 * g["range"]) & (g["lower_wick"] < 0.1 * g["range"])

    # --- Doji: negligible body relative to range. Informational only (no
    # directional bias by itself -- excluded from PATTERN_COLUMNS) but
    # flagged here so it shows up in per-timeframe detail for context.
    out["doji"] = tiny_body.astype(int) * 0  # always 0: presence tracked via `doji_present` below
    out["doji_present"] = tiny_body

    # --- Hammer / hanging man: small body near top, long lower wick, little upper wick
    hammer_shape = small_body & long_lower & (g["upper_wick"] < g["body"] + 1e-9)
    out["hammer"] = 0
    out.loc[hammer_shape & (trend < 0), "hammer"] = 1     # bullish reversal after downtrend
    out.loc[hammer_shape & (trend > 0), "hammer"] = -1    # "hanging man" after uptrend -> bearish

    # --- Inverted hammer / shooting star: small body near bottom, long upper wick
    star_shape = small_body & long_upper & (g["lower_wick"] < g["body"] + 1e-9)
    out["shooting_star"] = 0
    out.loc[star_shape & (trend < 0), "shooting_star"] = 1   # "inverted hammer" after downtrend -> bullish
    out.loc[star_shape & (trend > 0), "shooting_star"] = -1  # shooting star after uptrend -> bearish

    # --- Marubozu: full body, negligible wicks -- strong momentum candle
    out["marubozu"] = 0
    out.loc[tiny_wicks & ~small_body & g["bullish"], "marubozu"] = 1
    out.loc[tiny_wicks & ~small_body & ~g["bullish"], "marubozu"] = -1

    # --- Spinning top: small body, wicks on both sides roughly balanced --
    # indecision. Detected and reported for context (see `doji_present`
    # convention above) but excluded from PATTERN_COLUMNS: no directional edge.
    balanced_wicks = (g["upper_wick"] > 0.2 * g["range"]) & (g["lower_wick"] > 0.2 * g["range"])
    out["spinning_top"] = 0
    out["spinning_top_present"] = small_body & balanced_wicks & ~tiny_body

    # --- Bullish / bearish engulfing (2-candle)
    prev_o, prev_c = o.shift(1), c.shift(1)
    bull_engulf = (~g["bullish"].shift(1).fillna(False)) & g["bullish"] & (c >= prev_o) & (o <= prev_c)
    bear_engulf = (g["bullish"].shift(1).fillna(False)) & (~g["bullish"]) & (o >= prev_c) & (c <= prev_o)
    out["engulfing"] = 0
    out.loc[bull_engulf, "engulfing"] = 1
    out.loc[bear_engulf, "engulfing"] = -1

    # --- Harami (2-candle): small candle2 body contained within candle1's larger body
    prev_body = g["body"].shift(1)
    contained = (o.combine(c, max) <= prev_o.combine(prev_c, max)) & \
                (o.combine(c, min) >= prev_o.combine(prev_c, min))
    harami = contained & (g["body"] < 0.6 * prev_body)
    out["harami"] = 0
    out.loc[harami & (g["bullish"].shift(1).fillna(False) == False) & g["bullish"], "harami"] = 1
    out.loc[harami & (g["bullish"].shift(1).fillna(False) == True) & (~g["bullish"]), "harami"] = -1

    # --- Piercing line / dark cloud cover (2-candle)
    prev_mid = (prev_o + prev_c) / 2
    piercing = (~g["bullish"].shift(1).fillna(False)) & g["bullish"] & (o < prev_c) & (c > prev_mid) & (c < prev_o)
    dark_cloud = (g["bullish"].shift(1).fillna(False)) & (~g["bullish"]) & (o > prev_c) & (c < prev_mid) & (c > prev_o)
    out["piercing_darkcloud"] = 0
    out.loc[piercing, "piercing_darkcloud"] = 1
    out.loc[dark_cloud, "piercing_darkcloud"] = -1

    # --- Morning star / evening star (3-candle)
    b1_bear = ~g["bullish"].shift(2).fillna(False)
    b1_body = g["body"].shift(2)
    b2_small = g["body"].shift(1) < 0.4 * b1_body
    b3_bull = g["bullish"]
    b3_closes_into_b1 = c > (o.shift(2) + c.shift(2)) / 2
    morning_star = b1_bear & b2_small & b3_bull & b3_closes_into_b1

    b1_bull = g["bullish"].shift(2).fillna(False)
    b3_bear = ~g["bullish"]
    b3_closes_into_b1_down = c < (o.shift(2) + c.shift(2)) / 2
    evening_star = b1_bull & b2_small & b3_bear & b3_closes_into_b1_down

    out["star_3candle"] = 0
    out.loc[morning_star, "star_3candle"] = 1
    out.loc[evening_star, "star_3candle"] = -1

    # --- Three white soldiers / three black crows (3-candle)
    bull3 = g["bullish"] & g["bullish"].shift(1).fillna(False) & g["bullish"].shift(2).fillna(False)
    rising_closes = (c > c.shift(1)) & (c.shift(1) > c.shift(2))
    opens_within_prior_body = (o > o.shift(1)) & (o < c.shift(1))
    three_soldiers = bull3 & rising_closes & opens_within_prior_body

    bear3 = (~g["bullish"]) & (~g["bullish"].shift(1).fillna(True)) & (~g["bullish"].shift(2).fillna(True))
    falling_closes = (c < c.shift(1)) & (c.shift(1) < c.shift(2))
    opens_within_prior_body_down = (o < o.shift(1)) & (o > c.shift(1))
    three_crows = bear3 & falling_closes & opens_within_prior_body_down

    out["three_in_a_row"] = 0
    out.loc[three_soldiers, "three_in_a_row"] = 1
    out.loc[three_crows, "three_in_a_row"] = -1

    # --- Tweezer top / bottom (2-candle, matching highs or lows)
    tol = 0.1 * g["range"].rolling(10).mean().bfill()
    tweezer_top = (h.sub(h.shift(1)).abs() <= tol) & g["bullish"].shift(1).fillna(False) & (~g["bullish"])
    tweezer_bottom = (l.sub(l.shift(1)).abs() <= tol) & (~g["bullish"].shift(1).fillna(True)) & g["bullish"]
    out["tweezer"] = 0
    out.loc[tweezer_top, "tweezer"] = -1
    out.loc[tweezer_bottom, "tweezer"] = 1

    return out


PATTERN_COLUMNS = [
    "hammer", "shooting_star", "marubozu", "engulfing", "harami",
    "piercing_darkcloud", "star_3candle", "three_in_a_row", "tweezer",
]


@dataclass
class TimeframeReading:
    timeframe: str
    weight: float
    latest_signal: float   # sum of active pattern signals on the most recent completed bar
    active_patterns: list


def multi_timeframe_confluence(base_df: pd.DataFrame,
                                timeframes: dict = None) -> list:
    """Resamples `base_df` (must be at <=3min resolution) up to each
    configured timeframe, runs the pattern library, and reports the most
    recent completed bar's signal per timeframe."""
    timeframes = timeframes or DEFAULT_TIMEFRAMES
    readings = []
    for label, (rule, weight) in timeframes.items():
        tf_df = resample_ohlc(base_df, rule)
        if len(tf_df) < 5:
            continue
        patterns = detect_patterns(tf_df)
        last = patterns.iloc[-2] if len(patterns) > 1 else patterns.iloc[-1]  # last COMPLETED bar
        active = [col for col in PATTERN_COLUMNS if last.get(col, 0) != 0]
        signal = float(sum(last.get(col, 0) for col in PATTERN_COLUMNS))
        readings.append(TimeframeReading(timeframe=label, weight=weight,
                                          latest_signal=signal, active_patterns=active))
    return readings


def candlestick_vote(base_df: pd.DataFrame, timeframes: dict = None,
                      gamma_profile=None, atr: float = None,
                      structure_bonus: float = 0.5) -> Vote:
    """Aggregates multi-timeframe pattern confluence into one vote.

    If `gamma_profile` and `atr` are supplied (see gamma_positioning.py),
    a pattern that fires while price is close (in ATR terms) to the
    max-pain strike or the zero-gamma flip level gets a confidence bonus
    -- the "pattern at a mechanistically significant level" idea.
    """
    readings = multi_timeframe_confluence(base_df, timeframes)
    if not readings:
        return Vote(name="candlesticks", direction=0.0, confidence=0.0,
                     detail={"reason": "not enough resampled data"})

    weighted_sum = sum(r.latest_signal * r.weight for r in readings)
    total_weight = sum(r.weight for r in readings)
    agreeing_bull = sum(1 for r in readings if r.latest_signal > 0)
    agreeing_bear = sum(1 for r in readings if r.latest_signal < 0)
    confluence_count = max(agreeing_bull, agreeing_bear)

    direction = float(np.tanh(weighted_sum / max(total_weight, 1e-9)))
    base_confidence = min(1.0, confluence_count / max(len(readings), 1))

    bonus = 0.0
    near_structure = False
    if gamma_profile is not None and atr:
        spot = gamma_profile.spot
        dist_max_pain = abs(spot - gamma_profile.max_pain_strike) / max(atr, 1e-9)
        dist_flip = abs(spot - gamma_profile.zero_gamma_flip) / max(atr, 1e-9)
        if min(dist_max_pain, dist_flip) < 1.5:
            near_structure = True
            bonus = structure_bonus

    confidence = float(min(1.0, base_confidence * (1 + bonus)))

    return Vote(
        name="candlesticks",
        direction=direction,
        confidence=confidence,
        regime_tag="reversal" if direction * np.sign(weighted_sum) != 0 else None,
        detail={
            "per_timeframe": [
                {"tf": r.timeframe, "signal": r.latest_signal, "patterns": r.active_patterns}
                for r in readings
            ],
            "confluence_count": confluence_count,
            "near_gamma_structure": near_structure,
        },
    )
