"""One-time backfill: walk every real historical chain day we have (from
data/chains_bulk, built from purchased vendor Greek CSVs) in chronological
order and record each day's vanna/charm exposure and skew reading into the
REAL persistent stores (state/vanna_charm_history.json, state/skew_history.
json). Both voters only need the chain snapshot + calendar date to record
-- no price/OHLCV series involved -- so this is a legitimate way to earn
real trailing history (min_history=20) without needing a daily-bars
provider at all. After this runs, live_signal.py / intraday_replay.py /
daily_review.py will see real accumulated history immediately."""
from datetime import datetime

from historical_chain import build_chain_lookup_from_dir
from gamma_positioning import compute_gamma_profile
from vanna_charm import compute_vanna_charm, vanna_charm_vote, VannaCharmHistoryStore
from skew_dynamics import skew_vote, SkewHistoryStore

CHAIN_DIR = "data/chains_bulk"
SYMBOL = "SPY"

print(f"Loading chain lookup from {CHAIN_DIR} ...")
chain_by_date = build_chain_lookup_from_dir(CHAIN_DIR, symbol=SYMBOL, min_days_out=1)
print(f"Loaded {len(chain_by_date)} day(s): {sorted(chain_by_date.keys())[0]} .. {sorted(chain_by_date.keys())[-1]}")

vc_store = VannaCharmHistoryStore()
skew_store = SkewHistoryStore()

for d in sorted(chain_by_date.keys()):
    chain = chain_by_date[d]
    profile = compute_vanna_charm(chain)
    vc_vote = vanna_charm_vote(profile, hours_to_close=3.0, store=vc_store, as_of=d, min_history=20)
    sk_vote = skew_vote(chain, store=skew_store, min_history=20, as_of=d)
    print(f"{d}  spot={chain.spot:8.2f}  vanna+charm={profile.vanna_exposure + profile.charm_exposure:+15,.0f}"
          f"  (vc conf={vc_vote.confidence:.2f})   skew={sk_vote.detail.get('today_skew', float('nan')):+.4f}"
          f"  (skew conf={sk_vote.confidence:.2f})")

print()
print(f"Final vanna_charm history: {len(vc_store.history(lookback_days=9999))} day(s)")
print(f"Final skew history:        {len(skew_store.history(lookback_days=9999))} day(s)")
