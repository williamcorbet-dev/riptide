"""
Time-of-day fingerprint: a self-calibrating baseline of "how SPY typically
behaves at this exact point in the trading day," and a live anomaly score
for whether today is moving unusually much (or little) for this time slot
compared to its own history.

This isn't borrowed from any single published strategy -- it's built
entirely from the instrument's own historical intraday shape (opening
range chop, midday lull, last-hour repositioning, etc.), so it's specific
to whatever ticker/timeframe you feed it rather than a generic rule.

Method:
  1. Bucket historical intraday bars by (minutes-since-open).
  2. For each bucket, build a distribution of realized bar-to-bar returns
     and cumulative return-since-open.
  3. For "today," compute a z-score of the actual move against that
     bucket's historical mean/stdev.
  4. Large |z| = today is behaving anomalously for this time of day, which
     the ensemble treats as a confidence signal (informative regime
     context), and the sign of the anomaly (relative to the day's
     move-so-far direction) informs the vote's direction.
"""

from dataclasses import dataclass

import numpy as np
import pandas as pd

from voters import Vote


def _minutes_since_open(ts: pd.Timestamp, session_open: str = "09:30") -> int:
    open_h, open_m = map(int, session_open.split(":"))
    open_dt = ts.replace(hour=open_h, minute=open_m, second=0, microsecond=0)
    return int((ts - open_dt).total_seconds() // 60)


def build_fingerprint(intraday_df: pd.DataFrame, session_open: str = "09:30",
                       bucket_minutes: int = 5) -> pd.DataFrame:
    """From historical intraday OHLC bars (any single timeframe, e.g. 5m),
    builds a table indexed by minutes-since-open bucket with the historical
    mean/std of cumulative return-since-open at that point in the day.
    """
    df = intraday_df.copy()
    df["date"] = df.index.normalize()
    df["mins"] = [_minutes_since_open(ts, session_open) for ts in df.index]
    df = df[df["mins"] >= 0]
    df["bucket"] = (df["mins"] // bucket_minutes) * bucket_minutes

    # cumulative return since that day's open, per row
    day_open = df.groupby("date")["Open"].transform("first")
    df["cum_ret"] = np.log(df["Close"] / day_open)

    fp = df.groupby("bucket")["cum_ret"].agg(["mean", "std", "count"]).rename(
        columns={"mean": "hist_mean", "std": "hist_std", "count": "n_obs"}
    )
    return fp


@dataclass
class FingerprintReading:
    bucket: int
    today_cum_ret: float
    hist_mean: float
    hist_std: float
    z_score: float
    n_obs: int


def score_today(intraday_df_today: pd.DataFrame, fingerprint: pd.DataFrame,
                 session_open: str = "09:30", bucket_minutes: int = 5,
                 min_obs: int = 20) -> FingerprintReading:
    """Compares today's realized move-so-far against the historical
    fingerprint at the current time-of-day bucket."""
    last_ts = intraday_df_today.index[-1]
    mins = _minutes_since_open(last_ts, session_open)
    bucket = (mins // bucket_minutes) * bucket_minutes

    day_open = intraday_df_today["Open"].iloc[0]
    today_cum_ret = float(np.log(intraday_df_today["Close"].iloc[-1] / day_open))

    if bucket not in fingerprint.index or fingerprint.loc[bucket, "n_obs"] < min_obs:
        # fall back to nearest bucket with enough observations
        valid = fingerprint[fingerprint["n_obs"] >= min_obs]
        if valid.empty:
            return FingerprintReading(bucket, today_cum_ret, np.nan, np.nan, np.nan, 0)
        nearest = (valid.index.to_series() - bucket).abs().idxmin()
        bucket = nearest

    row = fingerprint.loc[bucket]
    std = row["hist_std"] if row["hist_std"] > 1e-9 else np.nan
    z = (today_cum_ret - row["hist_mean"]) / std if std and not np.isnan(std) else np.nan

    return FingerprintReading(
        bucket=int(bucket), today_cum_ret=today_cum_ret,
        hist_mean=float(row["hist_mean"]), hist_std=float(row["hist_std"]),
        z_score=float(z) if not np.isnan(z) else np.nan, n_obs=int(row["n_obs"]),
    )


def fingerprint_vote(intraday_df_today: pd.DataFrame, fingerprint: pd.DataFrame,
                      session_open: str = "09:30", bucket_minutes: int = 5,
                      z_cap: float = 2.5) -> Vote:
    """Direction: sign of today's anomaly relative to its own history --
    i.e. if today is moving MORE positive than typical for this time of
    day, that's read as bullish continuation pressure (momentum framing);
    if you'd rather fade anomalies, flip the sign at the call site.
    Confidence scales with |z|, capped at `z_cap` standard deviations."""
    reading = score_today(intraday_df_today, fingerprint, session_open, bucket_minutes)

    if np.isnan(reading.z_score) or reading.n_obs < 20:
        return Vote(name="time_of_day", direction=0.0, confidence=0.0,
                     detail={"reason": "insufficient historical fingerprint data",
                             "bucket": reading.bucket, "n_obs": reading.n_obs})

    direction = float(np.tanh(reading.z_score / z_cap))
    confidence = float(min(1.0, abs(reading.z_score) / z_cap))

    return Vote(
        name="time_of_day",
        direction=direction,
        confidence=confidence,
        regime_tag="anomalous" if abs(reading.z_score) > 1.5 else "typical",
        detail={
            "bucket_minutes_since_open": reading.bucket,
            "today_cum_ret": reading.today_cum_ret,
            "hist_mean": reading.hist_mean,
            "hist_std": reading.hist_std,
            "z_score": reading.z_score,
            "n_obs": reading.n_obs,
        },
    )
