"""
Systematic scan for genuine "grind-then-reversal" points across many days
of 1-min bars, so these get found proactively instead of relying on
someone watching live and reporting the time after the fact (see
daily_reviews.md, 2026-08-21: found and graded 14 real reversal points
this way -- the ensemble fired a wrong-direction signal at/near 6 of them
and never caught the correct direction within 75 min at 6 others).

Works on a 5-min-resampled close series (one session at a time, nothing
crosses a day boundary) to smooth out 1-min noise -- a human watching the
chart perceives a "765.12 level" as one bounce zone, not a single-minute
tick, so matching that scale gives sane results.

A reversal at resampled bar t requires ALL of:
  - t is the local min (or max) of price over a +/- LOOKAROUND window
  - the move INTO t (from LOOKAROUND before to t) was at least
    MIN_LEG_DOLLARS in one direction -- a real prior leg, not noise
  - the move OUT of t (from t to LOOKAROUND after) was at least
    MIN_LEG_DOLLARS in the opposite direction -- an actual follow-through
  - the prior leg was a "grind": realized volatility over that leg
    (avg abs 5-min close-close move) is below GRIND_VOL_CEILING -- this
    specifically targets the "hour of no real movement then it moves"
    pattern, not a V-shaped whipsaw

Usage:
    python find_reversals.py --webull-csv data/SPY_Webull_1min_20260706_to_20260814.csv data/SPY_live_*.csv
    (defaults to the full available data/ set if no paths are given)

Writes reversals_found.csv (one row per detected point) and prints a
summary table. Read-only -- never touches state/.
"""
import glob

import pandas as pd
import numpy as np

RESAMPLE = "5min"
LOOKAROUND_BARS = 6       # 6 x 5min = 30 min each side, used to confirm local extremum
MIN_LEG_DOLLARS = 0.40    # minimum size of both the entry leg and the reversal leg
GRIND_VOL_CEILING = 0.16  # avg abs 5-min close-close move during the entry leg, below this = "grind"


def _resample_session(day_bars: pd.DataFrame) -> pd.Series:
    return day_bars["Close"].resample(RESAMPLE).last().dropna()


def find_reversals_one_day(day_bars: pd.DataFrame) -> list:
    close = _resample_session(day_bars)
    n = len(close)
    out = []
    for i in range(LOOKAROUND_BARS, n - LOOKAROUND_BARS):
        t = close.index[i]
        price_t = close.iloc[i]
        before = close.iloc[i - LOOKAROUND_BARS: i + 1]
        after = close.iloc[i: i + LOOKAROUND_BARS + 1]

        is_low = (price_t <= before.min()) and (price_t <= after.min())
        is_high = (price_t >= before.max()) and (price_t >= after.max())
        if not (is_low or is_high):
            continue

        entry_leg = price_t - before.iloc[0]
        exit_leg = after.iloc[-1] - price_t
        if abs(entry_leg) < MIN_LEG_DOLLARS or abs(exit_leg) < MIN_LEG_DOLLARS:
            continue
        if np.sign(entry_leg) == np.sign(exit_leg):
            continue

        leg_moves = before.diff().abs().dropna()
        grind_vol = float(leg_moves.mean()) if len(leg_moves) else np.nan
        if not (grind_vol <= GRIND_VOL_CEILING):
            continue

        out.append({
            "time": t, "price": float(price_t),
            "kind": "low_to_high" if is_low else "high_to_low",
            "entry_leg": float(entry_leg), "exit_leg": float(exit_leg),
            "grind_vol": grind_vol,
        })

    deduped = []
    for r in out:
        if deduped and (r["time"] - deduped[-1]["time"]) <= pd.Timedelta(minutes=LOOKAROUND_BARS * 5):
            prev = deduped[-1]
            better = r if (r["kind"] == "low_to_high" and r["price"] < prev["price"]) or \
                          (r["kind"] == "high_to_low" and r["price"] > prev["price"]) else prev
            deduped[-1] = better
        else:
            deduped.append(r)
    return deduped


def find_reversals(minute_df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for day, day_bars in minute_df.groupby(minute_df.index.normalize()):
        rows.extend(find_reversals_one_day(day_bars))
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# Live/causal version -- everything above is hindsight (it needs the AFTER
# leg to confirm a reversal actually happened, so it can only ever report on
# a moment that has already passed). This is the real-time-safe half: "are
# we, right now, in the kind of low-volatility grind that these reversals
# come out of" -- uses ONLY bars up to and including `now`, never anything
# after (verified by test_find_reversals.py's no-lookahead test), so it's
# safe to call live at every checkpoint, not just in a backward scan.
#
# 2026-08-21 finding (daily_reviews.md): tested whether this flag alone
# predicts ensemble error broadly (not just on the 14 cherry-picked
# reversal points, which are grinds-that-happened-to-reverse by
# construction -- a biased sample). See that day's entry for the result.
# ---------------------------------------------------------------------------

LIVE_LOOKBACK_MIN = 30
LIVE_GRIND_VOL_CEILING = 0.055  # avg abs 1-min close-close move, below this = "grinding" (1-min scale,
                                 # not the 5-min scale GRIND_VOL_CEILING above uses)


def is_grinding_now(intraday_df: pd.DataFrame, now, lookback_min: int = LIVE_LOOKBACK_MIN,
                     vol_ceiling: float = LIVE_GRIND_VOL_CEILING):
    """True if the `lookback_min` minutes up to and including `now` have
    been unusually low-volatility (a coiling/compression state) -- no
    opinion on direction, and no claim a reversal is coming, just "this is
    the kind of quiet stretch reversals tend to come out of." Returns None
    if there isn't enough trailing data yet to judge (too early in the
    session, or too little history passed in)."""
    window = intraday_df[(intraday_df.index > now - pd.Timedelta(minutes=lookback_min)) &
                          (intraday_df.index <= now)]
    if len(window) < lookback_min * 0.6:
        return None
    moves = window["Close"].diff().abs().dropna()
    if len(moves) < 5:
        return None
    return bool(moves.mean() <= vol_ceiling)


if __name__ == "__main__":
    import argparse

    from webull_data import load_webull_intraday_csv

    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("paths", nargs="*", help="Webull-format 1-min CSV(s); defaults to everything in data/")
    ap.add_argument("--out", default="reversals_found.csv")
    args = ap.parse_args()

    paths = args.paths or sorted(glob.glob("data/SPY_Webull_1min_*.csv") + glob.glob("data/SPY_live_*.csv"))

    all_rows = []
    for path in paths:
        df = load_webull_intraday_csv(path)
        found = find_reversals(df)
        if not found.empty:
            found["source"] = path
        all_rows.append(found)
    result = pd.concat(all_rows, ignore_index=True) if all_rows else pd.DataFrame()
    result = result.sort_values("time").reset_index(drop=True)
    result.to_csv(args.out, index=False)
    print(f"Found {len(result)} grind-then-reversal points across {len(paths)} file(s)")
    print(result.to_string())
    print(f"\nWrote {args.out}")
