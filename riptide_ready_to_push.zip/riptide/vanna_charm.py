"""
Vanna and charm exposure: second-order Greek dealer flows that add to the
gamma picture, and are especially pronounced near expiration and in the
final trading hour -- directly relevant to 1DTE.

  Vanna = d(Delta)/d(sigma) -- flows triggered when implied vol changes
          (dealers rehedge as IV moves, independent of spot moving)
  Charm = d(Delta)/d(time)  -- flows triggered by pure time decay (delta
          "bleeds" toward 0 or 1 as expiration approaches, forcing
          dealers to rehedge even if spot and IV are both unchanged)

Computed via numerical differentiation of Black-Scholes delta (bump the
input, reprice, difference) rather than typing out the closed-form vanna/
charm formulas by hand -- this is standard "bump and reprice" practice and
much less error-prone than transcribing the analytic expressions, at the
cost of being a hair slower to compute. For a per-chain snapshot that's a
trivial cost.

Same data limitation as gamma_positioning.py: needs a live options chain,
so this module is live-only, not free-backtestable over history.
"""

import json
import os
from dataclasses import dataclass
from datetime import date

import numpy as np
from scipy.stats import norm

from gamma_positioning import ChainSnapshot, CONTRACT_SIZE
from voters import Vote

DEFAULT_STATE_DIR = os.path.join(os.path.dirname(__file__), "state")
VANNA_CHARM_HISTORY_PATH = os.path.join(DEFAULT_STATE_DIR, "vanna_charm_history.json")


def bs_delta(S, K, T, r, sigma, option_type: str = "call") -> np.ndarray:
    T = np.maximum(T, 1e-6)
    sigma = np.maximum(sigma, 1e-4)
    d1 = (np.log(S / K) + (r + 0.5 * sigma ** 2) * T) / (sigma * np.sqrt(T))
    if option_type == "call":
        return norm.cdf(d1)
    return norm.cdf(d1) - 1.0


def numeric_vanna(S, K, T, r, sigma, option_type: str = "call", h: float = 1e-3) -> np.ndarray:
    up = bs_delta(S, K, T, r, sigma + h, option_type)
    down = bs_delta(S, K, T, r, np.maximum(sigma - h, 1e-4), option_type)
    return (up - down) / (2 * h)


def numeric_charm(S, K, T, r, sigma, option_type: str = "call", h: float = 1 / 365 / 24) -> np.ndarray:
    """Rate of change of delta per YEAR as time passes (T decreases).
    Divide by 365 at the call site if you want per-day decay."""
    later = bs_delta(S, K, np.maximum(T - h, 1e-6), r, sigma, option_type)
    earlier = bs_delta(S, K, T + h, r, sigma, option_type)
    return (later - earlier) / (-2 * h)  # dDelta/dT, negated below at aggregation


@dataclass
class VannaCharmProfile:
    vanna_exposure: float
    charm_exposure: float
    vanna_zscore: float  # vs recent rolling history, if provided
    charm_zscore: float


def compute_vanna_charm(chain: ChainSnapshot, r: float = 0.05) -> VannaCharmProfile:
    call_vanna = numeric_vanna(chain.spot, chain.strike, chain.time_to_expiry_years, r, chain.call_iv, "call")
    put_vanna = numeric_vanna(chain.spot, chain.strike, chain.time_to_expiry_years, r, chain.put_iv, "put")
    call_charm = numeric_charm(chain.spot, chain.strike, chain.time_to_expiry_years, r, chain.call_iv, "call")
    put_charm = numeric_charm(chain.spot, chain.strike, chain.time_to_expiry_years, r, chain.put_iv, "put")

    # Same OI-weighted, calls-positive/puts-negative convention as GEX for consistency.
    vanna_exposure = float(np.nansum(call_vanna * chain.call_oi * CONTRACT_SIZE)
                            - np.nansum(put_vanna * chain.put_oi * CONTRACT_SIZE))
    charm_exposure = float(np.nansum(call_charm * chain.call_oi * CONTRACT_SIZE)
                            - np.nansum(put_charm * chain.put_oi * CONTRACT_SIZE))

    return VannaCharmProfile(vanna_exposure=vanna_exposure, charm_exposure=charm_exposure,
                              vanna_zscore=np.nan, charm_zscore=np.nan)


class VannaCharmHistoryStore:
    """Persistent (JSON-backed) log of daily |vanna+charm exposure|
    magnitude, analogous to skew_dynamics.SkewHistoryStore. Combined
    vanna/charm exposure is OI-weighted dollar notional -- its scale
    depends entirely on that day's open interest, with no natural "big"
    or "small" threshold of its own (unlike, say, a bounded ratio). The
    ONLY honest way to judge whether today's exposure is unusually large
    is against this instrument's own recent history, exactly the same
    self-calibrating approach time_of_day_fingerprint.py and
    skew_dynamics.py already use -- see vanna_charm_vote()."""

    def __init__(self, path: str = VANNA_CHARM_HISTORY_PATH):
        self.path = path
        self.readings: dict = {}
        self._load()

    def _load(self):
        if os.path.exists(self.path):
            with open(self.path) as f:
                self.readings = json.load(f)

    def save(self):
        os.makedirs(DEFAULT_STATE_DIR, exist_ok=True)
        with open(self.path, "w") as f:
            json.dump(self.readings, f)

    def record(self, as_of: date, magnitude: float):
        self.readings[as_of.isoformat()] = magnitude
        self.save()

    def history(self, lookback_days: int = 60) -> list:
        dates_sorted = sorted(self.readings.keys())[-lookback_days:]
        return [self.readings[d] for d in dates_sorted]


def vanna_charm_vote(profile: VannaCharmProfile, hours_to_close: float,
                      history_scale: float = None, store: VannaCharmHistoryStore = None,
                      as_of: date = None, min_history: int = 20, lookback_days: int = 60) -> Vote:
    """Direction: sign of combined vanna+charm exposure (positive = net
    dealer flows likely to be supportive of upside rehedging pressure,
    negative = downside). Confidence increases late in the session, since
    charm decay accelerates as expiration nears (matches the 1/sqrt(T)
    gamma acceleration this whole system is built around for 0DTE/1DTE).

    Combined exposure is raw OI-weighted dollar notional, with no natural
    scale of its own -- confidence MUST be judged against this
    instrument's own recent history, not a hardcoded constant. Passing
    `history_scale` directly does that. If you don't have one handy, pass
    `store` (a VannaCharmHistoryStore) instead and this records today's
    magnitude and computes the trailing average itself -- same self-
    calibrating pattern as skew_dynamics.skew_vote(). With neither,
    confidence is honestly 0 rather than guessed: an earlier version used
    `abs(combined) / max(abs(combined), 1.0)` as a "crude fallback," but
    that ratio is mathematically ~1.0 for any real chain (exposure is
    always $100Ks+, never anywhere near $1) -- it silently maxed out
    confidence on every real call rather than being the weak/conservative
    fallback it was meant to be. Confirmed against real historical chain
    data (2026-08-14): see README's vanna/charm case study.
    """
    combined = profile.vanna_exposure + profile.charm_exposure

    if history_scale is None and store is not None:
        hist = store.history(lookback_days)
        store.record(as_of or date.today(), abs(combined))
        if len(hist) >= min_history:
            history_scale = float(np.mean(hist))

    if history_scale and history_scale > 0:
        magnitude = min(1.0, abs(combined) / (3 * history_scale))
    else:
        return Vote(
            name="vanna_charm", direction=0.0, confidence=0.0, live_only=True,
            detail={"reason": "no vanna/charm exposure history yet to judge today's magnitude "
                               "against -- this improves the longer it's run (pass `store`)",
                    "vanna_exposure": profile.vanna_exposure, "charm_exposure": profile.charm_exposure},
        )

    time_boost = min(1.0, 1.5 * max(0.0, 1 - hours_to_close / 6.5))
    confidence = float(min(1.0, 0.4 * magnitude + 0.6 * magnitude * (0.5 + 0.5 * time_boost)))
    direction = float(np.sign(combined)) * min(1.0, abs(combined) / max(abs(combined), 1e-9))

    return Vote(
        name="vanna_charm",
        direction=direction if confidence > 0 else 0.0,
        confidence=confidence,
        regime_tag="late_session_decay" if hours_to_close < 2 else None,
        detail={
            "vanna_exposure": profile.vanna_exposure,
            "charm_exposure": profile.charm_exposure,
            "hours_to_close": hours_to_close,
            "history_scale": history_scale,
        },
        live_only=True,
    )
